# Judge release preflight — private local preparation

Status: SAFE_PREP_ONLY. This file authorizes no operational action. The supplied template stays disabled, with pending authority/policy IDs, dates, DB/origin and no credential. Changing enabled alone is insufficient. No resource creation or deployment command is supplied.

The latest available owner source is libfile_d71fc99066348191ba36572ef4902eed@v0, ZIP SHA256 5c0e2a7034d37894463097cd4417074d2e82c5228a6fd71aee25ea0362bf4d25, owner worker d473ba95a10884f5725a6305a386c4d9430ae0a371f227455206ac7572eed87e. Current HUB receipt reports live bc6ddfd7-e2d3-41d4-8395-686ea6429320 at12:35:50UTC. Those bytes and the reported history are pinned; current live freshness has not been attested in this job. A newer live source must be compared by the sole operator before deployment. C2 as a whole must not replace an unknown newer owner version.

## 1. Local work completed before any approval question

Compare every owner payload against the private C2 overlay; preserve owner runtime/schema/auth/storage and the six normalization payloads. Only judge routing/build/package overlays and generated assets may differ intentionally. Rebase README from the later owner text, preserving private-candidate caveats. Record all hashes and differences in REBASE_AUDIT.json and CYCLE03_CHANGES.json. Keep 0005/0006 separate from owner schema; local SQLite migration tests do not establish a D1 migration runner.

From nano-data-source with Node24 and the supplied no-network preload, run the representative commands recorded in the evidence runner. They exercise owner37 and judge20, fresh/populated migration, and release-specific disabled/finite synthetic accounting against source and generated worker. Do not rerun the unchanged185-case C2 set as a mandatory gate. No actual provider transport, secrets or live DB are needed.

## 2. Decisions required before operational steps

Root must review one concrete decision record covering audience, credentials/DB, actual limits, dates, costs, session/read UX, retention handling and the exact source/worker. The 5grants×4calls=20 proposal is a finite pilot, not final judging availability. USD0.02 is an unapproved estimated budget, not an invoice hard cap. Four calls funds two producer/receiver examples but does not enforce exactly two metadata cases. Session admissions remain bounded independently of calls.

The official Testing requirement provides for free, unrestricted access through judging. A final access contract satisfying that requirement is unresolved; a finite pilot approval alone cannot close it. Official judging is December1–15 Pacific time (Dubai December1 21:00–December16 00:00), and submission deadline is October30 21:00 Dubai. These are reference dates, not approved runtime values. All template dates remain PENDING. See OFFICIAL_CONSTRAINTS.md for sources.

Maximum session TTL in the current router is8h; new login cannot read old-session content. A readUntil spanning judging does not extend that session or grant a cross-session restore. Truthful instructions must describe the earlier effective access boundary. Production purge scheduling is absent; do not promise automatic24h deletion. Recommended read+24h remains a proposal only until an approved mechanism produces a deletion receipt while preserving quota tombstones.

## 3. Conditional operational sequence — root/sole operator only

1. Pin fresh live owner source and current settings through the authorized operator; compare this candidate. If source/receipt differs, rebase only the judge overlay and rerun affected local gates. Do not obtain secrets through this preparation artifact.
2. Record the specific approved pilot or final release contract, with exact values and authorization receipt. Keep unrestricted final judging access and a limited pilot as separate decisions. Missing approval means resources remain absent and runtimePolicy.enabled remains false.
3. Under that separate authorization, create the dedicated DB/bindings and explicit grants. Resolve a real D1 migration procedure and validate its receipt; the Node SQLite helper here is local-only. Record non-secret identifiers/counts and owner before/after. Do not put codes, keys, tokens or credential hashes in public artifacts.
4. Review actual policy/dates/token/timeout/estimate limits and judge instructions. Require an approved credential path; never fall back to the owner key/DB/policy or transfer owner100. Preserve the existing owner expiry and data.
5. Deploy the authorized exact worker once through the authorized operator, then read deployment version/worker hash/bindings/policy. An uncertain deploy result is investigated read-only and never automatically repeated.
6. Under a separate finite inference authorization, open a fresh browser session without an owner cookie and use one approved judge grant with fictional data: explicit producer, human review, explicit receiver, saved read. Unknown results consume quota and are read only; no automatic retry. Extra examples require approved allowance.
7. Verify owner/legacy and other-case/session/grant/campaign denial, campaign/grant decrement, owner100/data unchanged and version/source/worker correspondence. A failure disables the judge entry under authorized rollback only; it must not restore an older owner version or rewrite saved evidence.
8. Verify actual retention operations separately if physical deletion is promised. Read/access expiry alone does not prove erasure; preserve reservation and stage tombstones after purge.
9. Root records pilot/final-release decision and submits the exact source/video/English instructions/testing credentials through their separately authorized paths. This job neither publishes nor submits. Unrestricted judging access remains a release blocker until resolved with evidence.

## 4. Return and stopping boundaries

Return the private source, logs/manifest/rebase evidence and result/NEXT to HUB12 with full reread. Root handles collection and the next bounded independent check. Actual judge resources, secrets, inference, deployment, public repository changes, external messages and Submit remain unperformed here. Existing H17/other cycles are unaffected.
