// Test helper: true two-thread SQLite reservation contention. No transport or real credentials.
import {parentPort,workerData} from 'node:worker_threads';
import {LocalTrialD1} from './judge-test-db.mjs';
import {createJudgeTrialStore} from '../adapter/judge-trial-store.mjs';
const db=new LocalTrialD1(workerData.path,{initialize:false});
const gate=new Int32Array(workerData.gate);parentPort.postMessage({ready:true});
Atomics.wait(gate,0,0);
try{const store=createJudgeTrialStore(db,workerData.scope,{now:()=>workerData.now});if(workerData.action==='close'){const closed=await store.closeStage(workerData.caseId,workerData.stage);parentPort.postMessage({closed:!!closed,mockSends:0});}else{const reserved=await store.reserve(workerData.reservation);parentPort.postMessage({reserved,mockSends:reserved?1:0});}}catch(e){parentPort.postMessage({error:e.message});}finally{db.close();}
