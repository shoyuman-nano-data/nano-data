// NEW PURPOSE-AUTHORED SYNTHETIC PUBLIC-DEMO FIXTURE. No E0 or owner-source imports.
// Workflow demonstration only; no semantic/compression/AI quality claim.
const utf8=new TextEncoder();
export const SYNTHETIC_SOURCE='NEW SYNTHETIC DEMO: The fictional Willow Reading Club plans one Saturday reading session. Its invented room has two tables and six chairs. Attendance, satisfaction and outcomes have not been measured. This text describes no real person, organization or event.';
export const FIXTURES=Object.freeze({
 A_REPORT:JSON.stringify({fixture:'JUDGE_PUBLIC_SYNTHETIC_V1',job:'A_REPORT',report:'A fictional reading session is planned. The room has two tables and six chairs. Attendance and outcomes are unknown.',scope:'WORKFLOW_ONLY_NOT_MEANING_QUALITY_PROOF'}),
 B_REPORT:JSON.stringify({fixture:'JUDGE_PUBLIC_SYNTHETIC_V1',job:'B_REPORT',report:'Fictional reading plan: 2 tables, 6 chairs; attendance/outcomes unknown.',scope:'WORKFLOW_ONLY_NOT_MEANING_QUALITY_PROOF'}),
 B_SOURCE:JSON.stringify({fixture:'JUDGE_PUBLIC_SYNTHETIC_V1',job:'B_SOURCE',source:SYNTHETIC_SOURCE,scope:'SYNTHETIC_SOURCE_BYTE_CHECK_ONLY'})
});
export const PIN=Object.freeze(Object.fromEntries(Object.keys(FIXTURES).map(job=>[job,true])));
export async function hash(value){const bytes=typeof value==='string'?utf8.encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');}
export async function compute(job){
 if(!Object.hasOwn(FIXTURES,job))throw Error('UNKNOWN_JOB');
 const input=utf8.encode(FIXTURES[job]),sourceBytes=job==='B_SOURCE'?utf8.encode(SYNTHETIC_SOURCE):null;
 const receipt={schema:'JUDGE_SYNTHETIC_RECEIPT_V1',fixture:'JUDGE_PUBLIC_SYNTHETIC_V1',job,payload_bytes:input.length,input_sha256:await hash(input),observed_local_source_reads_this_operation:sourceBytes?1:0,observed_local_source_bytes_this_operation:sourceBytes?.length??0,source_sha256:sourceBytes?await hash(sourceBytes):null,actual_model_calls:0,actual_sent_bytes:'NOT_RUN',semantic_quality:'NOT_EVALUATED',compression_benefit:'NOT_EVALUATED',scope:'NEW_SYNTHETIC_WORKFLOW_ONLY',demo_text:JSON.parse(FIXTURES[job]).report??SYNTHETIC_SOURCE};
 const files={'input.json':input,'result.json':utf8.encode(JSON.stringify({job,status:'FIXED_SYNTHETIC_BYTES_COMPUTED',input_sha256:receipt.input_sha256})),'receipt.json':utf8.encode(JSON.stringify(receipt)),'verification.json':utf8.encode(JSON.stringify({job,method:'RECOMPUTE_FIXED_SYNTHETIC_BYTES',not_ai:true}))};
 return {files,receipt};
}
export async function verify(job,files){const expected=(await compute(job)).files;if(Object.keys(files).sort().join(',')!==Object.keys(expected).sort().join(','))throw Error('FIXED_FILE_SET_MISMATCH');for(const name of Object.keys(expected)){if(!(files[name] instanceof Uint8Array)||files[name].length!==expected[name].length||!files[name].every((byte,i)=>byte===expected[name][i]))throw Error('FIXED_BYTE_MISMATCH');}return {status:'EXACT_SYNTHETIC_BYTES_VERIFIED',scope:'NEW_SYNTHETIC_WORKFLOW_ONLY'};}
