import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {migrateJudgeTrialCases} from '../adapter/judge-trial-migration.mjs';
export const trialHash=s=>createHash('sha256').update(s).digest('hex');
export class LocalTrialD1{
 constructor(path=':memory:',{initialize=true}={}){this.sql=new DatabaseSync(path);this.sql.exec('PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');if(initialize){this.sql.exec(readFileSync(new URL('../migrations/0005_judge_trial_isolated.sql',import.meta.url),'utf8'));migrateJudgeTrialCases(this.sql);}}
 withSession(){return this;}
 prepare(query){const sql=this.sql;return {bind(...args){return {async run(){const r=sql.prepare(query).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},async first(){return sql.prepare(query).get(...args)||null;},async all(){return {success:true,results:sql.prepare(query).all(...args)};}};}};}
 async batch(statements){this.sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());this.sql.exec('COMMIT');return result;}catch(e){this.sql.exec('ROLLBACK');throw e;}}
 close(){this.sql.close();}
}
export function seedTrialFixture(db,{now=Date.now(),campaignId='CAMP_LOCAL',grantCount=4,ceiling=8,callCeiling=2,maxSessions=2,executeMs=40*60000,readMs=60*60000,retentionMs=120*60000}={}){
 db.sql.prepare('INSERT INTO trial_campaigns(id,ceiling,execute_until,read_until,retention_until) VALUES(?,?,?,?,?)').run(campaignId,ceiling,now+executeMs,now+readMs,now+retentionMs);
 const grants=[];for(let i=1;i<=grantCount;i++){const id='GRANT_LOCAL_'+i,code='LOCAL_TEST_ONLY_CODE_'+i;db.sql.prepare('INSERT INTO trial_grants(id,campaign_id,code_hash,call_ceiling,max_sessions,expires_at) VALUES(?,?,?,?,?,?)').run(id,campaignId,trialHash(code),callCeiling,maxSessions,now+readMs);grants.push({id,code,codeHash:trialHash(code)});}
 return {campaignId,grants};
}
