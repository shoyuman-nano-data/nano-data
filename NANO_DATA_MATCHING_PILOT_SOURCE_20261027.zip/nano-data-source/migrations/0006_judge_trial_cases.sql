-- ISOLATED LOCAL JUDGE DATABASE ONLY. Never apply to the owner JUDGE_DB.
-- Run through migrateJudgeTrialCases(sql,{randomBytes}); it validates legacy rows,
-- supplies TEMP._trial_case_migration and owns one BEGIN IMMEDIATE/COMMIT boundary.
-- Direct execution without that validated staging table fails; do not bypass it.
CREATE UNIQUE INDEX trial_grants_case_scope ON trial_grants(id,campaign_id);
CREATE UNIQUE INDEX trial_sessions_case_scope ON trial_sessions(id,grant_id);
CREATE TABLE trial_cases (
 case_id TEXT PRIMARY KEY NOT NULL,
 receiver_id TEXT NOT NULL UNIQUE CHECK(receiver_id<>case_id),
 campaign_id TEXT NOT NULL REFERENCES trial_campaigns(id),
 grant_id TEXT NOT NULL,
 session_id TEXT NOT NULL,
 creation_key TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 producer_closed_at INTEGER,
 receiver_closed_at INTEGER,
 UNIQUE(session_id,creation_key),
 UNIQUE(case_id,campaign_id,grant_id,session_id),
 FOREIGN KEY(grant_id,campaign_id) REFERENCES trial_grants(id,campaign_id),
 FOREIGN KEY(session_id,grant_id) REFERENCES trial_sessions(id,grant_id)
);
INSERT INTO trial_cases(case_id,receiver_id,campaign_id,grant_id,session_id,creation_key,created_at,producer_closed_at,receiver_closed_at)
 SELECT case_id,receiver_id,campaign_id,grant_id,session_id,creation_key,created_at,NULL,NULL FROM temp._trial_case_migration;
CREATE TABLE trial_runs_cases_new (
 id TEXT PRIMARY KEY NOT NULL,
 campaign_id TEXT NOT NULL REFERENCES trial_campaigns(id),
 grant_id TEXT NOT NULL REFERENCES trial_grants(id),
 session_id TEXT NOT NULL REFERENCES trial_sessions(id),
 case_id TEXT NOT NULL,
 stage TEXT NOT NULL CHECK(stage IN('produce','receive')),
 parent_id TEXT,
 source TEXT,
 input_hash TEXT,
 policy_revision TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 evidence_json TEXT,
 finished_at INTEGER,
 purged_at INTEGER,
 UNIQUE(grant_id,case_id,stage),
 CHECK((stage='produce' AND id=case_id AND parent_id IS NULL) OR (stage='receive' AND id<>case_id AND parent_id=case_id)),
 FOREIGN KEY(case_id,campaign_id,grant_id,session_id) REFERENCES trial_cases(case_id,campaign_id,grant_id,session_id)
);
INSERT INTO trial_runs_cases_new(id,campaign_id,grant_id,session_id,case_id,stage,parent_id,source,input_hash,policy_revision,created_at,evidence_json,finished_at,purged_at)
 SELECT id,campaign_id,grant_id,session_id,CASE WHEN stage='produce' THEN id ELSE parent_id END,stage,parent_id,source,input_hash,policy_revision,created_at,evidence_json,finished_at,purged_at FROM trial_runs;
DROP TABLE trial_runs;
ALTER TABLE trial_runs_cases_new RENAME TO trial_runs;
CREATE INDEX trial_runs_campaign ON trial_runs(campaign_id);
CREATE INDEX trial_runs_scope ON trial_runs(session_id,grant_id,campaign_id,case_id);
CREATE INDEX trial_cases_scope ON trial_cases(session_id,grant_id,campaign_id);
CREATE INDEX trial_cases_grant ON trial_cases(grant_id);
CREATE TRIGGER trial_runs_case_fixed_id BEFORE INSERT ON trial_runs
WHEN NOT EXISTS(SELECT 1 FROM trial_cases k WHERE k.case_id=NEW.case_id AND k.campaign_id=NEW.campaign_id AND k.grant_id=NEW.grant_id AND k.session_id=NEW.session_id AND ((NEW.stage='produce' AND NEW.id=k.case_id) OR (NEW.stage='receive' AND NEW.id=k.receiver_id AND NEW.parent_id=k.case_id)))
BEGIN SELECT RAISE(ABORT,'TRIAL_CASE_FIXED_ID'); END;
CREATE TRIGGER trial_cases_id_namespace BEFORE INSERT ON trial_cases
WHEN EXISTS(SELECT 1 FROM trial_cases k WHERE k.case_id IN(NEW.case_id,NEW.receiver_id) OR k.receiver_id IN(NEW.case_id,NEW.receiver_id)) OR EXISTS(SELECT 1 FROM trial_runs r WHERE r.id IN(NEW.case_id,NEW.receiver_id))
BEGIN SELECT RAISE(ABORT,'TRIAL_CASE_ID_COLLISION'); END;
