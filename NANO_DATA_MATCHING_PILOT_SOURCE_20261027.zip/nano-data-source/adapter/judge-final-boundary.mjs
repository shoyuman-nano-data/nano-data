// Final-judging activation remains disabled by default. This is not auth issuance,
// a credentials loader, a billing proof, or a grant to deploy/change live settings.
import {createJudgeCostGuard,createJudgeCostLedger,readPublicModelPricing,COST_BUDGET_ID,JUDGING_END} from './judge-cost-guard.mjs';
export const FINAL_RUNTIME_MODE='BOUNDED_FINAL_JUDGING_V1';
export function finalJudgingRequested(env){
 if(env.JUDGE_FINAL_RUNTIME!==undefined||env.JUDGE_FINAL_COST_POLICY_JSON!==undefined)return true;
 try{const p=JSON.parse(env.JUDGE_TRIAL_POLICY_JSON||'{}');return !!p&&Object.hasOwn(p,'finalJudging');}catch{return false;}
}
export function finalJudgingPolicy(env,trialPolicy,now=Date.now){
 let p;try{p=JSON.parse(env.JUDGE_FINAL_COST_POLICY_JSON||'{}');}catch{return null;}
 const t=now();
 if(env.JUDGE_FINAL_RUNTIME!==FINAL_RUNTIME_MODE||trialPolicy?.finalJudging!==true||env.JUDGE_TRIAL_PILOT_BRIDGE!==undefined||p.enabled!==true||p.mode!=='APPLICATION_RESERVATION_GUARD_NOT_INVOICE_CAP'||p.spendingAuthority!=='FREE_CREDITS_ONLY_NO_AUTOMATIC_PAID_CHARGES'||p.budgetId!==COST_BUDGET_ID||p.executeUntil!==JUDGING_END||!Number.isSafeInteger(p.startsAt)||p.startsAt>t||t>=JUDGING_END||p.startsAt>=JUDGING_END||p.producerMaxOutputTokens!==512||p.receiverMaxOutputTokens!==2048||trialPolicy.receiverMaxOutputTokens!==2048||trialPolicy.receiverDeadlineMs!==60000||p.activationAuthorization!=='EXPLICIT_FINAL_JUDGING_ACTIVATION_AFTER_REVIEW')return null;
 return Object.freeze({...p});
}
export function finalJudgingTransport({env,policy,runId,providerFetch,readPublicPricing=readPublicModelPricing,now=Date.now}){
 return createJudgeCostGuard({ledger:createJudgeCostLedger(env.JUDGE_TRIAL_DB,{now}),providerFetch,readPublicPricing,policy,now}).forRun(runId);
}
