// Dedicated judge DB adapter. No owner DB/key/policy fallback, grant issuer or provider transport.
const textID=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(v);
const hashID=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const runID=v=>typeof v==='string'&&/^HOF_[a-f0-9]{32}$/.test(v);
const clockValue=now=>{const n=now();if(!Number.isSafeInteger(n)||n<0)throw Error('TRIAL_CLOCK_INVALID');return n;};
const confirmed=r=>{if(r?.success!==true||!Number.isSafeInteger(r.meta?.changes))throw Error('TRIAL_STORAGE_UNCONFIRMED');return r.meta.changes;};
const ownerFor=s=>`trial:${s.campaignId}:${s.sessionId}`;
function context(row){return row?{campaignId:row.campaign_id,grantId:row.grant_id,sessionId:row.session_id,expiresAt:row.session_expires_at,executeUntil:row.execute_until,readUntil:row.read_until,retentionUntil:row.retention_until,grantExpiresAt:row.grant_expires_at,sessionTag:row.session_id,owner:ownerFor({campaignId:row.campaign_id,sessionId:row.session_id})}:null;}
const joined=`SELECT s.id session_id,s.expires_at session_expires_at,g.id grant_id,g.campaign_id,g.expires_at grant_expires_at,c.execute_until,c.read_until,c.retention_until FROM trial_sessions s JOIN trial_grants g ON g.id=s.grant_id JOIN trial_campaigns c ON c.id=g.campaign_id`;
const readable=`s.revoked=0 AND g.revoked=0 AND c.revoked=0 AND s.expires_at>? AND g.expires_at>? AND c.read_until>? AND c.retention_until>?`;
export function createJudgeTrialStore(DB,scope={}, {now=Date.now}={}){
 if(!DB||typeof DB.withSession!=='function')throw Error('TRIAL_DATABASE_REQUIRED');
 const db=DB.withSession('first-primary'),bound=Object.freeze({...scope});
 const scoped=s=>textID(s?.campaignId)&&textID(s?.grantId)&&textID(s?.sessionId);
 const active=async(s=bound)=>{if(!scoped(s))return null;const t=clockValue(now);return context(await db.prepare(`${joined} WHERE c.id=? AND g.id=? AND s.id=? AND ${readable}`).bind(s.campaignId,s.grantId,s.sessionId,t,t,t,t).first());};
 const totals=async(s=bound)=>{const r=await db.prepare(`SELECT c.ceiling campaign_ceiling,g.call_ceiling grant_ceiling,g.max_sessions,(SELECT COUNT(*) FROM trial_runs WHERE campaign_id=c.id) campaign_used,(SELECT COUNT(*) FROM trial_runs WHERE grant_id=g.id) grant_used,(SELECT COUNT(*) FROM trial_cases WHERE grant_id=g.id) metadata_used FROM trial_campaigns c JOIN trial_grants g ON g.campaign_id=c.id WHERE c.id=? AND g.id=?`).bind(s.campaignId,s.grantId).first();return r?{campaignUsed:r.campaign_used,campaignCeiling:r.campaign_ceiling,grantUsed:r.grant_used,grantCeiling:r.grant_ceiling,remainingCalls:Math.max(0,Math.min(r.campaign_ceiling-r.campaign_used,r.grant_ceiling-r.grant_used)),metadataUsed:r.metadata_used,metadataCeiling:r.grant_ceiling+r.max_sessions}:null;};
 const caseRow=async(id,s=bound)=>db.prepare('SELECT * FROM trial_cases WHERE case_id=? AND campaign_id=? AND grant_id=? AND session_id=?').bind(id,s.campaignId,s.grantId,s.sessionId).first();
 const stageRows=async(id,s=bound)=>{const r=await db.prepare('SELECT stage,evidence_json,purged_at FROM trial_runs WHERE case_id=? AND campaign_id=? AND grant_id=? AND session_id=?').bind(id,s.campaignId,s.grantId,s.sessionId).all();if(r.success!==true||!Array.isArray(r.results))throw Error('TRIAL_STORAGE_UNCONFIRMED');return r.results;};
 const parentReady=rows=>{const p=rows.find(x=>x.stage==='produce');if(!p||p.purged_at!==null||!p.evidence_json)return false;try{const e=JSON.parse(p.evidence_json);return e.finish_reason==='stop'&&['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(e.status);}catch{return false;}};
 const availability=(k,rows,can)=>({produce:can&&k.producer_closed_at===null&&!rows.some(x=>x.stage==='produce'),receive:can&&k.receiver_closed_at===null&&!rows.some(x=>x.stage==='receive')&&parentReady(rows)});
 const summary=async(id)=>{const k=await caseRow(id);if(!k)return null;const a=await active();if(!a)return null;const u=await totals(),rows=await stageRows(id);const stage=s=>{const row=rows.find(x=>x.stage===s),closed=(s==='produce'?k.producer_closed_at:k.receiver_closed_at)!==null;return {reserved:!!row,closed,status:row?(row.purged_at!==null?'PURGED_TOMBSTONE':row.evidence_json?'SAVED':'PENDING_OR_UNKNOWN_NO_RESEND'):closed?'CLOSED_NO_RETRY':'UNSENT'};};return {caseId:k.case_id,producerId:k.case_id,receiverId:k.receiver_id,creationKey:k.creation_key,createdAt:k.created_at,producerClosedAt:k.producer_closed_at,receiverClosedAt:k.receiver_closed_at,stages:{produce:stage('produce'),receive:stage('receive')},availableStages:availability(k,rows,!!a&&clockValue(now)<a.executeUntil&&u.remainingCalls>0)};};
 return {
  async login({codeHash,sessionId,tokenHash,ttlMs,campaignId}={}){
   const t=clockValue(now);
   if(!hashID(codeHash)||!hashID(tokenHash)||!textID(sessionId)||!textID(campaignId)||!Number.isSafeInteger(ttlMs)||ttlMs<1||ttlMs>86400000)return {status:'INVALID_CODE'};
   // Pre-read only classifies failures. Admission itself rechecks all bounds atomically below.
   const grant=await db.prepare('SELECT g.id,g.sessions_issued,g.max_sessions,g.expires_at,g.revoked,c.execute_until,c.read_until,c.retention_until,c.revoked campaign_revoked FROM trial_grants g JOIN trial_campaigns c ON c.id=g.campaign_id WHERE g.code_hash=? AND c.id=?').bind(codeHash,campaignId).first();
   if(!grant)return {status:'INVALID_CODE'};
   if(grant.revoked||grant.campaign_revoked||grant.expires_at<=t||grant.execute_until<=t||grant.read_until<=t||grant.retention_until<=t)return {status:'EXPIRED'};
   const result=await db.prepare(`INSERT OR IGNORE INTO trial_sessions(id,token_hash,grant_id,expires_at) SELECT ?,?,g.id,MIN(?,g.expires_at,c.read_until) FROM trial_grants g JOIN trial_campaigns c ON c.id=g.campaign_id WHERE g.code_hash=? AND c.id=? AND g.sessions_issued<g.max_sessions AND g.revoked=0 AND c.revoked=0 AND g.expires_at>? AND c.execute_until>? AND c.read_until>? AND c.retention_until>?`).bind(sessionId,tokenHash,t+ttlMs,codeHash,campaignId,t,t,t,t).run();
   if(confirmed(result)!==1)return {status:'SESSION_LIMIT'};
   const session=await this.session(tokenHash);if(!session)throw Error('TRIAL_SESSION_COMMIT_UNCONFIRMED');
   return {status:'CREATED',session,scope:{campaignId:session.campaignId,grantId:session.grantId,sessionId:session.sessionId}};
  },
  async session(tokenHash){if(!hashID(tokenHash))return null;const t=clockValue(now);return context(await db.prepare(`${joined} WHERE s.token_hash=? AND ${readable}`).bind(tokenHash,t,t,t,t).first());},
  async logout(tokenHash){if(!hashID(tokenHash))return false;return confirmed(await db.prepare('UPDATE trial_sessions SET revoked=1 WHERE token_hash=? AND revoked=0').bind(tokenHash).run())===1;},
  async badLogin(){const t=clockValue(now),window=Math.floor(t/900000);confirmed(await db.prepare('DELETE FROM trial_login_windows WHERE window<?').bind(window-1).run());const r=await db.prepare("INSERT INTO trial_login_windows(window,kind,attempts) VALUES(?,'invalid',1) ON CONFLICT(window,kind) DO UPDATE SET attempts=MIN(attempts+1,1000000) RETURNING attempts").bind(window).first();if(!Number.isSafeInteger(r?.attempts))throw Error('TRIAL_STORAGE_UNCONFIRMED');return {limited:r.attempts>10,retryAfterSeconds:Math.max(1,Math.ceil(((window+1)*900000-t)/1000))};},
  async usage(s=bound){
   const a=await active(s);if(!a)return null;
   const r=await totals(s);if(!r)return null;
   const canExecute=clockValue(now)<a.executeUntil&&r.remainingCalls>0;
   const k=runID(s.caseId)?await caseRow(s.caseId,s):null;
   const stages=k?await stageRows(k.case_id,s):[];
   const availableStages=k?availability(k,stages,canExecute):{produce:false,receive:false};
   return {...r,canExecute,availableStages};
  },
  async createCase({creationKey,producerId,receiverId}={}){
   if(!scoped(bound)||!textID(creationKey)||!runID(producerId)||!runID(receiverId)||producerId===receiverId)return {status:'CLOSED',case:null};
   if(!await active())return {status:'CLOSED',case:null};
   const existing=await db.prepare('SELECT case_id FROM trial_cases WHERE session_id=? AND creation_key=? AND grant_id=? AND campaign_id=?').bind(bound.sessionId,creationKey,bound.grantId,bound.campaignId).first();
   if(existing)return {status:'EXISTING',case:await summary(existing.case_id)};
   const t=clockValue(now);
   const r=await db.prepare(`INSERT OR IGNORE INTO trial_cases(case_id,receiver_id,campaign_id,grant_id,session_id,creation_key,created_at) SELECT ?,?,?,?,?,?,? FROM trial_sessions s JOIN trial_grants g ON g.id=s.grant_id JOIN trial_campaigns c ON c.id=g.campaign_id WHERE s.id=? AND g.id=? AND c.id=? AND ${readable} AND c.execute_until>? AND (SELECT COUNT(*) FROM trial_runs WHERE campaign_id=c.id)<c.ceiling AND (SELECT COUNT(*) FROM trial_runs WHERE grant_id=g.id)<g.call_ceiling AND (SELECT COUNT(*) FROM trial_cases WHERE grant_id=g.id)<g.call_ceiling+g.max_sessions AND NOT EXISTS(SELECT 1 FROM trial_cases k WHERE k.session_id=s.id AND k.producer_closed_at IS NULL AND NOT EXISTS(SELECT 1 FROM trial_runs p WHERE p.case_id=k.case_id AND p.stage='produce')) AND NOT EXISTS(SELECT 1 FROM trial_cases WHERE case_id IN(?,?) OR receiver_id IN(?,?)) AND NOT EXISTS(SELECT 1 FROM trial_runs WHERE id IN(?,?))`).bind(producerId,receiverId,bound.campaignId,bound.grantId,bound.sessionId,creationKey,t,bound.sessionId,bound.grantId,bound.campaignId,t,t,t,t,t,producerId,receiverId,producerId,receiverId,producerId,receiverId).run();
   if(confirmed(r)===1)return {status:'CREATED',case:await summary(producerId)};
   const same=await db.prepare('SELECT case_id FROM trial_cases WHERE session_id=? AND creation_key=? AND grant_id=? AND campaign_id=?').bind(bound.sessionId,creationKey,bound.grantId,bound.campaignId).first();
   if(same)return {status:'EXISTING',case:await summary(same.case_id)};
   const empty=await db.prepare("SELECT case_id FROM trial_cases k WHERE session_id=? AND grant_id=? AND campaign_id=? AND producer_closed_at IS NULL AND NOT EXISTS(SELECT 1 FROM trial_runs p WHERE p.case_id=k.case_id AND p.stage='produce') ORDER BY created_at,case_id LIMIT 1").bind(bound.sessionId,bound.grantId,bound.campaignId).first();
   if(empty)return {status:'EMPTY_CASE_EXISTS',case:await summary(empty.case_id)};
   const u=await this.usage();if(!u||!u.canExecute)return {status:'CLOSED',case:null};
   if(u.metadataUsed>=u.metadataCeiling)return {status:'METADATA_LIMIT',case:null};
   return {status:'ID_COLLISION',case:null};
  },
  async caseLookup(caseId){return runID(caseId)&&await active()?summary(caseId):null;},
  async listCases(){
   const a=await active();if(!a)return [];const u=await totals();if(!u)return [];
   const r=await db.prepare('SELECT * FROM trial_cases WHERE campaign_id=? AND grant_id=? AND session_id=? ORDER BY created_at,case_id').bind(bound.campaignId,bound.grantId,bound.sessionId).all();
   // Constant query count. Do not load model output/source just to render state.
   const stages=await db.prepare(`SELECT case_id,stage,purged_at,evidence_json IS NOT NULL has_evidence,
    CASE WHEN json_valid(evidence_json) THEN json_extract(evidence_json,'$.finish_reason') END finish_reason,
    CASE WHEN json_valid(evidence_json) THEN json_extract(evidence_json,'$.status') END evidence_status
    FROM trial_runs WHERE campaign_id=? AND grant_id=? AND session_id=?`).bind(bound.campaignId,bound.grantId,bound.sessionId).all();
   if(r.success!==true||!Array.isArray(r.results)||stages.success!==true||!Array.isArray(stages.results))throw Error('TRIAL_STORAGE_UNCONFIRMED');
   if(!await active())return [];
   const byCase=new Map();for(const row of stages.results){const rows=byCase.get(row.case_id)||[];rows.push(row);byCase.set(row.case_id,rows);}
   return r.results.map(k=>{const rows=byCase.get(k.case_id)||[],producer=rows.find(x=>x.stage==='produce'),can=clockValue(now)<a.executeUntil&&u.remainingCalls>0;
    const stage=s=>{const row=rows.find(x=>x.stage===s),closed=(s==='produce'?k.producer_closed_at:k.receiver_closed_at)!==null;return {reserved:!!row,closed,status:row?(row.purged_at!==null?'PURGED_TOMBSTONE':row.has_evidence?'SAVED':'PENDING_OR_UNKNOWN_NO_RESEND'):closed?'CLOSED_NO_RETRY':'UNSENT'};};
    return {caseId:k.case_id,producerId:k.case_id,receiverId:k.receiver_id,creationKey:k.creation_key,createdAt:k.created_at,producerClosedAt:k.producer_closed_at,receiverClosedAt:k.receiver_closed_at,stages:{produce:stage('produce'),receive:stage('receive')},availableStages:{produce:can&&k.producer_closed_at===null&&!producer,receive:can&&k.receiver_closed_at===null&&!rows.some(x=>x.stage==='receive')&&!!producer&&producer.purged_at===null&&producer.finish_reason==='stop'&&['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(producer.evidence_status)}};
   });
  },
  async closeStage(caseId,stage){
   if(!runID(caseId)||!['produce','receive'].includes(stage)||!await active())return null;
   const col=stage==='produce'?'producer_closed_at':'receiver_closed_at',t=clockValue(now);
   confirmed(await db.prepare(`UPDATE trial_cases SET ${col}=COALESCE(${col},?) WHERE case_id=? AND campaign_id=? AND grant_id=? AND session_id=? AND EXISTS(${joined} WHERE s.id=trial_cases.session_id AND g.id=trial_cases.grant_id AND c.id=trial_cases.campaign_id AND ${readable})`).bind(t,caseId,bound.campaignId,bound.grantId,bound.sessionId,t,t,t,t).run());
   return summary(caseId);
  },
  async reserve({id,owner,source,inputHash,policy}={}){
   if(!scoped(bound)||!runID(bound.caseId)||owner!==ownerFor(bound)||!runID(id)||!hashID(inputHash)||typeof source!=='string'||new TextEncoder().encode(source).length>800)return false;
   let input;try{input=JSON.parse(source);}catch{return false;}
   const stage=input?.stage;if(!['produce','receive'].includes(stage))return false;
   const parent=stage==='receive'?input.parentId:null;
   if(stage==='receive'&&(!runID(parent)||id===parent||input.originalRef!==parent))return false;
   const revision=policy?.policyId;if(!textID(revision))return false;const t=clockValue(now);
   const fixed=stage==='produce'?"AND k.case_id=? AND k.producer_closed_at IS NULL":"AND k.receiver_id=? AND k.receiver_closed_at IS NULL AND k.case_id=?";
   const parentCheck=stage==='receive'?`AND EXISTS(SELECT 1 FROM trial_runs p WHERE p.id=k.case_id AND p.case_id=k.case_id AND p.campaign_id=c.id AND p.grant_id=g.id AND p.session_id=s.id AND p.stage='produce' AND p.purged_at IS NULL AND p.evidence_json IS NOT NULL AND json_valid(p.evidence_json) AND json_extract(p.evidence_json,'$.finish_reason')='stop' AND json_extract(p.evidence_json,'$.status') IN('RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'))`:'';
   const args=[id,bound.campaignId,bound.grantId,bound.sessionId,bound.caseId,stage,parent,source,inputHash,revision,t,bound.sessionId,bound.grantId,bound.campaignId,bound.caseId,t,t,t,t,t,id,...(stage==='receive'?[parent]:[])];
   const result=await db.prepare(`INSERT OR IGNORE INTO trial_runs(id,campaign_id,grant_id,session_id,case_id,stage,parent_id,source,input_hash,policy_revision,created_at) SELECT ?,?,?,?,?,?,?,?,?,?,? FROM trial_sessions s JOIN trial_grants g ON g.id=s.grant_id JOIN trial_campaigns c ON c.id=g.campaign_id JOIN trial_cases k ON k.session_id=s.id AND k.grant_id=g.id AND k.campaign_id=c.id WHERE s.id=? AND g.id=? AND c.id=? AND k.case_id=? AND ${readable} AND c.execute_until>? AND (SELECT COUNT(*) FROM trial_runs WHERE campaign_id=c.id)<c.ceiling AND (SELECT COUNT(*) FROM trial_runs WHERE grant_id=g.id)<g.call_ceiling ${fixed} ${parentCheck}`).bind(...args).run();return confirmed(result)===1;
  },
  async finish(id,evidence){
   if(!scoped(bound)||!runID(bound.caseId)||!runID(id)||!evidence||typeof evidence!=='object')return false;
   const t=clockValue(now);let encoded;try{encoded=JSON.stringify(evidence);}catch{return false;}
   // Closed stages and access expiry cannot erase an already-reserved completion. Retention/purge can.
   const r=await db.prepare(`UPDATE trial_runs SET evidence_json=?,finished_at=? WHERE id=? AND case_id=? AND campaign_id=? AND grant_id=? AND session_id=? AND evidence_json IS NULL AND purged_at IS NULL AND EXISTS(SELECT 1 FROM trial_cases k WHERE k.case_id=trial_runs.case_id AND k.campaign_id=trial_runs.campaign_id AND k.grant_id=trial_runs.grant_id AND k.session_id=trial_runs.session_id AND ((trial_runs.stage='produce' AND trial_runs.id=k.case_id) OR (trial_runs.stage='receive' AND trial_runs.id=k.receiver_id))) AND EXISTS(SELECT 1 FROM trial_campaigns c WHERE c.id=trial_runs.campaign_id AND c.retention_until>?)`).bind(encoded,t,id,bound.caseId,bound.campaignId,bound.grantId,bound.sessionId,t).run();return confirmed(r)===1;
  },
  async read(id,owner){if(!scoped(bound)||!runID(bound.caseId)||owner!==ownerFor(bound)||!runID(id)||!await active())return null;const r=await db.prepare('SELECT r.id,r.source,r.input_hash,r.created_at,r.evidence_json,r.finished_at,r.purged_at FROM trial_runs r JOIN trial_cases k ON k.case_id=r.case_id AND k.campaign_id=r.campaign_id AND k.grant_id=r.grant_id AND k.session_id=r.session_id WHERE r.id=? AND r.case_id=? AND r.campaign_id=? AND r.grant_id=? AND r.session_id=? AND (r.id=k.case_id OR r.id=k.receiver_id) AND r.purged_at IS NULL').bind(id,bound.caseId,bound.campaignId,bound.grantId,bound.sessionId).first();return r?{id:r.id,source:r.source,input_hash:r.input_hash,created_at:r.created_at,finished_at:r.finished_at,evidence:r.evidence_json?JSON.parse(r.evidence_json):null,status:r.evidence_json?'SAVED':'PENDING_OR_UNKNOWN_NO_RESEND'}:null;},
  async purge(){const t=clockValue(now);return confirmed(await db.prepare('UPDATE trial_runs SET source=NULL,input_hash=NULL,evidence_json=NULL,purged_at=? WHERE purged_at IS NULL AND campaign_id IN(SELECT id FROM trial_campaigns WHERE retention_until<=?)').bind(t,t).run());}
 };
}
