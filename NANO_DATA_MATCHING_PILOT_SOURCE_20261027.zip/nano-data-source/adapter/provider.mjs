// NOT DEPLOYED / NOT ENABLED. Network-capable foundation; real use requires new explicit approval.
// No credentials, route, public permit issuer, or actual provider calls are created here.
import {SYNTHETIC_SOURCE,hash} from './core.mjs';
export const ENDPOINT='https://api.tokenfactory.nebius.com/v1/chat/completions';
export const MODEL='nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B';
export const PROMPT=SYNTHETIC_SOURCE+'\nSummarize the plan in at most 60 words. Preserve the unknowns. Do not invent attendance, satisfaction or outcomes.';
export const requestBody=()=>({model:MODEL,messages:[{role:'user',content:PROMPT}],max_completion_tokens:512,n:1,stream:false,store:false,service_tier:'default'});
export const promptHash=()=>hash(PROMPT);
export const MAX_INPUT_UTF8_BYTES=1024;
export const ESTIMATED_MAX_USD=(1024*0.06+512*0.24)/1000000; // estimate only, not tokenizer/account billing cap

export function createProviderAttempt({store,serverApproval,credential,fetchImpl=globalThis.fetch,deadlineMs=15000,prompt=PROMPT,maxOutputTokens=512}){
 // Snapshot known scalar approval fields BEFORE any asynchronous boundary.
 const p=serverApproval||{},a=Object.freeze(Object.fromEntries(['approvalId','authority','approved','inputHash','model','endpoint','maxCalls','maxOutputTokens','maxInputTokens','budgetUSD','expiresAt'].map(k=>[k,p[k]])));
 const requestForRun=()=>({...requestBody(),messages:[{role:'user',content:prompt}],max_completion_tokens:maxOutputTokens});
 const testTransport=fetchImpl!==globalThis.fetch;
 if(typeof fetchImpl!=='function'||!store?.claim||!store?.finish||!Number.isInteger(deadlineMs)||deadlineMs<1||deadlineMs>60000||![512,2048].includes(maxOutputTokens))throw Error('DEPENDENCIES_OR_DEADLINE_INVALID');
 const base=()=>({evidence_scope:testTransport?'INJECTED_TRANSPORT_TEST_NOT_PROVIDER_EVIDENCE':'PROVIDER_REPORTED_NOT_INDEPENDENTLY_VERIFIED',actual_model_calls:testTransport?0:'UNKNOWN',automatic_retry:false,billing:'UNKNOWN'});
 const closed=reason=>({...base(),status:'CLOSED',reason,request_attempts:0,usage:'UNKNOWN',output:null});
 return {async run({ownerAuthorized=false}={}){
  if(ownerAuthorized!==true)return closed('OWNER_AUTH_REQUIRED');
  if(typeof prompt!=='string'||!prompt.trim()||new TextEncoder().encode(prompt).length>MAX_INPUT_UTF8_BYTES||(1024*0.06+maxOutputTokens*0.24)/1000000>0.01)return closed('PREFLIGHT_SIZE_OR_ESTIMATE_CLOSED');
  if(typeof credential!=='string'||!credential.trim()||/[\r\n]/.test(credential))return closed('PROVIDER_SECRET_REQUIRED');
  const cutoff=Date.parse(a.expiresAt);
  if(a.authority!=='EXPLICIT_OWNER_ONE_CALL_APPROVAL'||a.approved!==true||typeof a.approvalId!=='string'||!/^NEBIUS_[A-Z0-9_]{1,96}$/.test(a.approvalId)||!Number.isFinite(cutoff)||new Date(cutoff).toISOString()!==a.expiresAt||Date.now()>=cutoff||a.inputHash!==await hash(prompt)||a.model!==MODEL||a.endpoint!==ENDPOINT||a.maxCalls!==1||a.maxOutputTokens!==maxOutputTokens||a.maxInputTokens!==1024||a.budgetUSD!==0.01)return closed('APPROVAL_BINDING_INVALID');
  let claim;try{claim=await store.claim(a);}catch{return {...closed('CLAIM_UNCERTAIN_NO_SEND'),status:'UNKNOWN_STOP_NO_RETRY'};}
  if(claim!==true)return closed('APPROVAL_CONSUMED_NO_RETRY');
  if(Date.now()>=cutoff){const r=closed('APPROVAL_EXPIRED_AFTER_CLAIM_NO_SEND');try{await store.finish(a.approvalId,r);}catch{}return r;}
  const transportStartedAt=Date.now();let result,timer;const controller=new AbortController();
  const unknown=(reason,httpStatus=null)=>({...base(),status:'UNKNOWN_STOP_NO_RETRY',reason,http_status:httpStatus,request_attempts:1,usage:'UNKNOWN',output:null});
  const perform=async()=>{
   const res=await fetchImpl(ENDPOINT,{method:'POST',headers:{authorization:'Bearer '+credential,'content-type':'application/json'},body:JSON.stringify(requestForRun()),redirect:'manual',signal:controller.signal});
   if(res.status!==200||res.redirected){await res.body?.cancel();return unknown('HTTP_OR_REDIRECT_REJECTED',res.status);}
   const length=Number(res.headers.get('content-length'));if(Number.isFinite(length)&&length>32768){await res.body?.cancel();return unknown('RESPONSE_SIZE_EXCEEDED',res.status);}
   const reader=res.body?.getReader();if(!reader)return unknown('EMPTY_RESPONSE',res.status);let size=0,chunks=[];
   try{while(true){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>32768){await reader.cancel();return unknown('RESPONSE_SIZE_EXCEEDED',res.status);}chunks.push(r.value);}}finally{reader.releaseLock();}
   const bytes=new Uint8Array(size);let pos=0;for(const c of chunks){bytes.set(c,pos);pos+=c.length;}let d;try{d=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{return unknown('INVALID_RESPONSE_JSON',res.status);}
   if(JSON.stringify(d).includes(credential))return unknown('SECRET_ECHO_REJECTED',res.status);
   const c=d?.choices?.[0],u=d?.usage;
   // Allowlisted diagnostics only, after complete response secret-echo rejection.
   const safeText=(v,max)=>typeof v==='string'&&v.length<=max&&/^[A-Za-z0-9_./:-]+$/.test(v)?v:null;
   const boundedInteger=v=>Number.isSafeInteger(v)&&v>=0&&v<=1000000000;
   const reportedUsage=u&&['prompt_tokens','completion_tokens','total_tokens'].every(k=>boundedInteger(u[k]))?{prompt_tokens:u.prompt_tokens,completion_tokens:u.completion_tokens,total_tokens:u.total_tokens}:null;
   const diagnostics={response_model:safeText(d?.model,128),model_matches:d?.model===MODEL,object_matches:d?.object==='chat.completion',service_tier:d?.service_tier===undefined?'ABSENT':d.service_tier===null?'NULL':['default','auto','flex','priority','scale','over-limit','no-limit'].includes(d.service_tier)?d.service_tier:'OTHER',response_id:safeText(d?.id,200),created_valid:Number.isSafeInteger(d?.created)&&d.created>0,choices_count:Array.isArray(d?.choices)?d.choices.length:null,choice_index:boundedInteger(c?.index)?c.index:null,role_matches:c?.message?.role==='assistant',finish_reason:['stop','length','tool_calls','content_filter','function_call'].includes(c?.finish_reason)?c.finish_reason:'OTHER_OR_ABSENT',content_type:c?.message?.content===null?'null':typeof c?.message?.content,content_utf8_bytes:typeof c?.message?.content==='string'?new TextEncoder().encode(c.message.content).length:null,content_nonempty:typeof c?.message?.content==='string'&&!!c.message.content.trim(),reasoning_present:typeof c?.message?.reasoning_content==='string'&&c.message.reasoning_content.length>0,reported_usage:reportedUsage,reported_usage_scope:'PROVIDER_REPORTED_UNVALIDATED_RESPONSE_NOT_INVOICE'};
   const rejected=reason=>({...unknown(reason,res.status),response_body_bytes:size,response_diagnostics:diagnostics,...(reportedUsage?{reported_usage:reportedUsage,reported_usage_cost_estimate_usd:(reportedUsage.prompt_tokens*0.06+reportedUsage.completion_tokens*0.24)/1000000,cost_scope:'UNVALIDATED_PROVIDER_REPORTED_USAGE_NOT_INVOICE'}:{})});
   if(d.model!==MODEL||d.object!=='chat.completion'||(d.service_tier!=null&&d.service_tier!=='default')||typeof d.id!=='string'||!/^[A-Za-z0-9_.:-]{1,200}$/.test(d.id)||!Number.isSafeInteger(d.created)||d.created<=0||!Array.isArray(d.choices)||d.choices.length!==1||c.index!==0||c.message?.role!=='assistant'||typeof c.message.content!=='string'||!c.message.content.trim()||new TextEncoder().encode(c.message.content).length>4096||!['stop','length'].includes(c.finish_reason))return rejected('OUTPUT_BINDING_INVALID');
   if(!u||!['prompt_tokens','completion_tokens','total_tokens'].every(k=>Number.isSafeInteger(u[k])&&u[k]>=0)||u.prompt_tokens>1024||u.completion_tokens>maxOutputTokens||u.total_tokens!==u.prompt_tokens+u.completion_tokens)return rejected('USAGE_UNCONFIRMED');
   return {...base(),status:d.service_tier==='default'?'RESPONSE_VALIDATED':'RESPONSE_RECEIVED_TIER_UNKNOWN',requested_service_tier:'default',reported_service_tier:d.service_tier??null,service_tier_verification:d.service_tier==='default'?'PROVIDER_REPORTED_DEFAULT_NOT_INVOICE':'UNREPORTED_NOT_CONFIRMED_DEFAULT',http_status:200,request_input_utf8_bytes:new TextEncoder().encode(prompt).length,request_json_bytes:new TextEncoder().encode(JSON.stringify(requestForRun())).length,response_body_bytes:size,output_utf8_bytes:new TextEncoder().encode(c.message.content).length,estimated_cost_usd:(u.prompt_tokens*0.06+u.completion_tokens*0.24)/1000000,cost_scope:d.service_tier==='default'?'CALCULATED_FROM_REPORTED_USAGE_NOT_INVOICE':'STANDARD_RATE_ESTIMATE_TIER_UNCONFIRMED_NOT_INVOICE',actual_model_calls:testTransport?0:1,request_attempts:1,model:d.model,response_id:d.id,input_sha256:a.inputHash,output:c.message.content,finish_reason:c.finish_reason,usage:{prompt_tokens:u.prompt_tokens,completion_tokens:u.completion_tokens,total_tokens:u.total_tokens},billing:'UNKNOWN_NOT_INVOICE'};
  };
  try{result=await Promise.race([perform(),new Promise(resolve=>{timer=setTimeout(()=>{controller.abort();resolve(unknown('DEADLINE_OUTCOME_UNCERTAIN'));},deadlineMs);})]);}catch{result=unknown('TRANSPORT_OUTCOME_UNCERTAIN');}finally{clearTimeout(timer);controller.abort();}
  result={...result,observed_transport_validation_ms:Date.now()-transportStartedAt,timing_scope:'SERVER_FETCH_AND_VALIDATION_NOT_FULL_WORKFLOW_OR_CPU'};
  try{if(await store.finish(a.approvalId,result)!==true)return unknown('EVIDENCE_COMMIT_UNCONFIRMED');}catch{return unknown('EVIDENCE_COMMIT_UNCONFIRMED');}
  return result;
 }};
}
