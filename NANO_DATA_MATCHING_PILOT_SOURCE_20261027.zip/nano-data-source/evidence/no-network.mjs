// Explicit process-level test safety boundary; no production code imports this.
globalThis.fetch=async()=>{throw Error('OFFLINE_TEST_NETWORK_FORBIDDEN');};
