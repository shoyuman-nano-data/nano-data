# Official access and timing reference

Read on October27,2026 from the primary organizer pages:

- https://nebiusglobalaihackathon.devpost.com/rules — Testing section, lines213–215; dates lines98–100.
- https://nebiusglobalaihackathon.devpost.com/details/dates — Schedule, lines93–97.

Testing access is required free of charge and without restrictions until judging ends. The finite5-grant/20-call proposal is therefore a pilot only; this job does not certify it as final judging compliance. No organizer exception was obtained.

Submission deadline: October30,2026 10:00PDT = October30 21:00Dubai. Judging: December1 09:00PST–December15 12:00PST = December1 21:00–December16 00:00Dubai. Operational dates remain PENDING until specifically authorized. The current owner's October27 internal execution cutoff is separate.
