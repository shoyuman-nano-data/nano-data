# NANO DATA — source-linked AI handoff prototype

Keep the source. Carry the purpose. Continue the work.

This source retains the original record, purpose, reason and next action; produces a compact CORE; allows a separately reviewed receiver step; and saves source-linked results for inspection. NVIDIA Nemotron 3 Nano 30B A3B is called through the Nebius Token Factory API from the server, never with a browser-exposed key. This is a prototype, not evidence of lossless compression or general superiority.

## Source identity and status (27 October 2026)

`worker.mjs` SHA-256: `b713c01d5da5e73507fe5a967c1f1b05894adff4d9943ca82da088b7a8e96421`.
This is the exact runtime bundle in the recorded 15:46:49 UTC pilot deployment, version `55f4eab8-6e67-42bc-9b36-c47087755cbb`, rather than the older C3 bundle. Deployment evidence is operator-reported and recorded in the project ledger; this package is not a fresh extraction from the host. Runtime source/assets are unchanged from that local deployed source. Documentation and packaging are updated. No external publication or final submission is implied.

A dated, fail-closed pilot bridge remains in the code to preserve reproducibility. Its campaign/policy labels, public hostname and 2026-10-27 18:00 UTC cutoff are nonsensitive constants, not usable access codes or authority to call a model. It is not a reusable production configuration. Do not enable or widen it for another deployment. New installations should use the isolated judge router with their own dedicated server-side key and DB, leaving `JUDGE_TRIAL_PILOT_BRIDGE` unset.

## Reproduce offline

Use Node 24 or later. Tests use synthetic credentials, local SQLite and injected model transports, not real provider requests.

```sh
npm test
npm run test:bundle
npm run test:judge-bundle
# Build dependency installation requires network and runs esbuild's install script:
npm ci
npm run build
```

`package-lock.json` pins esbuild 0.28.2. The generated worker has no npm runtime dependency. No node_modules, authentication state, hosting config, database/account identifiers, private code/hash or enabled policy is shipped. MIT license and third-party notices are included.

## Hosted setup boundary

The runtime targets Cloudflare Workers with D1, not a standalone Node HTTP listener. `build.mjs` embeds static assets. `/workflow` is the original/source/CORE/receiver review screen; `/judge` is the isolated trial screen; `/seed` is diagnostic. Neither loading a screen nor reloading saved results should start model execution.

For an owner installation, bind a fresh `JUDGE_DB`, apply `schema.sql`, then migrations `0003_nebius_once.sql` and `0004_handoff_product.sql`. Configure the exact HTTPS `JUDGE_APP_ORIGIN`, server-only `JUDGE_ACCESS_KEY` and ISO `JUDGE_ACCESS_EXPIRES_AT`. `.env.example` is an inventory, not an auto-loaded file. Provider execution remains disabled unless the appropriate explicit server-side policy is supplied. Set `NEBIUS_API_KEY` only through the host's secret store. Do not copy historical policy identifiers as authorization.

For isolated judge setup, see `JUDGE_TRIAL_DESIGN_HISTORY.md` for routes, session/grant accounting and schema details. Bind a separate `JUDGE_TRIAL_DB`, exact HTTPS `JUDGE_TRIAL_APP_ORIGIN`, dedicated server-only `JUDGE_TRIAL_PROVIDER_KEY`, and an explicitly reviewed `JUDGE_TRIAL_POLICY_JSON`. Schema 0005 plus the validated local SQLite migration helper for 0006 can reproduce the data model locally. The migration helper is NOT a production D1 deployment command. No live database bootstrap or usable grant is bundled. `release/judge-production.disabled.json` is a disabled test fixture, not the dated pilot's live settings.

This package is runnable offline as supplied. Public hosted inference still requires separate operator provisioning, fresh access verification and an agreed judging-period access/cost contract; it must not be advertised as a turnkey public judge service.

## Evidence limits

A historical synthetic source-to-CORE-to-receiver trial and saved reload exist. The dated pilot deployment itself was recorded with zero real pilot model calls at the reviewed checkpoint. Offline test passes are not model-quality results. Finite pilot quotas and expiry do not meet or prove unrestricted final judging access. New sessions do not restore old session bodies. Retention time is not proof of physical deletion; no purge scheduler is claimed. Costs are estimates, not billing hard caps.
