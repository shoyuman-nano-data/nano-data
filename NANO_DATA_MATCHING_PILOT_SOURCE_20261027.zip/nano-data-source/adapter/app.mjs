import {createJudgeTrialRouter,isJudgeTrialPath} from './judge-trial.mjs';
import {createSeedChain} from './seed-chain.mjs';
import {createHandoffStore} from './handoff-store.mjs';
import {createProviderAttempt} from './provider.mjs';
import {createProviderStore} from './provider-store.mjs';
import judgeBrief from '../content/judge-brief.json' with {type:'json'};
import {createLocalHarness} from './worker.mjs';
import {hash} from './core.mjs';
const TEST_KEY='LOCAL-ONLY-PUBLIC-TEST-KEY-NOT-A-REAL-SECRET-0001';
const response=(data,status=200,headers={})=>Response.json(data,{status,headers:{'cache-control':'no-store',...headers}});
const equal=(a,b)=>{if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;};
async function readBody(request,maxBytes=512){const reader=request.body?.getReader();let size=0,parts=[];if(reader){try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>maxBytes){await reader.cancel();throw Error('REQUEST_TOO_LARGE');}parts.push(value);}}finally{reader.releaseLock();}}const bytes=new Uint8Array(size);let i=0;for(const p of parts){bytes.set(p,i);i+=p.length;}return new TextDecoder('utf-8',{fatal:true}).decode(bytes);}
export function createApp({providerFetch=globalThis.fetch}={}){
 const localTesting=false;
 const trialRouter=createJudgeTrialRouter({providerFetch});
 return {async fetch(request,env){
  const trialUrl=new URL(request.url);
  if(isJudgeTrialPath(trialUrl.pathname))return trialRouter.fetch(request,env);
  const url=new URL(request.url),origin=localTesting?'http://127.0.0.1:8787':env.JUDGE_APP_ORIGIN;
  const cookieName=localTesting?'nano_local_session':'__Host-nano_judge_session';
  const key=localTesting?TEST_KEY:env.JUDGE_ACCESS_KEY;
  const mode=localTesting?'LOCAL_TEST':'JUDGE_FIXED_TEST_ONLY';
  const security={'content-security-policy':"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",'x-content-type-options':'nosniff','referrer-policy':'no-referrer','permissions-policy':'camera=(), microphone=(), geolocation=()'};
  const seal=r=>{const h=new Headers(r.headers);Object.entries(security).forEach(([k,v])=>h.set(k,v));h.set('cache-control','no-store');return new Response(r.body,{status:r.status,headers:h});};
  const fail=(reason,status=403)=>seal(response({status:'CLOSED',reason,receipt:null},status));
  try{
   if(!origin||url.origin!==origin||(!localTesting&&!origin.startsWith('https://')))return fail('ORIGIN_NOT_CONFIGURED');
   // Assets are only non-sensitive UI shell; all computation requires a session.
   if(request.method==='GET'&&['/','/index.html','/app.js','/style.css','/seed','/seed.js','/workflow','/workflow.js'].includes(url.pathname)&&!url.search)return seal(await env.ASSETS.fetch(request));
   if(!key||typeof key!=='string'||(!localTesting&&(!/^[A-Za-z0-9_-]{43}$/.test(key)||key===TEST_KEY||/^(LOCAL|TEST|REPLACE|CHANGEME)/i.test(key))))return fail('JUDGE_CREDENTIAL_NOT_CONFIGURED',503);
   const cutoff=Date.parse(env.JUDGE_ACCESS_EXPIRES_AT);
   if(typeof env.JUDGE_ACCESS_EXPIRES_AT!=='string'||!Number.isFinite(cutoff)||new Date(cutoff).toISOString()!==env.JUDGE_ACCESS_EXPIRES_AT||Date.now()>=cutoff)return fail('JUDGE_ACCESS_EXPIRED_OR_NOT_CONFIGURED',403);
   if(!env.JUDGE_DB)return fail('DATABASE_NOT_CONFIGURED',503);
   const db=env.JUDGE_DB.withSession('first-primary'),credentialHash=await hash(key);
   const cookie=(request.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1);
   let session=null;
   if(cookie&&/^[a-f0-9]{64}$/.test(cookie))session=await db.prepare('SELECT token_hash,expires_at,credential_hash FROM judge_sessions WHERE token_hash=?').bind(await hash(cookie)).first();
   const authenticated=!!session&&session.expires_at>Date.now()&&equal(session.credential_hash,credentialHash);
   if(url.pathname==='/_auth/session'&&request.method==='GET'&&!url.search)return seal(response({authenticated,mode,provider_enabled:authenticated&&env.NEBIUS_ENABLED==='ONE_APPROVED_CALL'&&typeof env.NEBIUS_API_KEY==='string'&&typeof env.NEBIUS_APPROVAL_JSON==='string',access_expires_at:env.JUDGE_ACCESS_EXPIRES_AT,...(localTesting?{developmentAccessKey:TEST_KEY}:{})}));
   if(request.method!=='POST'||request.headers.get('origin')!==origin||request.headers.get('content-type')!=='application/json'||url.search)return fail('REQUEST_BOUNDARY_CLOSED');
   if(url.pathname==='/_auth/login'){
    const raw=await readBody(request),body=JSON.parse(raw);if(!body||Object.keys(body).length!==1||typeof body.passphrase!=='string'||JSON.stringify(body)!==raw)return fail('INVALID_LOGIN',400);
    // Global 15-minute window, atomic admission, bounded table cleanup. This
    // prevents unbounded guessing but allows denial of login by outsiders.
    const window=Math.floor(Date.now()/900000);
    await db.prepare('DELETE FROM judge_login_windows WHERE window<?').bind(window-1).run();
    const admission=await db.prepare('INSERT INTO judge_login_windows(window,attempts) VALUES(?,1) ON CONFLICT(window) DO UPDATE SET attempts=attempts+1 RETURNING attempts').bind(window).first();
    if(admission.attempts>10)return fail('LOGIN_RATE_LIMITED',429);
    if(!equal(await hash(body.passphrase),credentialHash))return fail('INVALID_LOGIN',401);
    const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');
    await db.batch([db.prepare('DELETE FROM judge_sessions WHERE expires_at<=? OR credential_hash<>?').bind(Date.now(),credentialHash),db.prepare('DELETE FROM judge_login_windows WHERE window<?').bind(window-1),db.prepare('INSERT INTO judge_sessions(token_hash,expires_at,credential_hash) VALUES(?,?,?)').bind(await hash(token),Math.min(Date.now()+8*3600000,cutoff),credentialHash)]);
    return seal(response({authenticated:true,mode,provider_enabled:env.NEBIUS_ENABLED==='ONE_APPROVED_CALL'&&typeof env.NEBIUS_API_KEY==='string'&&typeof env.NEBIUS_APPROVAL_JSON==='string'},200,{'set-cookie':`${cookieName}=${token}; HttpOnly; ${localTesting?'':'Secure; '}SameSite=Strict; Path=/; Max-Age=${Math.max(0,Math.min(28800,Math.floor((cutoff-Date.now())/1000)))}`}));
   }
   if(url.pathname==='/_auth/logout'){
    if(session)await db.prepare('DELETE FROM judge_sessions WHERE token_hash=?').bind(session.token_hash).run();
    return seal(response({authenticated:false},200,{'set-cookie':`${cookieName}=; HttpOnly; ${localTesting?'':'Secure; '}SameSite=Strict; Path=/; Max-Age=0`}));
   }
   if(!authenticated)return fail('JUDGE_LOGIN_REQUIRED',401);
   if(['/_api/seed/produce','/_api/seed/receive','/_api/seed/read'].includes(url.pathname)){
    const raw=await readBody(request,2048),body=JSON.parse(raw),action=url.pathname.split('/').at(-1);
    const keys=action==='produce'?['id','original','purpose','reason','nextAction']:action==='receive'?['id','parentId']:['id'];
    if(!body||Array.isArray(body)||Object.keys(body).length!==keys.length||!keys.every(k=>Object.hasOwn(body,k))||JSON.stringify(body)!==raw)return fail('INVALID_SEED_REQUEST',400);
    let policy={};try{policy=JSON.parse(env.HANDOFF_PRODUCT_POLICY_JSON||'{}');}catch{return fail('PRODUCT_POLICY_INVALID',503);}
    const service=createSeedChain({store:createHandoffStore(env.JUDGE_DB),policy,credential:env.NEBIUS_API_KEY,fetchImpl:providerFetch});
    const result=await service[action]({...body,owner:'judge:'+session.token_hash});
    return seal(response(result,result.status==='SAVED'?200:422));
   }
   if(url.pathname==='/_api/judge_brief'){const raw=await readBody(request);if(raw!=='{}')return fail('INVALID_BRIEF_REQUEST',400);return seal(response({schema:'NANO_JUDGE_FIXED_TEST_V1',access:'JUDGE_SESSION_FIXED_TEST_ONLY',...judgeBrief}));}
   if(['/_api/provider_once/run','/_api/provider_once/evidence'].includes(url.pathname)){
    const raw=await readBody(request);if(raw!=='{}')return fail('NO_CLIENT_PROVIDER_INPUT',400);
    if(env.NEBIUS_ENABLED!=='ONE_APPROVED_CALL'||typeof env.NEBIUS_APPROVAL_JSON!=='string')return fail('REAL_AI_NOT_ENABLED',503);
    let approval;try{approval=JSON.parse(env.NEBIUS_APPROVAL_JSON);}catch{return fail('PROVIDER_APPROVAL_NOT_CONFIGURED',503);}
    if(!approval||typeof approval.approvalId!=='string'||!/^NEBIUS_[A-Z0-9_]{1,96}$/.test(approval.approvalId))return fail('PROVIDER_APPROVAL_NOT_CONFIGURED',503);
    const providerStore=createProviderStore(env.JUDGE_DB);
    if(url.pathname.endsWith('/evidence'))return seal(response({scope:'PERSISTED_EVIDENCE_CHECK_SCOPE',record:await providerStore.read(approval.approvalId)}));
    // This protected judge-role route consumes ONE global server approval, not one per session.
    // No request field can mint another approval or supply a prompt/key/model.
    const run=createProviderAttempt({store:providerStore,serverApproval:approval,credential:env.NEBIUS_API_KEY,fetchImpl:providerFetch});
    const evidence=await run.run({ownerAuthorized:true});
    return seal(response(evidence,['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(evidence.status)?200:422));
   }
   const handle=createLocalHarness({origin,authorize:async()=> 'judge:'+session.token_hash});
   return seal(await handle(request,{DB:env.JUDGE_DB}));
  }catch{return fail('REQUEST_OR_STORAGE_CLOSED',422);}
 }};
}
export default createApp();
