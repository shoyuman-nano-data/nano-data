import {parentPort,workerData} from 'node:worker_threads';
import {LocalCostD1,NOW,runId} from './judge-cost-fixture.mjs';
import {createJudgeCostLedger} from '../adapter/judge-cost-guard.mjs';
const db=new LocalCostD1(workerData.path,{initialize:false});
const gate=new Int32Array(workerData.gate);parentPort.postMessage({ready:true});Atomics.wait(gate,0,0);
try{const result=await createJudgeCostLedger(db,{now:()=>NOW}).reserve({runId:runId(workerData.id),requestSha256:'a'.repeat(64),maxOutputTokens:512});parentPort.postMessage({accepted:result?.accepted===true});}
catch(e){parentPort.postMessage({error:e.message});}finally{db.close();}
