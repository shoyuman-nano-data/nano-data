import {PIN,compute,verify,hash} from './core.mjs';
import {D1Store} from './d1.mjs';
const ID=/^JDG_[A-F0-9]{32}$/;
const reply=(x,status=200)=>Response.json({schema:'H12_CF_FIXED_JDG_LOCAL_PROTOTYPE_V1',mode:'LOCAL_CHAIN_NOT_AI_OUTPUT',actual_model_calls:0,automatic_retry:false,...x},{status,headers:{'cache-control':'no-store'}});
async function digestFiles(files){return Object.fromEntries(await Promise.all(Object.entries(files).sort().map(async([n,b])=>[n,{bytes:b.length,sha256:await hash(b)}])));}
// Default entry ALWAYS refuses access. No env/header magic enables local auth.
export default {fetch:async()=>reply({status:'CLOSED',reason:'PRODUCTION_AUTH_NOT_IMPLEMENTED',receipt:null},403)};
// TEST HARNESS ONLY dependency injection. This is not an authentication service.
export function createLocalHarness({authorize,origin='https://local.invalid',afterClaim=async()=>{}}){
 return async (request,env)=>{
 let attemptId,claimed=false;
 try {
  const owner=await authorize(request);if(typeof owner!=='string'||!owner) return reply({status:'CLOSED',reason:'UNAUTHORIZED',receipt:null},403);
  const url=new URL(request.url);
  if(url.origin!==origin||request.headers.get('origin')!==origin||request.headers.get('x-h12-local-intent')!=='PRIVATE_STATIC_FAKE_V1') throw Error('BOUNDARY_CLOSED');
  const action=url.pathname.slice('/_api/fixed_e0_chain/'.length);
  if(!url.pathname.startsWith('/_api/fixed_e0_chain/')||!['prepare','run','reload'].includes(action)||url.search||request.method!=='POST')throw Error('INVALID_ACTION');
  if(request.headers.get('content-type')!=='application/json')throw Error('JSON_REQUIRED');
  const reader=request.body?.getReader();let chunks=[],size=0; if(reader){try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>512){await reader.cancel();throw Error('REQUEST_TOO_LARGE');}chunks.push(value);}}finally{reader.releaseLock();}} const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;} const raw=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  const input=JSON.parse(raw),key=action==='prepare'?'job':'attemptId';
  // Single-key lexical canonical form also rejects duplicate JSON keys.
  if(!input||Array.isArray(input)||Object.keys(input).length!==1||!Object.hasOwn(input,key)||JSON.stringify(input)!==raw)throw Error('INVALID_INPUT');
  const store=new D1Store(env.DB);
  if(action==='prepare'){
   const job=input.job;if(!Object.hasOwn(PIN,job))throw Error('UNKNOWN_JOB');
   await compute(job); // purpose-authored fixed synthetic fixture only
   const existing=await store.findPreparedJob(job,owner);
   if(existing){const state=await store.load(existing.attempt);return reply({status:state.claim?'EXISTING_ATTEMPT':'PREPARED',attemptId:existing.attempt,job});}
   attemptId='JDG_'+crypto.randomUUID().replaceAll('-','').toUpperCase();
   await store.prepare(attemptId,job,owner);
   return reply({status:'PREPARED',attemptId,job});
  }
  attemptId=input.attemptId;if(typeof attemptId!=='string'||!ID.test(attemptId))throw Error('INVALID_ATTEMPT');
  const expectation=await store.expectation(attemptId,owner);if(!expectation)throw Error('CALLER_EXPECTATION_CLOSED');
  const job=expectation.job;
  if(action==='run'){
   const token=crypto.randomUUID();try{await store.claim(attemptId,job,token);claimed=true;}catch{throw Error('DUPLICATE_OR_UNCERTAIN_CLAIM_STOP_NO_RETRY');}
   await afterClaim(attemptId);
   const {files}=await compute(job);await verify(job,files);
   const commit={schema:'JUDGE_SYNTHETIC_SUCCESS_COMMIT_V1',attemptId,job,token,record_files:await digestFiles(files)};
   await store.commit(attemptId,files,commit);
  }
  const saved=await store.load(attemptId);
  if(!saved.claim||!saved.commit)throw Error('MISSING_CLAIM_OR_COMMIT');
  const expected={schema:'JUDGE_SYNTHETIC_SUCCESS_COMMIT_V1',attemptId,job,token:saved.claim.token,record_files:await digestFiles(saved.files)};
  if(saved.claim.job!==job||JSON.stringify(saved.commit)!==JSON.stringify(expected))throw Error('SUCCESS_COMMIT_MISMATCH');
  const verified=await verify(job,saved.files);
  return reply({status:action==='run'?'SAVED_LOCAL_FRESH_VERIFIED':'RELOADED_LOCAL_FRESH_VERIFIED',attemptId,job,verified,receipt:JSON.parse(new TextDecoder().decode(saved.files['receipt.json'])),driver_runs_this_operation:action==='run'?1:0,verification_scope:'JS_RECOMPUTATION_NOT_FRESH_PYTHON_PROCESS'});
 }catch(e){return reply({status:claimed?'UNKNOWN_STOP_NO_RETRY':'CLOSED',reason:/^[A-Z0-9_]+$/.test(e.message)?e.message:'INVALID_OR_UNCERTAIN_STATE_STOP_NO_RETRY',attemptId,receipt:null,verified:null},422);}
 };
}
