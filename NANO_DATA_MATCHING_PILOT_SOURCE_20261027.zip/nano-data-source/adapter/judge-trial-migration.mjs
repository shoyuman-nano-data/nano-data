// Local SQLite migration helper only. No grant issuance, provider access or live DB adapter.
import {readFileSync} from 'node:fs';
const runID=v=>typeof v==='string'&&/^HOF_[a-f0-9]{32}$/.test(v);
const legacyColumns=['id','campaign_id','grant_id','session_id','stage','parent_id','source','input_hash','policy_revision','created_at','evidence_json','finished_at','purged_at'];
const rowSnapshot=rows=>JSON.stringify(rows.map(r=>legacyColumns.map(n=>r[n])));
const counts=rows=>({runs:rows.length,campaigns:Object.fromEntries([...new Set(rows.map(r=>r.campaign_id))].sort().map(id=>[id,rows.filter(r=>r.campaign_id===id).length])),grants:Object.fromEntries([...new Set(rows.map(r=>r.grant_id))].sort().map(id=>[id,rows.filter(r=>r.grant_id===id).length])),purgedTombstones:rows.filter(r=>r.purged_at!==null).length});
export function migrateJudgeTrialCases(sql,{randomBytes}={}){
 if(!sql||typeof sql.exec!=='function'||typeof sql.prepare!=='function')throw Error('LOCAL_SQLITE_REQUIRED');
 sql.exec('BEGIN IMMEDIATE');
 try{
  const columns=sql.prepare('PRAGMA table_info(trial_runs)').all();
  if(!columns.length)throw Error('TRIAL_LEGACY_SCHEMA_REQUIRED');
  if(columns.some(c=>c.name==='case_id')){
   if(!sql.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='trial_cases'").get())throw Error('TRIAL_PARTIAL_MIGRATION');
   const broken=sql.prepare("SELECT COUNT(*) n FROM trial_runs r LEFT JOIN trial_cases k ON k.case_id=r.case_id AND k.campaign_id=r.campaign_id AND k.grant_id=r.grant_id AND k.session_id=r.session_id WHERE k.case_id IS NULL OR (r.stage='produce' AND (r.id<>k.case_id OR r.parent_id IS NOT NULL)) OR (r.stage='receive' AND (r.id<>k.receiver_id OR r.parent_id<>k.case_id))").get().n;
   if(broken||sql.prepare('PRAGMA foreign_key_check').all().length)throw Error('TRIAL_MIGRATED_SCOPE_INVALID');
   const rows=sql.prepare('SELECT * FROM trial_runs ORDER BY id').all(),cases=sql.prepare('SELECT COUNT(*) n FROM trial_cases').get().n;
   sql.exec('COMMIT');return {status:'ALREADY_MIGRATED',...counts(rows),cases};
  }
  if(sql.prepare("SELECT 1 FROM sqlite_master WHERE name IN('trial_cases','trial_runs_cases_new')").get())throw Error('TRIAL_PARTIAL_MIGRATION');
  const rows=sql.prepare('SELECT * FROM trial_runs ORDER BY id').all();
  const before=rowSnapshot(rows),beforeCounts=counts(rows),byID=new Map(rows.map(r=>[r.id,r]));
  const parents=new Map(),receivers=new Map(),used=new Set(rows.map(r=>r.id));
  for(const r of rows){
   if(!runID(r.id)||!['produce','receive'].includes(r.stage))throw Error('TRIAL_LEGACY_ID_OR_STAGE');
   const binding=sql.prepare('SELECT s.grant_id,g.campaign_id FROM trial_sessions s JOIN trial_grants g ON g.id=s.grant_id JOIN trial_campaigns c ON c.id=g.campaign_id WHERE s.id=?').get(r.session_id);
   if(!binding||binding.grant_id!==r.grant_id||binding.campaign_id!==r.campaign_id)throw Error('TRIAL_LEGACY_SCOPE_INVALID');
   if(r.stage==='produce'){
    if(r.parent_id!==null)throw Error('TRIAL_LEGACY_PRODUCER_PARENT');
    parents.set(r.id,r);
   }
  }
  for(const r of rows.filter(r=>r.stage==='receive')){
   const p=byID.get(r.parent_id);
   if(!p||p.stage!=='produce'||p.id===r.id||p.campaign_id!==r.campaign_id||p.grant_id!==r.grant_id||p.session_id!==r.session_id)throw Error('TRIAL_LEGACY_RECEIVER_SCOPE');
   if(receivers.has(p.id))throw Error('TRIAL_LEGACY_DUPLICATE_RECEIVER');
   receivers.set(p.id,r.id);
  }
  const allocate=()=>{
   if(typeof randomBytes!=='function')throw Error('LOCAL_MIGRATION_RANDOM_REQUIRED');
   for(let attempt=0;attempt<32;attempt++){
    const bytes=randomBytes(16);if(!(bytes instanceof Uint8Array)||bytes.length!==16)throw Error('LOCAL_MIGRATION_RANDOM_INVALID');
    const id='HOF_'+[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
    if(!used.has(id)){used.add(id);return id;}
   }
   throw Error('TRIAL_MIGRATION_ID_COLLISION');
  };
  sql.exec('CREATE TEMP TABLE _trial_case_migration(case_id TEXT PRIMARY KEY,receiver_id TEXT UNIQUE,campaign_id TEXT,grant_id TEXT,session_id TEXT,creation_key TEXT,created_at INTEGER)');
  const stage=sql.prepare('INSERT INTO temp._trial_case_migration VALUES(?,?,?,?,?,?,?)');
  for(const p of parents.values())stage.run(p.id,receivers.get(p.id)||allocate(),p.campaign_id,p.grant_id,p.session_id,'LEGACY_'+p.id,p.created_at);
  sql.exec(readFileSync(new URL('../migrations/0006_judge_trial_cases.sql',import.meta.url),'utf8'));
  const after=sql.prepare('SELECT * FROM trial_runs ORDER BY id').all();
  if(rowSnapshot(after)!==before||JSON.stringify(counts(after))!==JSON.stringify(beforeCounts))throw Error('TRIAL_MIGRATION_DATA_CHANGED');
  if(sql.prepare('PRAGMA foreign_key_check').all().length)throw Error('TRIAL_MIGRATION_FOREIGN_KEY');
  sql.exec('DROP TABLE temp._trial_case_migration');
  sql.exec('COMMIT');return {status:'MIGRATED',...beforeCounts,cases:parents.size};
 }catch(error){sql.exec('ROLLBACK');throw error;}
}
