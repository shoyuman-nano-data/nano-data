const $=id=>document.getElementById(id);
const STORAGE='nano-judge-new-synthetic-attempt-v1';
const validJob=x=>['A_REPORT','B_REPORT','B_SOURCE'].includes(x);
const validId=x=>typeof x==='string'&&/^JDG_[A-F0-9]{32}$/.test(x);
let attemptId=null,prepared=false,busy=false,epoch=0,authenticated=false;
try{const saved=localStorage.getItem(STORAGE);if(validId(saved)){attemptId=saved;const meta=JSON.parse(localStorage.getItem(STORAGE+'-job')||'null');$('job').value=meta?.attemptId===saved&&validJob(meta.job)?meta.job:'';}}catch{if(attemptId)$('job').value='';}
let realConsumed=false,realAvailable=false;
const controls=['real-run','real-reload','login','logout','prepare','run','reload','job','passphrase'];
function sync(){$('real-test-card').hidden=!authenticated;$('login-panel').hidden=authenticated;$('login-form').hidden=authenticated;for(const id of controls)$(id).disabled=busy;for(const id of ['prepare','job','logout'])$(id).disabled=busy||!authenticated;$('real-run').disabled=busy||!authenticated||!realAvailable||realConsumed;$('real-reload').disabled=busy||!authenticated||!realAvailable;$('prepare').disabled=busy||!authenticated||!validJob($('job').value);$('run').disabled=busy||!authenticated||!prepared||!attemptId;$('reload').disabled=busy||!authenticated||!attemptId;$('attempt').textContent=attemptId?`試行ID: ${attemptId}`:'試行はまだありません。';document.body.setAttribute('aria-busy',String(busy));}
function clearResult(){ $('result').hidden=true;$('result-summary').textContent='';$('facts').replaceChildren();$('details').textContent='';$('error').hidden=true;$('error').textContent=''; }
function saveAttempt(id,job){attemptId=id;if(!id){$('job').value='A_REPORT';updateJobNote();}if(id&&validJob(job))$('job').value=job;try{if(id){localStorage.setItem(STORAGE,id);if(validJob(job))localStorage.setItem(STORAGE+'-job',JSON.stringify({attemptId:id,job}));else localStorage.removeItem(STORAGE+'-job');}else{localStorage.removeItem(STORAGE);localStorage.removeItem(STORAGE+'-job');}}catch{}sync();}
function clearAuthentication(){realConsumed=false;realAvailable=false;$('real-answer').textContent='';$('real-details').textContent='';$('real-status').textContent='未確認 / Not checked';clearBrief();authenticated=false;prepared=false;clearResult();sync();}
function revealActions(){ sync();$('action-card').scrollIntoView?.({block:'start',behavior:'auto'}); }
function accessMessage(reason){
 if(reason==='JUDGE_ACCESS_EXPIRED_OR_NOT_CONFIGURED')return 'Access unavailable: contact the owner. / 利用期限が終了したか、接続設定が無効です。提供者に確認してください。再接続だけでは復旧しません。';
 if(reason==='INVALID_LOGIN')return 'Check the judge key. / 審査用キーを確認してください。本人用キーは使えません。';
 return 'Session ended: reconnect for a new trial. / セッションが終了しました。再接続すると新しい試用を始められます。以前のセッションの結果は復元できません。';
}
async function post(path,payload){if(path.startsWith('/_api/')&&!authenticated)throw Error('接続が必要です');const res=await fetch(path,{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json','x-h12-local-intent':'PRIVATE_STATIC_FAKE_V1'},body:JSON.stringify(payload),cache:'no-store',redirect:'error'});if(res.status===401||res.status===403){clearAuthentication();$('auth-status').textContent=accessMessage();}let data;try{data=await res.json();}catch{throw Error('応答を確認できません。状態は不明です。自動再試行はしません。');}if(!res.ok){if(res.status===401||res.status===403){const message=accessMessage(data.reason);$('auth-status').textContent=message;throw Error(message);}throw Error(data.reason||`HTTP ${res.status}`);}return data;}
async function operation(label,fn){if(busy)return;busy=true;const current=++epoch;clearResult();$('status').textContent=label;sync();try{await fn(current);}catch(e){if(current!==epoch)return;clearResult();$('status').textContent='完了を確認できませんでした。';$('error').hidden=false;$('error').textContent=`${e.message} — 以前の成功結果は表示していません。`; }finally{if(current===epoch){busy=false;sync();}}}
function updateJobNote(){$('job-note').textContent=!validJob($('job').value)?'保存ジョブは未確認です。保存結果を再検証するか、新しいジョブを選んでください。':$('job').value==='B_SOURCE'?'別需要の検証です。固定ソースのバイトを確認します。A/B報告検証とのコスト比較には使いません。':'A と B の報告検証は同じ需要です。ソースのバイト確認は行いません。';}
function show(data){if(!['SAVED_LOCAL_FRESH_VERIFIED','RELOADED_LOCAL_FRESH_VERIFIED'].includes(data.status)||data.attemptId!==attemptId||!['A_REPORT','B_REPORT','B_SOURCE'].includes(data.job)||!data.receipt||!data.verified)throw Error(data.reason||'期待した保存・再検証結果ではありません');saveAttempt(attemptId,data.job);updateJobNote();const r=data.receipt;const facts=[['Result / 結果',data.status.startsWith('SAVED')?'計算・保存・再検証済み':'保存結果を再検証済み'],['Job / ジョブ',data.job],['Input bytes / サイズ',`${r.payload_bytes} bytes`],['ソースのバイト確認',`${r.observed_local_source_reads_this_operation} 回 / ${r.observed_local_source_bytes_this_operation} bytes`],['Model calls / 呼出',`${r.actual_model_calls} 回`],['外部送信',r.actual_sent_bytes],['検証範囲','JavaScriptで再計算 / Python別プロセスではありません']];for(const [k,v] of facts){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=String(v);$('facts').append(dt,dd);}$('result-summary').textContent=typeof r.demo_text==='string'?r.demo_text:'Synthetic workflow result / 合成ワークフロー結果';$('details').textContent=JSON.stringify(data,null,2);$('result').hidden=false;$('status').textContent='検証が完了しました。';}

function clearBrief(){for(const id of ['judge-intro','judge-evidence'])$(id).hidden=true;for(const id of ['brief-title','brief-purpose','brief-problem','brief-version'])$(id).textContent='';for(const id of ['brief-guide','brief-evidence','brief-limits','brief-next'])$(id).replaceChildren();}
const briefText=value=>typeof value==='string'?value:JSON.stringify(value??'');
function briefList(id,rows){for(const row of rows){const li=document.createElement('li');li.textContent=briefText(row);$(id).append(li);}}
async function loadBrief(){
 const current=epoch;clearBrief();if(!authenticated)return;
 const data=await post('/_api/judge_brief',{});
 if(current!==epoch||!authenticated)return;
 if(!data||typeof data.schema!=='string'||!data.version||!Array.isArray(data.guide)||!Array.isArray(data.evidence)||!Array.isArray(data.limits)||!Array.isArray(data.next_updates))throw Error('プレビューの応答を確認できません');
 $('brief-title').textContent=briefText(data.title);$('brief-purpose').textContent=briefText(data.purpose);$('brief-problem').textContent=briefText(data.problem);
 briefList('brief-guide',data.guide);briefList('brief-limits',data.limits);briefList('brief-next',data.next_updates);
 for(const item of data.evidence){const article=document.createElement('article'),title=document.createElement('h3'),facts=document.createElement('dl');title.textContent=briefText(item.label);article.append(title);for(const [label,value] of [['Result / 結果',item.result],['検証の範囲',item.scope],['根拠',item.source],['確認日時',item.verified_at]]){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=briefText(value);facts.append(dt,dd);}article.append(facts);$('brief-evidence').append(article);}
 $('brief-version').textContent=`版: ${briefText(data.version)} / 更新日時: ${briefText(data.updated_at)} / 形式: ${briefText(data.schema)}`;
 $('judge-intro').hidden=false;$('judge-evidence').hidden=false;
}

$('login-form').addEventListener('submit',event=>{event.preventDefault();if(busy)return;const passphrase=$('passphrase').value;$('passphrase').value='';operation('接続を確認しています…',async()=>{clearAuthentication();const session=await post('/_auth/login',{passphrase});if(session.authenticated!==true)throw Error('認証完了を確認できません');saveAttempt(null);authenticated=true;realAvailable=session.provider_enabled===true;$('auth-status').textContent='接続済み / Connected';await loadBrief();revealActions();$('status').textContent='① Prepare / 準備から始めてください。';});});
$('logout').addEventListener('click',()=>{if(!authenticated||busy)return;operation('切断しています…',async()=>{clearAuthentication();saveAttempt(null);$('passphrase').value='';await post('/_auth/logout',{});$('auth-status').textContent='切断しました。';$('status').textContent='切断しました。以前のセッションの結果は開けません。再接続すると新しい試用を始められます。';});});
$('job').addEventListener('change',()=>{if(busy||!authenticated)return;epoch++;prepared=false;clearResult();updateJobNote();$('status').textContent='選んだジョブで新しい試行を準備してください。';sync();});
$('prepare').addEventListener('click',()=>{if(!authenticated||busy||!validJob($('job').value))return;operation('新しい試行を準備しています…',async()=>{prepared=false;const job=$('job').value;const data=await post('/_api/fixed_e0_chain/prepare',{job});if(!['PREPARED','EXISTING_ATTEMPT'].includes(data.status)||!validId(data.attemptId)||data.job!==job)throw Error(data.reason||'準備結果を確認できません');saveAttempt(data.attemptId,data.job);if(data.status==='EXISTING_ATTEMPT'){prepared=false;$('status').textContent='このジョブの試行は実行済みです。保存結果を再検証してください。';return;}prepared=true;$('status').textContent='準備できました。② Run and save / 保存を押してください。';});});
$('run').addEventListener('click',()=>{if(!authenticated||!prepared||!attemptId||busy)return;operation('固定データを計算・保存しています…',async()=>{prepared=false;const data=await post('/_api/fixed_e0_chain/run',{attemptId});show(data);});});
$('reload').addEventListener('click',()=>{if(!authenticated||!attemptId||busy)return;operation('保存結果を読み直して再検証しています…',async()=>{prepared=false;show(await post('/_api/fixed_e0_chain/reload',{attemptId}));});});
updateJobNote();sync();
if(attemptId)$('status').textContent='保存された試行IDがあります。接続後に「保存結果を再検証」を選べます。';

async function checkSession(){
 await operation('接続状態を確認しています…',async()=>{
  clearAuthentication();
  const res=await fetch('/_auth/session',{credentials:'same-origin',cache:'no-store',redirect:'error'});
  if(!res.ok){let reason;try{reason=(await res.json()).reason;}catch{}const message=(res.status===401||res.status===403)?accessMessage(reason):'接続状態を確認できません。しばらくしてからページを開き直してください。';$('auth-status').textContent=message;throw Error(message);}
  const data=await res.json();
  if(typeof data.authenticated!=='boolean')throw Error('セッション応答が不正です');
  authenticated=data.authenticated;realAvailable=data.provider_enabled===true;
  if(authenticated){await loadBrief();revealActions();}
  $('auth-status').textContent=data.authenticated?'接続済み / Connected':'未接続です。審査用アクセスキーを入力してください。';
  if(data.mode==='LOCAL_TEST'&&typeof data.developmentAccessKey==='string'){
   $('development-key').textContent=`ローカル試験専用キー（本番利用不可）: ${data.developmentAccessKey}`;
   $('development-key').hidden=false;
  }
  $('status').textContent=authenticated?(attemptId?'試行IDを復元しました。この審査セッションの保存結果を再検証できます。':'固定ジョブを選んで試行を準備してください。'):(attemptId?'試行IDを復元しました。接続後に保存結果を再検証できます。':'接続後に試行を準備してください。');
 });
}
checkSession();

function clearRealResult(){$('real-status').textContent='未確認 / Not checked';$('real-answer').textContent='';$('real-details').textContent='';}
function showReal(data){const result=data.record?.evidence??data;const scope=result.evidence_scope??data.scope??'UNKNOWN';const status=result.status??data.record?.status??'UNKNOWN';const label=status==='RESPONSE_VALIDATED'?(scope==='INJECTED_TRANSPORT_TEST_NOT_PROVIDER_EVIDENCE'?'TEST_ONLY / ローカル試験':'SUCCESS / provider応答確認'):status==='RESPONSE_RECEIVED_TIER_UNKNOWN'?(scope==='INJECTED_TRANSPORT_TEST_NOT_PROVIDER_EVIDENCE'?'TEST_ONLY / ローカル試験・料金区分未確認':'実AI応答あり・料金区分は未確認 / AI response; billing tier unconfirmed'):status==='NOT_RUN'?'NOT_RUN / 未実施':status;$('real-status').textContent=`${label} / ${scope}`;$('real-answer').textContent=typeof result.output==='string'?result.output:status==='NOT_RUN'?'まだ送信していません。 / No request recorded.':'出力は未確認です。成功・無課金とは扱いません。 / Outcome unknown.';$('real-details').textContent=JSON.stringify(data,null,2);}
$('real-run').addEventListener('click',()=>{if(!authenticated||!realAvailable||busy||realConsumed)return;realConsumed=true;clearRealResult();$('real-status').textContent='RUNNING / 実行中・再押下しないでください';operation('実AIテストを確認しています…',async()=>{try{const r=await post('/_api/provider_once/run',{});showReal(r);}catch(e){$('real-status').textContent='UNKNOWN / 結果未確認。保存証拠を確認してください。';throw e;}});});
$('real-reload').addEventListener('click',()=>{if(!authenticated||!realAvailable||busy)return;clearRealResult();operation('実AIの保存証拠を読みます…',async()=>{try{showReal(await post('/_api/provider_once/evidence',{}));}catch(e){$('real-status').textContent='UNKNOWN / 保存証拠を確認できません。';throw e;}});});
