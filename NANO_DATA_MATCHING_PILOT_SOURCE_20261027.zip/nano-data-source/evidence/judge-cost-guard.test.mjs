import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {Worker} from 'node:worker_threads';
import {createJudgeCostLedger,createJudgeCostGuard,reservationNano,validatePricingSnapshot,CEILING_NANO,COST_MODEL,JUDGING_END} from '../adapter/judge-cost-guard.mjs';
import {LocalCostD1,NOW,runId,request,pricing,policy,COST_ENDPOINT} from './judge-cost-fixture.mjs';

function setup(t,options={}){
 const db=new LocalCostD1(':memory:',options);t.after(()=>db.close());
 const ledger=createJudgeCostLedger(db,{now:()=>NOW});
 let calls=0;
 const providerFetch=async()=>{calls++;return new Response('synthetic response');};
 const guard=createJudgeCostGuard({ledger,providerFetch,readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 return {db,ledger,guard,calls:()=>calls};
}
const reserve=async(ledger,n=1,out=512)=>(await ledger.reserve({runId:runId(n),requestSha256:'a'.repeat(64),maxOutputTokens:out}))?.accepted===true;

test('integer reservation uses full context plus every requested output token',()=>{
 assert.equal(reservationNano(512),15851520);assert.equal(reservationNano(2048),16220160);
 assert.equal(Math.floor(CEILING_NANO/(reservationNano(512)+reservationNano(2048))),779);
 assert.throws(()=>reservationNano(513));assert.throws(()=>reservationNano(2049));
});
test('disabled release file contains no zero assumptions or operational start',()=>{
 const p=JSON.parse(readFileSync(new URL('../release/final-judging.disabled.json',import.meta.url),'utf8'));
 assert.equal(p.enabled,false);assert.equal(p.startsAt,null);assert.equal(p.providerInvoiceHardCap,'UNVERIFIED');
 assert.match(p.priorSpendAndPendingCalls,/UNKNOWN/);assert.match(p.taxesFeesAndExchange,/UNKNOWN/);
});
test('missing or disabled policy never sends or reserves',async t=>{
 const s=setup(t);let priceReads=0;
 for(const p of [undefined,{...policy(),enabled:false},{...policy(),budgetId:'OTHER'},{...policy(),executeUntil:JUDGING_END+1}]){
  const guard=createJudgeCostGuard({ledger:s.ledger,providerFetch:async()=>assert.fail('send'),readPublicPricing:async()=>{priceReads++;return pricing();},policy:p,now:()=>NOW});
  await assert.rejects(guard.forRun(runId(1))(COST_ENDPOINT,request()),/COST_GUARD_DISABLED/);
 }
 assert.equal(priceReads,0);assert.equal((await s.ledger.status()).reservations,0);
});
test('exact model and prices required; unavailable or changed metadata fails closed',async t=>{
 const s=setup(t);
 for(const mutate of [x=>x[0].status='disabled',x=>x[0].flavors[0].input_price_per_million_tokens=0.061,x=>x[0].flavors[0].output_price_per_million_tokens=0.241,x=>x[0].flavors[0].max_model_len=262145,x=>x[0].flavors[0].external_provider=true,x=>x.push(x[0])]){
  const data=pricing();mutate(data);assert.throws(()=>validatePricingSnapshot(data));
  const g=createJudgeCostGuard({ledger:s.ledger,providerFetch:async()=>assert.fail('send'),readPublicPricing:async()=>data,policy:policy(),now:()=>NOW});
  await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_PRICE/);
 }
 const g=createJudgeCostGuard({ledger:s.ledger,providerFetch:async()=>assert.fail('send'),readPublicPricing:async()=>{throw Error('network unavailable');},policy:policy(),now:()=>NOW});
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_PRICE_UNVERIFIED/);
 assert.equal((await s.ledger.status()).reservations,0);
});
test('rejects model switching, extra tools, multiple generations, auto tier and unbounded output before reservation',async t=>{
 const s=setup(t);
 for(const patch of [{model:'other/model'},{tools:[]},{n:2},{stream:true},{service_tier:'auto'},{max_completion_tokens:2049},{max_completion_tokens:null},{messages:[{role:'user',content:'a'.repeat(1025)}]},{messages:[{role:'user',content:[{type:'image_url',image_url:{url:'x'}}]}]}]){
  const r=request();r.body=JSON.stringify({...JSON.parse(r.body),...patch});
  await assert.rejects(s.guard.forRun(runId(1))(COST_ENDPOINT,r),/COST_REQUEST/);
 }
 await assert.rejects(s.guard.forRun(runId(1))('https://example.invalid',request()),/COST_REQUEST/);
 assert.equal(s.calls(),0);assert.equal((await s.ledger.status()).reservations,0);
});
test('duplicate run cannot send again after success; full reservation never refunded',async t=>{
 const s=setup(t);const fn=s.guard.forRun(runId(1));await fn(COST_ENDPOINT,request());
 await assert.rejects(fn(COST_ENDPOINT,request()),/COST_DUPLICATE_OR_BUDGET/);
 const state=await s.ledger.status();assert.equal(state.reserved_nano,reservationNano(512));assert.equal(state.reservations,1);assert.equal(s.calls(),1);
 assert.equal(s.db.sql.prepare('SELECT observation FROM judge_cost_reservations').get().observation,'RESPONSE_RETURNED_UNSETTLED');
 const serialized=JSON.stringify(s.db.sql.prepare('SELECT * FROM judge_cost_reservations').all());assert.doesNotMatch(serialized,/SYNTHETIC_NON_SECRET_TEST_VALUE|Fictional local test/);
});
test('uncertain transport consumes full reservation and never automatically retries or falls back',async t=>{
 const s=setup(t);let calls=0;
 const g=createJudgeCostGuard({ledger:s.ledger,providerFetch:async()=>{calls++;throw Error('timeout after acceptance');},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request(2048)),/COST_TRANSPORT_UNKNOWN_NO_RETRY/);
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request(2048)),/COST_DUPLICATE_OR_BUDGET/);
 assert.equal(calls,1);assert.equal((await s.ledger.status()).reserved_nano,reservationNano(2048));
});
test('HTTP error retains reservation and is not retried',async t=>{
 const s=setup(t);let calls=0;
 const g=createJudgeCostGuard({ledger:s.ledger,providerFetch:async()=>{calls++;return new Response('synthetic 429',{status:429});},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 assert.equal((await g.forRun(runId(1))(COST_ENDPOINT,request())).status,429);
 assert.equal(calls,1);assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
});
test('reservation response lost after DB commit sends nothing and cannot reclaim',async t=>{
 const s=setup(t);let sends=0;
 const ambiguous={...s.ledger,reserve:async r=>{await s.ledger.reserve(r);throw Error('ack lost');}};
 const g=createJudgeCostGuard({ledger:ambiguous,providerFetch:async()=>{sends++;return new Response('bad');},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_RESERVATION_UNCONFIRMED_NO_SEND/);
 assert.equal(sends,0);assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
 await assert.rejects(s.guard.forRun(runId(1))(COST_ENDPOINT,request()),/COST_DUPLICATE_OR_BUDGET/);
});
test('observation write failure cannot refund or cause an automatic retry',async t=>{
 const s=setup(t);let sends=0;
 const g=createJudgeCostGuard({ledger:{...s.ledger,observe:async()=>{throw Error('storage down');}},providerFetch:async()=>{sends++;return new Response('ok');},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 await g.forRun(runId(1))(COST_ENDPOINT,request());assert.equal(sends,1);
 assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_DUPLICATE_OR_BUDGET/);
});
test('cumulative budget has no session, browser, case or campaign reset',async t=>{
 const s=setup(t,{ceiling:reservationNano(512)*2});
 for(let n=1;n<=2;n++)await s.guard.forRun(runId(n))(COST_ENDPOINT,request());
 const reconstructed=createJudgeCostGuard({ledger:createJudgeCostLedger(s.db,{now:()=>NOW}),providerFetch:async()=>assert.fail('send'),readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 await assert.rejects(reconstructed.forRun(runId(3))(COST_ENDPOINT,request()),/COST_DUPLICATE_OR_BUDGET/);
 assert.equal(s.calls(),2);assert.equal((await s.ledger.status()).reservations,2);
});
test('prior commitments are subtracted and unknown cannot be seeded as an absent value',async t=>{
 const s=setup(t,{ceiling:reservationNano(512)*2,prior:reservationNano(512)});
 assert.equal(await reserve(s.ledger,1),true);assert.equal(await reserve(s.ledger,2),false);
 assert.throws(()=>s.db.sql.prepare('UPDATE judge_cost_budget SET prior_committed_nano=NULL').run());
});
test('database rejects deletion, refund, amount mutation, budget increase and reset',async t=>{
 const s=setup(t,{ceiling:reservationNano(512)*2,prior:1});await reserve(s.ledger,1);
 for(const sql of ['DELETE FROM judge_cost_reservations','DELETE FROM judge_cost_budget','UPDATE judge_cost_reservations SET reserved_nano=1','UPDATE judge_cost_reservations SET max_output_tokens=2048','UPDATE judge_cost_budget SET prior_committed_nano=0','UPDATE judge_cost_budget SET ceiling_nano=25000000000','UPDATE judge_cost_budget SET starts_at=starts_at+1','UPDATE judge_cost_budget SET committed_nano=0','UPDATE judge_cost_budget SET reservation_count=0'])assert.throws(()=>s.db.sql.exec(sql));
 assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
});
test('INSERT OR REPLACE cannot reset a budget or overwrite a reservation',async t=>{
 const s=setup(t,{prior:12345});await reserve(s.ledger,1);
 assert.equal(s.db.sql.prepare('PRAGMA recursive_triggers').get().recursive_triggers,0);
 assert.throws(()=>s.db.sql.exec('INSERT OR REPLACE INTO judge_cost_budget SELECT singleton,budget_id,ceiling_nano,0,starts_at,execute_until,enabled,0,0 FROM judge_cost_budget'));
 assert.throws(()=>s.db.sql.exec('INSERT OR REPLACE INTO judge_cost_reservations SELECT * FROM judge_cost_reservations'));
 assert.equal((await s.ledger.status()).prior_committed_nano,12345);
});
test('DB disabled, not-yet-started, expired, absent row and future-window policy fail closed',async t=>{
 const s=setup(t,{enabled:0});assert.equal(await reserve(s.ledger),false);
 s.db.sql.exec('UPDATE judge_cost_budget SET enabled=1');
 for(const at of [NOW-2000,JUDGING_END,JUDGING_END+1])assert.equal(await reserve(createJudgeCostLedger(s.db,{now:()=>at}),at+1),false);
 s.db.sql.exec('UPDATE judge_cost_budget SET execute_until=execute_until-1');
 assert.equal(await reserve(createJudgeCostLedger(s.db,{now:()=>JUDGING_END-1})),false);
});
test('expiry between reservation and send retains reservation but sends nothing',async t=>{
 const s=setup(t);let at=NOW,sends=0;
 const ledger={...s.ledger,reserve:async r=>{const ok=await s.ledger.reserve(r);at=JUDGING_END;return ok;}};
 const g=createJudgeCostGuard({ledger,providerFetch:async()=>{sends++;return new Response('bad');},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>at});
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_EXPIRED_AFTER_RESERVE_NO_SEND/);
 assert.equal(sends,0);assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
});
test('an earlier DB cutoff returned atomically with reservation is rechecked before send',async t=>{
 const s=setup(t);let at=NOW,sends=0;
 s.db.sql.prepare('UPDATE judge_cost_budget SET execute_until=?').run(NOW+10);
 const ledger={...s.ledger,reserve:async r=>{const admission=await s.ledger.reserve(r);at=NOW+11;return admission;}};
 const g=createJudgeCostGuard({ledger,providerFetch:async()=>{sends++;return new Response('bad');},readPublicPricing:async()=>pricing(),policy:policy(),now:()=>at});
 await assert.rejects(g.forRun(runId(1))(COST_ENDPOINT,request()),/COST_EXPIRED_AFTER_RESERVE_NO_SEND/);
 assert.equal(sends,0);assert.equal((await s.ledger.status()).reserved_nano,reservationNano(512));
});
test('abort before reservation costs nothing; abort after reservation never refunds',async t=>{
 const s=setup(t);let abort=new AbortController();abort.abort();
 await assert.rejects(s.guard.forRun(runId(1))(COST_ENDPOINT,{...request(),signal:abort.signal}),/COST_REQUEST_ALREADY_ABORTED/);
 assert.equal((await s.ledger.status()).reservations,0);
 abort=new AbortController();const ledger={...s.ledger,reserve:async r=>{const ok=await s.ledger.reserve(r);abort.abort();return ok;}};
 const g=createJudgeCostGuard({ledger,providerFetch:async()=>assert.fail('send'),readPublicPricing:async()=>pricing(),policy:policy(),now:()=>NOW});
 await assert.rejects(g.forRun(runId(2))(COST_ENDPOINT,{...request(),signal:abort.signal}),/COST_ABORTED_AFTER_RESERVE_NO_SEND/);
 assert.equal((await s.ledger.status()).reservations,1);
});
test('request object mutation during awaited pricing cannot change reserved/sent request',async t=>{
 const s=setup(t);const r=request();let sent;
 const g=createJudgeCostGuard({ledger:s.ledger,providerFetch:async(_,options)=>{sent=JSON.parse(options.body);return new Response('ok');},readPublicPricing:async()=>{r.body=JSON.stringify({...JSON.parse(r.body),model:'expensive/model',max_completion_tokens:100000});return pricing();},policy:policy(),now:()=>NOW});
 await g.forRun(runId(1))(COST_ENDPOINT,r);assert.equal(sent.model,COST_MODEL);assert.equal(sent.max_completion_tokens,512);
});
test('779 complete producer+receiver journeys fit; 780th pair does not fit nominal USD 25',async t=>{
 const s=setup(t);for(let i=0;i<779;i++){assert.equal(await reserve(s.ledger,2*i+1,512),true);assert.equal(await reserve(s.ledger,2*i+2,2048),true);}
 assert.equal((await s.ledger.status()).reserved_nano,24983838720);
 assert.equal(await reserve(s.ledger,1559,512),true);assert.equal(await reserve(s.ledger,1560,2048),false);
 assert((await s.ledger.status()).reserved_nano<=CEILING_NANO);
});
test('actual concurrent SQLite connections cannot exceed one remaining reservation',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'nano-judging-synthetic-cost-'));
 try{
  const path=join(dir,'synthetic-only.sqlite');const db=new LocalCostD1(path,{ceiling:reservationNano(512)});db.close();
  const gate=new SharedArrayBuffer(4);const handles=[];
  const results=await new Promise((resolve,reject)=>{
   let ready=0;const outcomes=[];
   for(let id=1;id<=8;id++){
    const worker=new Worker(new URL('./judge-cost-race-worker.mjs',import.meta.url),{workerData:{path,gate,id}});handles.push(worker);
    worker.on('error',reject);worker.on('message',msg=>{if(msg.ready){ready++;if(ready===8){Atomics.store(new Int32Array(gate),0,1);Atomics.notify(new Int32Array(gate),0);}}else{outcomes.push(msg);if(outcomes.length===8)resolve(outcomes);}});
   }
  });
  await Promise.all(handles.map(w=>new Promise(resolve=>{if(w.threadId===-1)resolve();else w.once('exit',resolve);}))); 
  assert.equal(results.filter(x=>x.accepted===true).length,1);assert.equal(results.filter(x=>x.error).length,0);
  const verify=new LocalCostD1(path,{initialize:false});try{assert.equal((await createJudgeCostLedger(verify,{now:()=>NOW}).status()).reserved_nano,reservationNano(512));}finally{verify.close();}
 }finally{rmSync(dir,{recursive:true,force:true});}
});
