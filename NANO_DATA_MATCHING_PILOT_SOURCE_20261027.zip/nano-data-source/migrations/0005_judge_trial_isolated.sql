-- ISOLATED JUDGE DATABASE ONLY. Never apply this schema to the owner's JUDGE_DB.
-- All timestamps are epoch milliseconds; issued sessions and reserved calls never refund.
CREATE TABLE trial_campaigns (
 id TEXT PRIMARY KEY NOT NULL,
 ceiling INTEGER NOT NULL CHECK(ceiling BETWEEN 1 AND 100000),
 execute_until INTEGER NOT NULL,
 read_until INTEGER NOT NULL CHECK(read_until>=execute_until),
 retention_until INTEGER NOT NULL CHECK(retention_until>=read_until),
 revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1))
);
CREATE TABLE trial_grants (
 id TEXT PRIMARY KEY NOT NULL,
 campaign_id TEXT NOT NULL REFERENCES trial_campaigns(id),
 code_hash TEXT NOT NULL UNIQUE,
 call_ceiling INTEGER NOT NULL CHECK(call_ceiling BETWEEN 1 AND 100000),
 max_sessions INTEGER NOT NULL CHECK(max_sessions BETWEEN 1 AND 100000),
 sessions_issued INTEGER NOT NULL DEFAULT 0 CHECK(sessions_issued>=0),
 expires_at INTEGER NOT NULL,
 revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1))
);
CREATE TABLE trial_sessions (
 id TEXT PRIMARY KEY NOT NULL,
 token_hash TEXT NOT NULL UNIQUE,
 grant_id TEXT NOT NULL REFERENCES trial_grants(id),
 expires_at INTEGER NOT NULL,
 revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN(0,1))
);
-- A successful INSERT and its issued-session accounting are one SQLite statement.
CREATE TRIGGER trial_session_issue_count AFTER INSERT ON trial_sessions
BEGIN
 UPDATE trial_grants SET sessions_issued=sessions_issued+1 WHERE id=NEW.grant_id;
END;
CREATE TABLE trial_login_windows (
 window INTEGER NOT NULL,
 kind TEXT NOT NULL CHECK(kind='invalid'),
 attempts INTEGER NOT NULL CHECK(attempts>=1),
 PRIMARY KEY(window,kind)
);
CREATE TABLE trial_runs (
 id TEXT PRIMARY KEY NOT NULL,
 campaign_id TEXT NOT NULL REFERENCES trial_campaigns(id),
 grant_id TEXT NOT NULL REFERENCES trial_grants(id),
 session_id TEXT NOT NULL REFERENCES trial_sessions(id),
 stage TEXT NOT NULL CHECK(stage IN('produce','receive')),
 parent_id TEXT,
 source TEXT,
 input_hash TEXT,
 policy_revision TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 evidence_json TEXT,
 finished_at INTEGER,
 purged_at INTEGER,
 UNIQUE(grant_id,stage)
);
CREATE INDEX trial_runs_campaign ON trial_runs(campaign_id);
CREATE INDEX trial_runs_scope ON trial_runs(session_id,grant_id,campaign_id);
CREATE INDEX trial_sessions_grant ON trial_sessions(grant_id);
