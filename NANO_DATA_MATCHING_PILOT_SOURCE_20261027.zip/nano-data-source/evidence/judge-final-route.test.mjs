import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fixture,response,WILLOW,ID} from './judge-router-fixture.mjs';
import {pricing} from './judge-cost-fixture.mjs';
import {COST_BUDGET_ID,JUDGING_END,CEILING_NANO,reservationNano} from '../adapter/judge-cost-guard.mjs';
import {FINAL_RUNTIME_MODE} from '../adapter/judge-final-boundary.mjs';
const module=await import(process.env.JUDGE_FINAL_APP_MODULE||'../adapter/app.mjs');

function finalFixture(t,{budget=CEILING_NANO,price=async()=>pricing(),transport,nativeSimulation=false,...opts}={}){
 let s;
 const wrapped={createJudgeTrialRouter:options=>{
  if(!nativeSimulation)return module.createApp({...options,readPublicPricing:price});
  // Test-only global stub simulates native transport selection. It never opens
  // a network connection; output is synthetic, not provider-call evidence.
  const previous=globalThis.fetch;globalThis.fetch=options.providerFetch;t.after(()=>{globalThis.fetch=previous;});
  return module.createApp({readPublicPricing:price});
 }};
 s=fixture(t,wrapped,{...opts,transport:async(...args)=>{
  // Every provider send must already have a committed amount at least as large
  // as the current explicit request; this assertion runs at the real route edge.
  const body=JSON.parse(args[1].body),rows=s.raw.sql.prepare('SELECT * FROM judge_cost_reservations ORDER BY rowid').all();
  assert(rows.length>0);assert.equal(rows.at(-1).max_output_tokens,body.max_completion_tokens);
  assert.equal(rows.at(-1).reserved_nano,reservationNano(body.max_completion_tokens));
  return transport?transport(...args):response('Willow Reading Club Saturday: 2 tables, 6 chairs; outcomes unmeasured.');
 }});
 s.raw.sql.exec(readFileSync(new URL('../migrations/0007_judge_cost_guard.PROPOSED.sql',import.meta.url),'utf8'));
 s.raw.sql.prepare('INSERT INTO judge_cost_budget(singleton,budget_id,ceiling_nano,prior_committed_nano,starts_at,execute_until,enabled) VALUES(1,?,?,?,?,?,1)').run(COST_BUDGET_ID,budget,0,Date.now()-60000,JUDGING_END);
 s.env.JUDGE_FINAL_RUNTIME=FINAL_RUNTIME_MODE;
 s.env.JUDGE_TRIAL_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_TRIAL_POLICY_JSON),finalJudging:true,receiverMaxOutputTokens:2048,receiverDeadlineMs:60000,maximumEstimatedUSD:25});
 s.env.JUDGE_FINAL_COST_POLICY_JSON=JSON.stringify({enabled:true,mode:'APPLICATION_RESERVATION_GUARD_NOT_INVOICE_CAP',spendingAuthority:'FREE_CREDITS_ONLY_NO_AUTOMATIC_PAID_CHARGES',budgetId:COST_BUDGET_ID,startsAt:Date.now()-60000,executeUntil:JUDGING_END,producerMaxOutputTokens:512,receiverMaxOutputTokens:2048,activationAuthorization:'EXPLICIT_FINAL_JUDGING_ACTIVATION_AFTER_REVIEW'});
 s.ledger=()=>s.raw.sql.prepare('SELECT COUNT(*) n,COALESCE(SUM(reserved_nano),0) reserved FROM judge_cost_reservations').get();
 return s;
}

test('final app route gates producer and receiver with explicit 512/2048 reservations; replays and read send zero',async t=>{
 const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie);
 for(const key of ['JUDGE_DB','JUDGE_ACCESS_KEY','HANDOFF_PRODUCT_POLICY_JSON','NEBIUS_API_KEY'])Object.defineProperty(s.env,key,{get(){throw Error('OWNER_BINDING_MUST_NOT_BE_READ');}});
 assert.equal((await s.produce(item,a.cookie)).status,200);assert.equal((await s.receive(item,a.cookie)).status,200);
 assert.equal(s.sends(),2);assert.deepEqual(s.requests.map(x=>x.max_completion_tokens),[512,2048]);
 assert.equal(s.ledger().reserved,reservationNano(512)+reservationNano(2048));
 await s.produce(item,a.cookie);await s.receive(item,a.cookie);await s.read(item,a.cookie);assert.equal(s.sends(),2);assert.equal(s.ledger().n,2);
});
test('declared final mode cannot silently downgrade when config, activation, output or runtime mode is missing',async t=>{
 for(const mutate of [s=>delete s.env.JUDGE_FINAL_RUNTIME,s=>delete s.env.JUDGE_FINAL_COST_POLICY_JSON,s=>s.env.JUDGE_FINAL_RUNTIME='DISABLED',s=>s.env.JUDGE_FINAL_COST_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_FINAL_COST_POLICY_JSON),enabled:false}),s=>s.env.JUDGE_FINAL_COST_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_FINAL_COST_POLICY_JSON),activationAuthorization:'PREPARATION_ONLY'}),s=>s.env.JUDGE_FINAL_COST_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_FINAL_COST_POLICY_JSON),spendingAuthority:'PAID_AUTOCHARGE'}),s=>s.env.JUDGE_TRIAL_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_TRIAL_POLICY_JSON),finalJudging:false}),s=>s.env.JUDGE_TRIAL_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_TRIAL_POLICY_JSON),receiverMaxOutputTokens:512})]){
  const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie);mutate(s);
  const r=await s.produce(item,a.cookie);assert.equal(r.status,503);assert.equal((await r.json()).reason,'FINAL_JUDGING_NOT_ACTIVATED');assert.equal(s.sends(),0);assert.equal(s.ledger().n,0);assert.equal(s.raw.sql.prepare('SELECT COUNT(*) n FROM trial_runs').get().n,0);
 }
});
test('final plus pilot bridge is rejected without reading an owner key',async t=>{
 const s=finalFixture(t);s.env.JUDGE_TRIAL_PILOT_BRIDGE='ANY_VALUE';Object.defineProperty(s.env,'NEBIUS_API_KEY',{get(){throw Error('OWNER_KEY_READ');}});
 const r=await s.fetch('/_judge/session');assert.equal((await r.json()).reason,'FINAL_PILOT_MIXING_FORBIDDEN');assert.equal(s.sends(),0);
});
test('malformed or false final marker alone cannot downgrade into an unguarded legacy send',async t=>{
 for(const marker of ['true',false,null,1]){
  const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie);
  delete s.env.JUDGE_FINAL_RUNTIME;delete s.env.JUDGE_FINAL_COST_POLICY_JSON;
  s.env.JUDGE_TRIAL_POLICY_JSON=JSON.stringify({...JSON.parse(s.env.JUDGE_TRIAL_POLICY_JSON),finalJudging:marker});
  const r=await s.produce(item,a.cookie);assert.equal(r.status,503);assert.equal((await r.json()).reason,'FINAL_JUDGING_NOT_ACTIVATED');assert.equal(s.sends(),0);assert.equal(s.ledger().n,0);
 }
});
test('missing cost schema cannot reach provider or owner fallback',async t=>{
 const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie);s.raw.sql.exec('DROP TABLE judge_cost_reservations');
 await s.produce(item,a.cookie);assert.equal(s.sends(),0);
});
test('unavailable/changed price stops before paid send and never retries',async t=>{
 for(const price of [async()=>{throw Error('unavailable');},async()=>{const p=pricing();p[0].flavors[0].output_price_per_million_tokens=0.25;return p;}]){
  const s=finalFixture(t,{price}),a=await s.login(),item=await s.newCase(a.cookie);await s.produce(item,a.cookie);await s.produce(item,a.cookie);assert.equal(s.sends(),0);assert.equal(s.ledger().n,0);
 }
});
test('cost exhaustion stops receiver despite available legacy call count; authentication and saved read survive',async t=>{
 const s=finalFixture(t,{budget:reservationNano(512)}),a=await s.login(),item=await s.newCase(a.cookie);
 assert.equal((await s.produce(item,a.cookie)).status,200);await s.receive(item,a.cookie);assert.equal(s.sends(),1);assert.equal(s.ledger().n,1);
 const session=await(await s.fetch('/_judge/session',undefined,a.cookie)).json();assert.equal(session.authenticated,true);assert(session.remainingCalls>0);assert.equal((await s.read(item,a.cookie)).status,200);
});
test('concurrent distinct sessions/cases share one final budget; at most one producer sends',async t=>{
 const s=finalFixture(t,{budget:reservationNano(512)}),a=await s.login(0),b=await s.login(1),one=await s.newCase(a.cookie),two=await s.newCase(b.cookie);
 await Promise.all([s.produce(one,a.cookie),s.produce(two,b.cookie)]);assert.equal(s.sends(),1);assert.equal(s.ledger().n,1);assert.equal(s.ledger().reserved,reservationNano(512));
});
test('concurrent duplicate route requests send once and retain exactly one monetary reservation',async t=>{
 const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie);
 await Promise.all([s.produce(item,a.cookie),s.produce(item,a.cookie)]);assert.equal(s.sends(),1);assert.equal(s.ledger().n,1);
});
test('unknown transport result keeps full reservation and a new login never refunds or resends it',async t=>{
 const s=finalFixture(t,{transport:async()=>{throw Error('accepted then disconnected');}}),a=await s.login(),item=await s.newCase(a.cookie);
 await s.produce(item,a.cookie);await s.produce(item,a.cookie);assert.equal(s.sends(),1);assert.equal(s.ledger().reserved,reservationNano(512));
 await s.login(1);assert.equal(s.ledger().reserved,reservationNano(512));assert.equal(s.sends(),1);
});
test('guard reservation committed but acknowledgment lost leaves zero sends and preserves charge',async t=>{
 const s=finalFixture(t),a=await s.login(),item=await s.newCase(a.cookie),prepare=s.raw.prepare.bind(s.raw);
 s.raw.prepare=query=>{const statement=prepare(query);if(!query.startsWith('INSERT INTO judge_cost_reservations'))return statement;return {bind(...args){const bound=statement.bind(...args);return {...bound,async first(){await bound.first();throw Error('synthetic lost acknowledgment');}};}};};
 await s.produce(item,a.cookie);await s.produce(item,a.cookie);assert.equal(s.sends(),0);assert.equal(s.ledger().reserved,reservationNano(512));
});
test('a bad model response is not a refund and cannot trigger a paid fallback',async t=>{
 const s=finalFixture(t,{transport:async()=>Response.json({model:'UNEXPECTED_MODEL'})}),a=await s.login(),item=await s.newCase(a.cookie);
 await s.produce(item,a.cookie);await s.produce(item,a.cookie);assert.equal(s.sends(),1);assert.equal(s.ledger().reserved,reservationNano(512));
});
test('owner request dispatch never consults new final settings',async()=>{
 const app=module.createApp({providerFetch:async()=>assert.fail('owner request must not send')});
 const env={JUDGE_APP_ORIGIN:'https://owner-fixture.invalid',ASSETS:{fetch:async()=>new Response('owner shell')}};
 for(const key of ['JUDGE_FINAL_RUNTIME','JUDGE_FINAL_COST_POLICY_JSON','JUDGE_TRIAL_DB'])Object.defineProperty(env,key,{get(){throw Error('FINAL_SETTING_READ_BY_OWNER');}});
 const r=await app.fetch(new Request('https://owner-fixture.invalid/workflow'),env);assert.equal(r.status,200);assert.equal(await r.text(),'owner shell');
});
test('native-fetch wrapper classification does not falsely label a real-path attempt zero (fully synthetic stub)',async t=>{
 const s=finalFixture(t,{nativeSimulation:true}),a=await s.login(),item=await s.newCase(a.cookie);
 const body=await(await s.produce(item,a.cookie)).json();assert.equal(s.sends(),1);
 assert.equal(body.evidence.actual_model_calls,1);assert.equal(body.evidence.evidence_scope,'PROVIDER_REPORTED_NOT_INDEPENDENTLY_VERIFIED');
});
test('20 cases and foreign sessions list within the Free 50-query invocation limit without leaking scope',async t=>{
 const s=finalFixture(t,{callCeiling:40,ceiling:80}),a=await s.login(0),b=await s.login(1),foreign=await s.newCase(b.cookie);
 const mine=[];for(let i=0;i<20;i++){const item=await s.newCase(a.cookie);mine.push(item.caseId);await s.fetch('/_judge/api/cases/close-stage',{caseId:item.caseId,stage:'produce'},a.cookie);}
 const prepare=s.raw.prepare.bind(s.raw);let queries=0;
 s.raw.prepare=query=>{if(++queries>50)throw Error('SYNTHETIC_D1_FREE_QUERY_CAP');return prepare(query);};
 const r=await s.fetch('/_judge/session',undefined,a.cookie),body=await r.json();assert.equal(r.status,200);assert.equal(body.cases.length,20);assert(queries<=10,'query count='+queries);assert.deepEqual(body.cases.map(x=>x.caseId),mine);assert(!JSON.stringify(body).includes(foreign.caseId));assert.equal(s.sends(),0);
 queries=0;const other=await(await s.fetch('/_judge/session',undefined,b.cookie)).json();assert.deepEqual(other.cases.map(x=>x.caseId),[foreign.caseId]);assert(queries<=10);
});
test('batched case listing preserves empty result and existing metadata ceiling without creating AI quota',async t=>{
 const s=finalFixture(t,{callCeiling:3,ceiling:8,maxSessions:2}),a=await s.login();
 assert.deepEqual((await(await s.fetch('/_judge/session',undefined,a.cookie)).json()).cases,[]);
 for(let i=0;i<5;i++){const item=await s.newCase(a.cookie);await s.fetch('/_judge/api/cases/close-stage',{caseId:item.caseId,stage:'produce'},a.cookie);}
 const extra=await(await s.fetch('/_judge/api/cases/new',{creationKey:'SYNTHETIC_METADATA_OVER_LIMIT'},a.cookie)).json();assert.equal(extra.status,'METADATA_LIMIT');
 const body=await(await s.fetch('/_judge/session',undefined,a.cookie)).json();assert.equal(body.cases.length,5);assert.equal(body.remainingCalls,3);assert.equal(s.ledger().n,0);assert.equal(s.sends(),0);
});
test('779 synthetic case summaries stay constant-query at the nominal full-journey arithmetic boundary',async t=>{
 const s=finalFixture(t,{callCeiling:2000,ceiling:2000}),a=await s.login();
 const insert=s.raw.sql.prepare('INSERT INTO trial_cases(case_id,receiver_id,campaign_id,grant_id,session_id,creation_key,created_at,producer_closed_at) VALUES(?,?,?,?,?,?,?,?)');
 for(let i=0;i<779;i++)insert.run(ID(10000+2*i),ID(10001+2*i),s.seeded.campaignId,s.seeded.grants[0].id,a.info.sessionTag,'SYNTHETIC_MANY_CASES_'+i,Date.now()+i,Date.now());
 const prepare=s.raw.prepare.bind(s.raw);let queries=0;s.raw.prepare=q=>{if(++queries>50)throw Error('SYNTHETIC_D1_FREE_QUERY_CAP');return prepare(q);};
 const r=await s.fetch('/_judge/session',undefined,a.cookie),body=await r.json();assert.equal(r.status,200);assert.equal(body.cases.length,779);assert(queries<=10,'query count='+queries);assert.equal(s.ledger().n,0);assert.equal(s.sends(),0);
});
