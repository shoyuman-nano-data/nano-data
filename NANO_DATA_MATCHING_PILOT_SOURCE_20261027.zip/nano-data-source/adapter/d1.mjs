// Real D1 prepared/batch API adapter. No filesystem and no remote calls here.
export class D1Store {
 constructor(db){ this.db=db.withSession('first-primary'); }
 async findPreparedJob(job,owner){return this.db.prepare('SELECT attempt FROM caller_expectations WHERE job=? AND owner=?').bind(job,owner).first();}
 async prepare(attempt,job,owner){ await this.db.prepare('INSERT INTO caller_expectations(attempt,job,owner) VALUES(?,?,?)').bind(attempt,job,owner).run(); }
 async expectation(attempt,owner){ return this.db.prepare('SELECT * FROM caller_expectations WHERE attempt=? AND owner=?').bind(attempt,owner).first(); }
 async claim(attempt,job,token){ await this.db.prepare('INSERT INTO claims(attempt,job,token) VALUES(?,?,?)').bind(attempt,job,token).run(); }
 async commit(attempt,files,commit){
  const statements=Object.entries(files).map(([name,bytes])=>this.db.prepare('INSERT INTO records(attempt,name,body) VALUES(?,?,?)').bind(attempt,name,new TextDecoder('utf-8',{fatal:true}).decode(bytes)));
  statements.push(this.db.prepare('INSERT INTO successful_attempts(attempt,commit_json) VALUES(?,?)').bind(attempt,JSON.stringify(commit)));
  // D1 batch executes atomically; any constraint/error rolls back all five inserts.
  await this.db.batch(statements);
 }
 async load(attempt){
  const out=await this.db.batch([
   this.db.prepare('SELECT job,token FROM claims WHERE attempt=?').bind(attempt),
   this.db.prepare('SELECT name,body FROM records WHERE attempt=?').bind(attempt),
   this.db.prepare('SELECT commit_json FROM successful_attempts WHERE attempt=?').bind(attempt),
  ]);
  return {claim:out[0].results[0],files:Object.fromEntries(out[1].results.map(r=>[r.name,new TextEncoder().encode(r.body)])),commit:out[2].results[0] && JSON.parse(out[2].results[0].commit_json)};
 }
}
