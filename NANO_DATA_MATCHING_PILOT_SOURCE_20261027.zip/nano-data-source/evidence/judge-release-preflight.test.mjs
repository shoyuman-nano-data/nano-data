// Finite release preparation only: synthetic credentials/DB and injected transport.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LocalTrialD1,seedTrialFixture,trialHash} from './judge-test-db.mjs';
import {WILLOW,response} from './judge-router-fixture.mjs';
const {createApp}=await import(process.env.JUDGE_RELEASE_APP_MODULE||'../adapter/app.mjs');
const ORIGIN='https://release-preflight.invalid';
function harness(t){
 const raw=new LocalTrialD1(),owner=new LocalTrialD1(':memory:',{initialize:false});
 t.after(()=>{raw.close();owner.close();});
 const at=Date.now(),seeded=seedTrialFixture(raw,{now:at,grantCount:5,callCeiling:4,ceiling:20,maxSessions:2});
 owner.sql.exec(readFileSync(new URL('../schema.sql',import.meta.url),'utf8'));
 owner.sql.exec(readFileSync(new URL('../migrations/0003_nebius_once.sql',import.meta.url),'utf8'));
 owner.sql.exec(readFileSync(new URL('../migrations/0004_handoff_product.sql',import.meta.url),'utf8'));
 const ownerKey='O'.repeat(43),ownerToken='a'.repeat(64),ownerCookie='__Host-nano_judge_session='+ownerToken;
 owner.sql.prepare('INSERT INTO judge_sessions(token_hash,expires_at,credential_hash) VALUES(?,?,?)').run(trialHash(ownerToken),at+3600000,trialHash(ownerKey));
 const policy={enabled:true,authority:'EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL',campaignId:seeded.campaignId,policyId:'HP_LOCAL_RELEASE_PREFLIGHT',maximumEstimatedUSD:0.02,sessionTtlMs:1200000};
 const env={JUDGE_TRIAL_DB:raw,JUDGE_TRIAL_APP_ORIGIN:ORIGIN,JUDGE_TRIAL_POLICY_JSON:JSON.stringify(policy),JUDGE_TRIAL_PROVIDER_KEY:'LOCAL_TEST_ONLY_RELEASE_MOCK',ASSETS:{fetch:async()=>new Response('<!doctype html><title>Local release shell</title>')},JUDGE_DB:owner,JUDGE_APP_ORIGIN:ORIGIN,JUDGE_ACCESS_KEY:ownerKey,JUDGE_ACCESS_EXPIRES_AT:new Date(at+3600000).toISOString(),HANDOFF_PRODUCT_POLICY_JSON:JSON.stringify({enabled:true,authority:'EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL',policyId:'HP_OWNER_100_20261027',maxTotalCalls:100,maximumEstimatedUSD:0.06,expiresAt:new Date(at+3600000).toISOString()})};
 let sends=0;const prompts=[];
 const app=createApp({providerFetch:async(url,options)=>{sends++;prompts.push(JSON.parse(options.body));return response(sends%2?'Willow Reading Club Saturday: 2 tables, 6 chairs; unmeasured.':'Checklist: prepare tables and chairs; retain unknown outcomes.');}});
 const request=(path,data,cookie='')=>app.fetch(new Request(ORIGIN+path,{method:data===undefined?'GET':'POST',headers:{origin:ORIGIN,...(data===undefined?{}:{'content-type':'application/json'}),cookie},...(data===undefined?{}:{body:JSON.stringify(data)})}),env);
 const login=async n=>{const r=await request('/_judge/auth/login',{code:seeded.grants[n].code});assert.equal(r.status,200,JSON.stringify(await r.clone().json()));return {cookie:r.headers.get('set-cookie').split(';')[0],body:await r.json()};};
 let sequence=0;const newCase=async cookie=>{const r=await request('/_judge/api/cases/new',{creationKey:'LOCAL_RELEASE_CREATION_'+(++sequence)},cookie);assert.equal(r.status,200,JSON.stringify(await r.clone().json()));return (await r.json()).case;};
 const produce=(item,cookie)=>request('/_judge/api/seed/produce',{caseId:item.caseId,id:item.producerId,...WILLOW},cookie);
 const receive=(item,cookie)=>request('/_judge/api/seed/receive',{caseId:item.caseId,id:item.receiverId,parentId:item.producerId},cookie);
 const rowCount=()=>raw.sql.prepare('SELECT count(*) n FROM trial_runs').get().n;
 return {raw,owner,seeded,env,policy,ownerCookie,request,login,newCase,produce,receive,rowCount,sends:()=>sends,prompts};
}

test('C03 disabled template retains pending dates, absent credential and explicit unapproved finite-pilot limits',()=>{
 const configured=JSON.parse(readFileSync(new URL('../release/judge-production.disabled.json',import.meta.url),'utf8'));
 assert.equal(configured.status,'SAFE_PREP_ONLY_UNAPPROVED_FINITE_PILOT');
 assert.equal(configured.runtimePolicy.enabled,false);
 assert.equal(configured.runtimePolicy.authority,'PENDING_EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL');
 assert.equal(configured.runtimePolicy.policyId,'PENDING');assert.equal(configured.runtimePolicy.campaignId,'PENDING');
 assert.deepEqual(configured.dates,{executeUntil:'PENDING',readUntil:'PENDING',retentionUntil:'PENDING'});
 assert.equal(configured.bindings.JUDGE_TRIAL_PROVIDER_KEY,null);
 assert.equal(configured.bindings.JUDGE_TRIAL_DB,'PENDING_DEDICATED_BINDING');
 assert.equal(configured.proposed.grantCount,5);assert.equal(configured.proposed.callsPerGrant,4);
 assert.equal(configured.proposed.campaignCallCeiling,20);assert.equal(configured.proposed.maxSessionsPerGrant,2);
 assert.equal(configured.proposed.maximumEstimatedUSD,0.02);assert.equal(configured.runtimePolicy.maximumEstimatedUSD,0.02);
 assert.match(configured.proposed.note,/not a literal registry case-count cap/);
 assert.match(configured.finalJudgingAccess,/BLOCKED.*UNRESTRICTED/);
 assert.equal(configured.authorization,'NO_PRODUCTION_ACTION_AUTHORIZED_BY_THIS_FILE');
 assert.match(configured.purgeOperation,/NOT_IMPLEMENTED/);
});

test('C03 disabled release policy cannot admit or reserve with an enabled synthetic owner and existing trial cookie',async t=>{
 const s=harness(t),admitted=await s.login(0),item=await s.newCase(admitted.cookie);
 const configured=JSON.parse(readFileSync(new URL('../release/judge-production.disabled.json',import.meta.url),'utf8'));
 const ownerBefore=JSON.stringify(s.owner.sql.prepare('SELECT * FROM judge_sessions ORDER BY token_hash').all()),ownerPolicy=s.env.HANDOFF_PRODUCT_POLICY_JSON;
 assert.equal((await(await s.request('/_auth/session',undefined,s.ownerCookie)).json()).authenticated,true);
 // Flipping enabled alone is insufficient: pending approval/policy still closes before admission/reserve.
 for(const policy of [configured.runtimePolicy,{...configured.runtimePolicy,enabled:true}]){
  s.env.JUDGE_TRIAL_POLICY_JSON=JSON.stringify(policy);
  assert.equal((await s.request('/judge')).status,200);
  assert.equal((await(await s.request('/_judge/session',undefined,admitted.cookie)).json()).enabled,false);
  for(const [path,data] of [['/_judge/auth/login',{code:s.seeded.grants[0].code}],['/_judge/api/cases/new',{creationKey:'LOCAL_DISABLED_CREATION'}],['/_judge/api/seed/produce',{caseId:item.caseId,id:item.producerId,...WILLOW}]])assert.equal((await s.request(path,data,admitted.cookie)).status,503);
 }
 assert.equal(s.sends(),0);assert.equal(s.rowCount(),0);
 assert.equal(s.raw.sql.prepare('SELECT count(*) n FROM trial_sessions').get().n,1);
 assert.equal(s.raw.sql.prepare('SELECT sessions_issued FROM trial_grants WHERE id=?').get(s.seeded.grants[0].id).sessions_issued,1);
 assert.equal(JSON.stringify(s.owner.sql.prepare('SELECT * FROM judge_sessions ORDER BY token_hash').all()),ownerBefore);
 assert.equal(s.env.HANDOFF_PRODUCT_POLICY_JSON,ownerPolicy);
 assert.equal((await(await s.request('/_auth/session',undefined,s.ownerCookie)).json()).authenticated,true);
});

test('C03 synthetic five grants consume exactly twenty total calls; fifth grant-call and independent campaign-overflow probe send nothing',async t=>{
 const s=harness(t);let total=0,last;
 for(let n=0;n<5;n++){
  const auth=await s.login(n);assert.equal(auth.body.remainingCalls,4);
  const one=await s.newCase(auth.cookie);
  assert.equal((await s.produce(one,auth.cookie)).status,200);
  assert.equal((await s.receive(one,auth.cookie)).status,200);
  const two=await s.newCase(auth.cookie);
  assert.equal((await s.produce(two,auth.cookie)).status,200);
  // Prepare a third fixed-ID case while one call remains, to probe reserve rather than only metadata gating.
  const fifth=await s.newCase(auth.cookie);
  assert.equal((await s.receive(two,auth.cookie)).status,200);
  total+=4;assert.equal(s.sends(),total);assert.equal(s.rowCount(),total);
  const refused=await s.produce(fifth,auth.cookie);assert.equal(refused.status,422);
  const refusal=await refused.json();assert.equal(refusal.status,'UNKNOWN_STOP_NO_RETRY');
  assert.equal(refusal.reservation_made,undefined);assert.equal(refusal.actual_model_calls,undefined);
  assert.equal(s.sends(),total);assert.equal(s.rowCount(),total);
  const current=await(await s.request('/_judge/session',undefined,auth.cookie)).json();assert.equal(current.remainingCalls,0);
  for(const item of [one,two])for(const id of [item.producerId,item.receiverId])assert.equal((await s.request('/_judge/api/seed/read',{caseId:item.caseId,id},auth.cookie)).status,200);
  assert.equal(s.sends(),total);
  // Second admission is allowed but it neither refunds calls nor exposes the old session's case.
  const relogin=await s.login(n);assert.equal(relogin.body.remainingCalls,0);assert.deepEqual(relogin.body.cases,[]);
  assert.equal((await s.request('/_judge/api/seed/read',{caseId:one.caseId,id:one.producerId},relogin.cookie)).status,422);
  assert.equal((await s.request('/_judge/auth/login',{code:s.seeded.grants[n].code})).status,429);
  assert.equal(s.raw.sql.prepare('SELECT sessions_issued FROM trial_grants WHERE id=?').get(s.seeded.grants[n].id).sessions_issued,2);
  last={...auth,item:fifth,grant:s.seeded.grants[n]};
 }
 assert.equal(total,20);assert.equal(s.sends(),20);assert.equal(s.rowCount(),20);
 assert.equal(s.raw.sql.prepare('SELECT count(*) n FROM trial_grants').get().n,5);
 for(const grant of s.seeded.grants)assert.equal(s.raw.sql.prepare('SELECT count(*) n FROM trial_runs WHERE grant_id=?').get(grant.id).n,4);
 // Synthetic fault probe only: relax one fixture grant cap after saturation, leaving campaign20 as the independent blocker.
 s.raw.sql.prepare('UPDATE trial_grants SET call_ceiling=5 WHERE id=?').run(last.grant.id);
 assert.equal((await s.produce(last.item,last.cookie)).status,422);
 assert.equal(s.sends(),20);assert.equal(s.rowCount(),20);
 assert.equal((await(await s.request('/_judge/session',undefined,last.cookie)).json()).remainingCalls,0);
 for(const prompt of s.prompts)assert.doesNotMatch(JSON.stringify(prompt),/caseId|creationKey|grantId|campaignId/);
});
