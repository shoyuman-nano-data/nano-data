// One dated, explicitly approved same-app pilot. Never a general credential fallback.
export const PILOT_CAMPAIGN='PILOT_20261027_1GRANT_2CALL';
export const PILOT_GRANT='PILOT_GRANT_20261027_01';
export const PILOT_POLICY='HP_PILOT_20261027_2CALL';
export const PILOT_FLAG='PILOT_20261027_TWO_CALLS_ONLY';
export const PILOT_CUTOFF=Date.parse('2026-10-28T05:00:00.000Z');
export async function pilotEnvironment(env,now=Date.now){
 if(env.JUDGE_TRIAL_PILOT_BRIDGE!==PILOT_FLAG)return env;
 // On any mismatch remain closed, even if an unrelated dedicated key was supplied.
 const closed=Object.create(env);closed.JUDGE_TRIAL_PROVIDER_KEY=undefined;
 let p;try{p=JSON.parse(env.JUDGE_TRIAL_POLICY_JSON||'{}');}catch{return closed;}
 if(now()>=PILOT_CUTOFF||p.enabled!==true||p.authority!=='EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL'||p.campaignId!==PILOT_CAMPAIGN||p.policyId!==PILOT_POLICY||p.maximumEstimatedUSD!==0.02||env.JUDGE_TRIAL_APP_ORIGIN!=='https://nano-data-judge-test-20261025.shoyuman-official.workers.dev'||!env.JUDGE_TRIAL_DB||env.JUDGE_TRIAL_DB===env.JUDGE_DB)return closed;
 const db=env.JUDGE_TRIAL_DB.withSession('first-primary');
 const row=await db.prepare(`SELECT c.ceiling,c.execute_until,c.read_until,c.retention_until,c.revoked,g.id grant_id,g.call_ceiling,g.max_sessions,g.expires_at,g.revoked grant_revoked,(SELECT COUNT(*) FROM trial_campaigns) campaigns,(SELECT COUNT(*) FROM trial_grants) grants,(SELECT COUNT(*) FROM trial_runs) runs FROM trial_campaigns c JOIN trial_grants g ON g.campaign_id=c.id WHERE c.id=? AND g.id=?`).bind(PILOT_CAMPAIGN,PILOT_GRANT).first();
 if(!row||row.campaigns!==1||row.grants!==1||row.ceiling!==2||row.call_ceiling!==2||row.max_sessions!==1||row.execute_until!==PILOT_CUTOFF||row.read_until!==PILOT_CUTOFF||row.retention_until!==PILOT_CUTOFF||row.expires_at!==PILOT_CUTOFF||row.revoked!==0||row.grant_revoked!==0||!Number.isSafeInteger(row.runs)||row.runs>2||now()>=PILOT_CUTOFF)return closed;
 const credential=env.NEBIUS_API_KEY;
 if(typeof credential!=='string'||!credential.trim()||/[\r\n]/.test(credential))return closed;
 closed.JUDGE_TRIAL_PROVIDER_KEY=credential;return closed;
}
