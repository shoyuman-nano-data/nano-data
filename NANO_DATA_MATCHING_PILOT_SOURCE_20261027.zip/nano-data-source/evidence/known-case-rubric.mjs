// OFFLINE known-text annotation replay only. Not an automatic semantic classifier.
import {createHash} from 'node:crypto';
const annotations={
 '0d29f3e7c2e19d57df81839c52d3a87afbe9e9f3c606dcdc797d46b4ebb496f5':{semantic:'KNOWN_CASE_FAIL',reason:'R5_UNSUPPORTED_DATA_ABSENCE_AND_CAUSAL_EXPLANATION'},
 'f50a387d2d76930f812071cfa024a4f9febb5ad7134455b9ebe64af6f0a8110f':{semantic:'KNOWN_REFERENCE_ACCEPTED_ANNOTATION',reason:'OFFLINE_ASSISTANT_REFERENCE_NOT_PROVIDER05'}
};
export function reviewRecordedCase(e){
 const schema=['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(e.status);
 const annotation=typeof e.output==='string'?annotations[createHash('sha256').update(e.output).digest('hex')]:null;
 return {scope:'OFFLINE_KNOWN_TEXT_REPLAY_NOT_GENERAL_EVALUATOR',schema_received:schema,completion:e.finish_reason==='stop'?'COMPLETE':e.finish_reason==='length'?'INCOMPLETE_LENGTH':'UNKNOWN',semantic:annotation?.semantic??'REVIEW_REQUIRED',reason:annotation?.reason??'UNSEEN_OUTPUT_REQUIRES_CLAIM_REVIEW',accepted_for_handoff:schema&&e.finish_reason==='stop'&&annotation?.semantic==='KNOWN_REFERENCE_ACCEPTED_ANNOTATION',billing:'UNKNOWN_NOT_INVOICE'};
}
