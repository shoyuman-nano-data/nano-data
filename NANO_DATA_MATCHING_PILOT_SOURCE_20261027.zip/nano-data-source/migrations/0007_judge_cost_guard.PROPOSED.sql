-- PRIVATE PROPOSAL ONLY. Not applied to any existing or remote database.
-- Fresh isolated judging database only. No owner binding, credentials or seed row.
-- Monetary units are integer nano-USD (1 USD = 1,000,000,000 units).
-- This is application admission accounting, NOT a provider invoice hard cap.
CREATE TABLE judge_cost_budget (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 budget_id TEXT NOT NULL UNIQUE CHECK(budget_id='NANO_DATA_FINAL_JUDGING'),
 ceiling_nano INTEGER NOT NULL CHECK(ceiling_nano BETWEEN 1 AND 25000000000),
 prior_committed_nano INTEGER NOT NULL CHECK(prior_committed_nano BETWEEN 0 AND ceiling_nano),
 starts_at INTEGER NOT NULL,
 execute_until INTEGER NOT NULL CHECK(execute_until<=1797364800000 AND execute_until>starts_at),
 enabled INTEGER NOT NULL CHECK(enabled IN(0,1)),
 committed_nano INTEGER NOT NULL DEFAULT 0 CHECK(committed_nano BETWEEN 0 AND ceiling_nano-prior_committed_nano),
 reservation_count INTEGER NOT NULL DEFAULT 0 CHECK(reservation_count>=0)
);
CREATE TABLE judge_cost_reservations (
 run_id TEXT PRIMARY KEY NOT NULL,
 budget_id TEXT NOT NULL REFERENCES judge_cost_budget(budget_id),
 request_sha256 TEXT NOT NULL CHECK(length(request_sha256)=64),
 model TEXT NOT NULL CHECK(model='nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B'),
 max_input_tokens INTEGER NOT NULL CHECK(max_input_tokens=262144),
 max_output_tokens INTEGER NOT NULL CHECK(max_output_tokens IN(512,2048)),
 reserved_nano INTEGER NOT NULL CHECK(reserved_nano=262144*60+max_output_tokens*240),
 send_intent_at INTEGER NOT NULL,
 observation TEXT CHECK(observation IN('RESPONSE_RETURNED_UNSETTLED','TRANSPORT_UNKNOWN_NO_RETRY','EXPIRED_AFTER_RESERVE_NO_SEND','ABORTED_AFTER_RESERVE_NO_SEND')),
 observed_at INTEGER
);
CREATE INDEX judge_cost_reservations_budget ON judge_cost_reservations(budget_id);
-- REPLACE can bypass DELETE triggers when recursive_triggers is off (SQLite
-- default), so reject replacements before uniqueness conflict handling.
CREATE TRIGGER judge_cost_budget_no_replace BEFORE INSERT ON judge_cost_budget
WHEN EXISTS(SELECT 1 FROM judge_cost_budget WHERE singleton=NEW.singleton)
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_BUDGET_NO_REPLACE'); END;
CREATE TRIGGER judge_cost_reservation_no_replace BEFORE INSERT ON judge_cost_reservations
WHEN EXISTS(SELECT 1 FROM judge_cost_reservations WHERE run_id=NEW.run_id)
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_RESERVATION_NO_REPLACE'); END;
-- Defense in depth: the application also uses a single INSERT ... SELECT.
-- Trigger check and insertion are one atomic SQLite statement, not read/then/write.
CREATE TRIGGER judge_cost_admit BEFORE INSERT ON judge_cost_reservations
BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM judge_cost_budget b WHERE b.singleton=1
  AND b.budget_id=NEW.budget_id AND b.enabled=1
  AND NEW.send_intent_at>=b.starts_at AND NEW.send_intent_at<b.execute_until
  AND b.prior_committed_nano+b.committed_nano+NEW.reserved_nano<=b.ceiling_nano
 ) THEN RAISE(ABORT,'JUDGE_COST_ADMISSION_CLOSED') END;
END;
-- Counter and row commit together; each admission reads a constant number of
-- rows instead of scanning every prior reservation against D1's daily read cap.
CREATE TRIGGER judge_cost_commit AFTER INSERT ON judge_cost_reservations
BEGIN
 UPDATE judge_cost_budget SET committed_nano=committed_nano+NEW.reserved_nano,
  reservation_count=reservation_count+1 WHERE budget_id=NEW.budget_id;
END;
-- No response, timeout, browser retry, new session or new campaign refunds money.
CREATE TRIGGER judge_cost_no_delete BEFORE DELETE ON judge_cost_reservations
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_RESERVATIONS_PERMANENT'); END;
CREATE TRIGGER judge_cost_immutable BEFORE UPDATE ON judge_cost_reservations
WHEN NEW.run_id<>OLD.run_id OR NEW.budget_id<>OLD.budget_id
 OR NEW.request_sha256<>OLD.request_sha256 OR NEW.model<>OLD.model
 OR NEW.max_input_tokens<>OLD.max_input_tokens OR NEW.max_output_tokens<>OLD.max_output_tokens
 OR NEW.reserved_nano<>OLD.reserved_nano OR NEW.send_intent_at<>OLD.send_intent_at
 OR OLD.observation IS NOT NULL
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_RESERVATION_IMMUTABLE'); END;
CREATE TRIGGER judge_cost_budget_no_delete BEFORE DELETE ON judge_cost_budget
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_BUDGET_PERMANENT'); END;
CREATE TRIGGER judge_cost_budget_no_reset BEFORE UPDATE ON judge_cost_budget
WHEN NEW.singleton<>OLD.singleton OR NEW.budget_id<>OLD.budget_id
 OR NEW.prior_committed_nano<OLD.prior_committed_nano
 OR NEW.ceiling_nano>OLD.ceiling_nano OR NEW.starts_at<>OLD.starts_at
 OR NEW.execute_until>OLD.execute_until
 OR NEW.committed_nano<OLD.committed_nano OR NEW.reservation_count<OLD.reservation_count
BEGIN SELECT RAISE(ABORT,'JUDGE_COST_BUDGET_NO_RESET_OR_INCREASE'); END;
