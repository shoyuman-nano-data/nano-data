// One bounded producer -> receiver handoff, not an autonomous agent framework.
import {createHandoffService,HANDOFF_SOURCE_MAX_BYTES} from './handoff.mjs';
import {hash} from './core.mjs';
import {selectCapsule} from './capsule-contract.mjs';
const bytes=s=>new TextEncoder().encode(s).length;
const closed=reason=>({status:'CLOSED',reason,actual_model_calls:0});
// Conservative surface anchors only, not a complete semantic equivalence test.
export function missingSourceAnchors(original,core){
 if(typeof original!=='string'||typeof core!=='string')return [];
 const named=(original.match(/\b[A-Z][a-z]+(?:[ -][A-Z][a-z]+)+\b/g)||[]).map(s=>s.replace(/^(?:The |Fictional )+/,'')).filter(s=>/[ -]/.test(s));
 const literal=original.match(/\b(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b|\b\d{1,4}(?:[:/.:-]\d{1,4})*(?:\.\d+)?\b/g)||[];
 const hay=core.toLowerCase();
 return [...new Set([...named,...literal])].filter(s=>{const escaped=s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');return !new RegExp('\\b'+escaped+'\\b','i').test(hay);});
}
export function createSeedChain(dependencies){
 const base=createHandoffService(dependencies);
 async function enrich(record){
  if(!record?.source)return record;
  let input;try{input=JSON.parse(record.source);}catch{return record;}
  const core=record.evidence?.output;
  const selected=input.stage==='produce'&&typeof core==='string'&&record.evidence?.finish_reason==='stop'?selectCapsule(input,record.id,core):null;
  if(selected?.capsule)selected.transfer.provenance={original_ref:record.id,raw_model_output_sha256:await hash(core),canonical_core_sha256:await hash(selected.capsule.core),canonical_capsule_sha256:await hash(JSON.stringify(selected.capsule)),scope:'DERIVED_FROM_SAVED_RAW_OUTPUT_WITHOUT_RECORD_REWRITE'};
  const missing=input.stage==='produce'?missingSourceAnchors(input.original,core):[];
  const normalize=s=>typeof s==='string'?s.trim().replace(/\s+/g,' '):null;
  const exactCoreEcho=input.stage==='receive'&&normalize(core)&&normalize(core)===normalize(input.core);
  let outputObject;try{outputObject=JSON.parse(core);}catch{}
  const capsuleEcho=input.stage==='receive'&&outputObject?.stage==='receive'&&outputObject?.nextAction===input.nextAction&&typeof outputObject.core==='string'&&Object.keys(outputObject).every(k=>['stage','purpose','reason','nextAction','core','originalRef','parentId'].includes(k));
  const p=dependencies.policy||{};
  const recoveryOffer=p.enabled===true&&p.authority==='EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL'&&p.receiverOnlyParentId===record.id&&p.maxTotalCalls===1&&p.receiverMaxOutputTokens===2048&&p.receiverDeadlineMs===60000&&Date.now()<Date.parse(p.expiresAt)&&input.stage==='produce'&&record.evidence?.finish_reason==='stop'&&['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(record.evidence?.status)?{parentId:record.id,policyId:p.policyId}:null;
  return {...record,input,...(input.stage==='produce'?{source_anchor_check:{scope:'BOUNDED_LITERAL_NAMES_DAYS_NUMBERS_NOT_SEMANTIC_PROOF',missing,status:missing.length?'REVIEW_POSSIBLE_OMISSION_OR_PARAPHRASE':'NO_MISSING_DETECTED'}}:{}),...(input.stage==='receive'?{action_execution_status:exactCoreEcho?'NOT_EXECUTED_EXACT_CORE_ECHO':capsuleEcho?'NOT_EXECUTED_HANDOFF_RESTATEMENT':'UNVERIFIED_REVIEW_AGAINST_NEXT_ACTION'}:{}),...(recoveryOffer?{receiver_only_offer:recoveryOffer}:{}),originalRef:input.stage==='produce'?record.id:input.originalRef,parentId:input.parentId||null,
   ...(selected?{...selected,transfer_status:selected.transfer.mode}:{}),
   completion_status:(record.evidence?.finish_reason==='length'||record.evidence?.response_diagnostics?.finish_reason==='length')?'TRUNCATED_NOT_COMPLETED':record.evidence?.finish_reason==='stop'?'MODEL_FINISHED_REVIEW_REQUIRED':'OUTCOME_UNCONFIRMED',semantic_status:'MODEL_OUTPUT_REQUIRES_HUMAN_REVIEW',saved_integrity:'SOURCE_AND_RESPONSE_LINKED_NOT_MEANING_PROOF'};
 }
 return {
  async produce({id,owner,original,purpose,reason,nextAction}){
   if(![original,purpose,reason,nextAction].every(x=>typeof x==='string'&&x.trim()))return closed('ALL_HANDOFF_FIELDS_REQUIRED');
   const input={stage:'produce',purpose,reason,nextAction,original},source=JSON.stringify(input);
   if(bytes(source)>HANDOFF_SOURCE_MAX_BYTES)return closed('SEED_INPUT_TOO_LARGE');
   return enrich(await base.run({id,owner,source}));
  },
  async receive({id,owner,parentId}){
   if(id===parentId)return closed('DISTINCT_RECEIVER_ID_REQUIRED');
   const parent=await enrich(await base.read({id:parentId,owner}));
   if(parent?.input?.stage!=='produce'||!parent.capsule||parent.evidence?.finish_reason!=='stop'||!['RESPONSE_VALIDATED','RESPONSE_RECEIVED_TIER_UNKNOWN'].includes(parent.evidence?.status))return closed('VALID_PRODUCER_REQUIRED');
   // Original is NOT sent again. The reference remains available through authenticated read.
   const source=JSON.stringify(parent.capsule);
   if(bytes(source)>HANDOFF_SOURCE_MAX_BYTES)return closed('CAPSULE_TOO_LARGE_NO_AUTO_TRUNCATION');
   return enrich(await base.run({id,owner,source}));
  },
  async read({id,owner}){return enrich(await base.read({id,owner}));}
 };
}
