// Isolated local hardening candidate. Not wired to any app or provider.
const requireApprovalId=id=>{if(typeof id!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(id))throw Error('INVALID_APPROVAL_ID');};
export function createProviderStore(DB){
 const db=DB.withSession('first-primary');
 return {
  async claim(binding){
   requireApprovalId(binding?.approvalId);
   const result=await db.prepare('INSERT OR IGNORE INTO nebius_one_call(approval_id,binding_json,claimed_at) VALUES(?,?,?)').bind(binding.approvalId,JSON.stringify(binding),Date.now()).run();
   if(result.success!==true||!Number.isInteger(result.meta?.changes))throw Error('CLAIM_UNCONFIRMED');
   return result.meta.changes===1;
  },
  async finish(id,evidence){
   requireApprovalId(id);
   const result=await db.prepare('UPDATE nebius_one_call SET evidence_json=?,finished_at=? WHERE approval_id=? AND evidence_json IS NULL').bind(JSON.stringify(evidence),Date.now(),id).run();
   return result.success===true&&result.meta?.changes===1;
  },
  async read(id){
   requireApprovalId(id);
   const row=await db.prepare('SELECT approval_id,claimed_at,evidence_json,finished_at FROM nebius_one_call WHERE approval_id=?').bind(id).first();
   if(!row)return {status:'NOT_RUN',approvalId:id};
   if(!row.evidence_json)return {status:'UNKNOWN_STOP_NO_RETRY',approvalId:id,claimed_at:row.claimed_at};
   return {status:'STORED_ATTEMPT_EVIDENCE_CHECK_SCOPE',approvalId:id,claimed_at:row.claimed_at,finished_at:row.finished_at,evidence:JSON.parse(row.evidence_json)};
  }
 };
}
