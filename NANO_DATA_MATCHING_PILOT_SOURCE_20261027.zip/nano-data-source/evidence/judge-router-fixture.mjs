import assert from 'node:assert/strict';
import {LocalTrialD1,seedTrialFixture} from './judge-test-db.mjs';
import {MODEL} from '../adapter/provider.mjs';
export const ID=n=>'HOF_'+n.toString(16).padStart(32,'0');
export const WILLOW={original:'Fictional Willow Reading Club: Saturday, 2 tables, 6 chairs. Attendance, satisfaction and outcomes unmeasured.',purpose:'Prepare session',reason:'Preserve uncertainty',nextAction:'Make checklist'};
export const CEDAR={original:'Fictional Cedar Repair Workshop: Sunday 10:00, 3 tables, 8 chairs and 1 confirmed outlet. Outcomes unmeasured.',purpose:'Prepare workshop',reason:'Retain unknowns',nextAction:'Make setup checklist'};
export const response=content=>Response.json({id:'LOCAL_MOCK_RESPONSE',model:MODEL,object:'chat.completion',created:1,service_tier:'default',choices:[{index:0,message:{role:'assistant',content},finish_reason:'stop'}],usage:{prompt_tokens:100,completion_tokens:30,total_tokens:130}});
export function fixture(t,module,{transport,callCeiling=6,ceiling=8,maxSessions=2,ttl=1200000,db,clock}={}){
 const raw=db||new LocalTrialD1();if(!db)t.after(()=>raw.close());const time={value:Date.now()},now=clock||(()=>time.value),seeded=seedTrialFixture(raw,{now:now(),callCeiling,ceiling,maxSessions});let sends=0,serial=100;
 const requests=[];const providerFetch=async(...args)=>{sends++;requests.push(JSON.parse(args[1].body));if(transport)return transport(...args);const prompt=requests.at(-1).messages[0].content;return response(prompt.includes('Cedar')?'Cedar Repair Workshop Sunday 10:00: 3 tables, 8 chairs and 1 outlet; outcomes unmeasured.':'Willow Reading Club Saturday: 2 tables, 6 chairs; outcomes unmeasured.');};
 const env={JUDGE_TRIAL_DB:raw,JUDGE_TRIAL_APP_ORIGIN:'https://judge-fixture.invalid',JUDGE_TRIAL_POLICY_JSON:JSON.stringify({enabled:true,authority:'EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL',campaignId:seeded.campaignId,policyId:'HP_LOCAL_C02',maximumEstimatedUSD:0.01,sessionTtlMs:ttl}),JUDGE_TRIAL_PROVIDER_KEY:'LOCAL_TEST_ONLY_C02_TRANSPORT',ASSETS:{fetch:async()=>new Response('<!doctype html><title>Local shell</title>')}};
 const randomBytes=n=>{const b=new Uint8Array(n);let v=++serial;for(let i=0;i<n;i++){b[i]=v%256;v=Math.floor(v/256);}return b;};const make=()=>module.createJudgeTrialRouter?module.createJudgeTrialRouter({providerFetch,now,randomBytes,deadlineMs:5}):module.createApp({providerFetch});let router=make();
 const req=(path,data,cookie='',options={})=>new Request(env.JUDGE_TRIAL_APP_ORIGIN+path,{method:options.method||(data===undefined?'GET':'POST'),headers:{origin:env.JUDGE_TRIAL_APP_ORIGIN,...(data===undefined?{}:{'content-type':'application/json'}),cookie,...options.headers},...(data===undefined?{}:{body:options.raw??JSON.stringify(data)})});
 const fetch=(path,data,cookie='',options)=>router.fetch(req(path,data,cookie,options),env);
 const login=async(grant=0)=>{const r=await fetch('/_judge/auth/login',{code:seeded.grants[grant].code});assert.equal(r.status,200,JSON.stringify(await r.clone().json()));return {cookie:r.headers.get('set-cookie').split(';')[0],info:await r.json()};};
 const newCase=async(cookie,key='LOCAL_CREATION_KEY_'+(++serial))=>{const r=await fetch('/_judge/api/cases/new',{creationKey:key},cookie);const b=await r.json();assert.ok(['CREATED','EXISTING','EMPTY_CASE_EXISTS'].includes(b.status),JSON.stringify(b));return b.case;};
 const produce=(item,cookie,input=WILLOW)=>{const {stage,...fields}=input;return fetch('/_judge/api/seed/produce',{caseId:item.caseId,id:item.producerId,...fields},cookie);};
 const receive=(item,cookie)=>fetch('/_judge/api/seed/receive',{caseId:item.caseId,id:item.receiverId,parentId:item.producerId},cookie);
 const read=(item,cookie,id=item.producerId)=>fetch('/_judge/api/seed/read',{caseId:item.caseId,id},cookie);
 return {raw,time,seeded,env,req,fetch,login,newCase,produce,receive,read,requests,sends:()=>sends,restart(){router=make();}};
}
