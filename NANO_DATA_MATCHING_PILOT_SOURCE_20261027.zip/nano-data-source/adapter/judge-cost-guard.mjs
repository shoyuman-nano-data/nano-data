// PRIVATE CANDIDATE. WIRED ONLY TO EXPLICIT FINAL MODE; NOT DEPLOYED.
// This enforces an application reservation ceiling at specified public tariffs.
// It does NOT guarantee invoice totals, taxes, provider behavior or other key use.
// No production activation was performed by this preparation.
export const COST_MODEL='nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B';
export const COST_ENDPOINT='https://api.tokenfactory.nebius.com/v1/chat/completions';
export const PUBLIC_PRICING_ENDPOINT='https://tokenfactory.nebius.com/api/public/models_info';
export const COST_BUDGET_ID='NANO_DATA_FINAL_JUDGING';
export const JUDGING_END=Date.parse('2026-12-15T20:00:00.000Z');
export const INPUT_BOUND=262144;
export const CEILING_NANO=25000000000;
const PRICE_INPUT_NANO=60,PRICE_OUTPUT_NANO=240;
const RUN=/^HOF_[a-f0-9]{32}$/;
const SHA=/^[a-f0-9]{64}$/;
const encode=s=>new TextEncoder().encode(s);
const digest=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',encode(s)))].map(n=>n.toString(16).padStart(2,'0')).join('');
const current=now=>{const t=now();if(!Number.isSafeInteger(t)||t<0)throw Error('COST_CLOCK_INVALID');return t;};
const closed=reason=>Object.assign(Error(reason),{code:reason});
export function reservationNano(maxOutputTokens){
 if(![512,2048].includes(maxOutputTokens))throw closed('COST_OUTPUT_BOUND_INVALID');
 return INPUT_BOUND*PRICE_INPUT_NANO+maxOutputTokens*PRICE_OUTPUT_NANO;
}

// Public metadata validation, no secret and no inference call. A price snapshot
// cannot lock future provider rates; a race between check and billing remains.
export function validatePricingSnapshot(models){
 if(!Array.isArray(models))throw closed('COST_PRICE_UNVERIFIED');
 const matching=models.flatMap(m=>Array.isArray(m.flavors)?m.flavors.filter(f=>f.model_id===COST_MODEL).map(f=>({m,f})):[]);
 if(matching.length!==1)throw closed('COST_PRICE_UNVERIFIED');
 const {m,f}=matching[0];
 if(m.status!=='active'||m.type!=='text2text'||f.external_provider!==false||f.max_model_len!==INPUT_BOUND||f.input_price_per_million_tokens!==0.06||f.output_price_per_million_tokens!==0.24)throw closed('COST_PRICE_OR_MODEL_CHANGED');
 return Object.freeze({model:COST_MODEL,maxInputTokens:INPUT_BOUND,inputNanoPerToken:PRICE_INPUT_NANO,outputNanoPerToken:PRICE_OUTPUT_NANO});
}

// Only used by a separately activated final-judging route. Public metadata GET,
// no authorization header. Bounded bytes/time, no retries or cached fallback.
export async function readPublicModelPricing(){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),3000);
 try{
  const r=await globalThis.fetch(PUBLIC_PRICING_ENDPOINT,{method:'GET',redirect:'manual',cache:'no-store',signal:controller.signal});
  if(r.status!==200||r.redirected)throw closed('COST_PRICE_UNVERIFIED');
  const reader=r.body?.getReader();if(!reader)throw closed('COST_PRICE_UNVERIFIED');
  let bytes=0,parts=[];
  try{while(true){const next=await reader.read();if(next.done)break;bytes+=next.value.length;if(bytes>262144){await reader.cancel();throw closed('COST_PRICE_UNVERIFIED');}parts.push(next.value);}}finally{reader.releaseLock();}
  const body=new Uint8Array(bytes);let at=0;for(const part of parts){body.set(part,at);at+=part.length;}
  return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(body));
 }finally{clearTimeout(timer);controller.abort();}
}

function inspectRequest(endpoint,options){
 if(endpoint!==COST_ENDPOINT||!options||options.method!=='POST'||options.redirect!=='manual'||typeof options.body!=='string'||encode(options.body).length>4096)throw closed('COST_REQUEST_BOUNDARY_INVALID');
 const headers=new Headers(options.headers);
 if(headers.get('content-type')!=='application/json'||!headers.get('authorization')?.startsWith('Bearer '))throw closed('COST_REQUEST_BOUNDARY_INVALID');
 // The credential is not stored or included in the digest/ledger/error.
 let d;try{d=JSON.parse(options.body);}catch{throw closed('COST_REQUEST_BODY_INVALID');}
 const allowed=['model','messages','max_completion_tokens','n','stream','store','service_tier'];
 if(Object.keys(d||{}).length!==allowed.length||!allowed.every(k=>Object.hasOwn(d,k))||d.model!==COST_MODEL||d.n!==1||d.stream!==false||d.store!==false||d.service_tier!=='default'||![512,2048].includes(d.max_completion_tokens)||!Array.isArray(d.messages)||d.messages.length!==1)throw closed('COST_REQUEST_BODY_INVALID');
 const m=d.messages[0];
 if(!m||Object.keys(m).length!==2||m.role!=='user'||typeof m.content!=='string'||!m.content.trim()||encode(m.content).length>1024)throw closed('COST_REQUEST_BODY_INVALID');
 return {requestBody:options.body,maxOutputTokens:d.max_completion_tokens};
}

export function createJudgeCostLedger(DB,{now=Date.now}={}){
 if(!DB||typeof DB.withSession!=='function')throw closed('COST_ISOLATED_DB_REQUIRED');
 const db=DB.withSession('first-primary');
 return Object.freeze({
  async reserve({runId,requestSha256,maxOutputTokens}){
   if(!RUN.test(runId||'')||!SHA.test(requestSha256||''))throw closed('COST_RESERVATION_INVALID');
   const amount=reservationNano(maxOutputTokens),at=current(now);
   if(at>=JUDGING_END)return false;
   const result=await db.prepare(`INSERT INTO judge_cost_reservations(run_id,budget_id,request_sha256,model,max_input_tokens,max_output_tokens,reserved_nano,send_intent_at)
    SELECT ?,b.budget_id,?,?,?,?,?,? FROM judge_cost_budget b
    WHERE b.singleton=1 AND b.budget_id=? AND b.enabled=1 AND b.starts_at<=? AND b.execute_until>?
    AND b.prior_committed_nano+b.committed_nano+?<=b.ceiling_nano
    AND NOT EXISTS(SELECT 1 FROM judge_cost_reservations WHERE run_id=?)
    RETURNING run_id,request_sha256,reserved_nano,(SELECT execute_until FROM judge_cost_budget WHERE singleton=1) execute_until`)
    .bind(runId,requestSha256,COST_MODEL,INPUT_BOUND,maxOutputTokens,amount,at,COST_BUDGET_ID,at,at,amount,runId).first();
   if(result===null)return false;
   if(result?.run_id!==runId||result.request_sha256!==requestSha256||result.reserved_nano!==amount||!Number.isSafeInteger(result.execute_until)||result.execute_until>JUDGING_END)throw closed('COST_RESERVATION_UNCONFIRMED_NO_SEND');
   return Object.freeze({accepted:true,executeUntil:result.execute_until});
  },
  async observe(runId,observation){
   if(!RUN.test(runId||'')||!['RESPONSE_RETURNED_UNSETTLED','TRANSPORT_UNKNOWN_NO_RETRY','EXPIRED_AFTER_RESERVE_NO_SEND','ABORTED_AFTER_RESERVE_NO_SEND'].includes(observation))throw closed('COST_OBSERVATION_INVALID');
   const r=await db.prepare('UPDATE judge_cost_reservations SET observation=?,observed_at=? WHERE run_id=? AND observation IS NULL').bind(observation,current(now),runId).run();
   if(r?.success!==true||!Number.isSafeInteger(r.meta?.changes))throw closed('COST_OBSERVATION_UNCONFIRMED');
   return r.meta.changes===1;
  },
  async status(){
   return db.prepare(`SELECT ceiling_nano,prior_committed_nano,enabled,starts_at,execute_until,
    committed_nano reserved_nano,reservation_count reservations FROM judge_cost_budget WHERE singleton=1`).bind().first();
  }
 });
}

// The private candidate's final boundary selects this before any final-mode send.
// This component has no default provider fetch or secret binding of its own.
// Callers must supply all dependencies explicitly. Tests supply synthetic ones.
export function createJudgeCostGuard({ledger,providerFetch,readPublicPricing,policy,now=Date.now}){
 const p=Object.freeze({...policy});
 const enabled=()=>p.enabled===true&&p.mode==='APPLICATION_RESERVATION_GUARD_NOT_INVOICE_CAP'&&p.budgetId===COST_BUDGET_ID&&p.executeUntil===JUDGING_END&&Number.isSafeInteger(p.startsAt)&&p.startsAt<JUDGING_END&&current(now)>=p.startsAt&&current(now)<JUDGING_END;
 const deps=()=>ledger&&typeof ledger.reserve==='function'&&typeof ledger.observe==='function'&&typeof providerFetch==='function'&&typeof readPublicPricing==='function';
 return Object.freeze({forRun(runId){
  if(!RUN.test(runId||''))throw closed('COST_RUN_ID_INVALID');
  return async(endpoint,options)=>{
   if(!enabled()||!deps())throw closed('COST_GUARD_DISABLED');
   const inspected=inspectRequest(endpoint,options);
   if(options.signal?.aborted)throw closed('COST_REQUEST_ALREADY_ABORTED');
   // Snapshot mutable request fields before awaits. No credential reaches storage.
   const send={...options,headers:new Headers(options.headers),body:inspected.requestBody};
   let price;try{price=await readPublicPricing();}catch{throw closed('COST_PRICE_UNVERIFIED');}
   validatePricingSnapshot(price);
   if(!enabled()||send.signal?.aborted)throw closed('COST_WINDOW_OR_ABORT_BEFORE_RESERVE');
   const requestSha256=await digest(inspected.requestBody);
   let accepted;try{accepted=await ledger.reserve({runId,requestSha256,maxOutputTokens:inspected.maxOutputTokens});}catch{throw closed('COST_RESERVATION_UNCONFIRMED_NO_SEND');}
   if(accepted?.accepted!==true||!Number.isSafeInteger(accepted.executeUntil)||accepted.executeUntil>JUDGING_END)throw closed('COST_DUPLICATE_OR_BUDGET_CLOSED_NO_SEND');
   const observe=async outcome=>{try{await ledger.observe(runId,outcome);}catch{/* Reservation remains permanently charged regardless. */}};
   if(!enabled()||current(now)>=accepted.executeUntil){await observe('EXPIRED_AFTER_RESERVE_NO_SEND');throw closed('COST_EXPIRED_AFTER_RESERVE_NO_SEND');}
   if(send.signal?.aborted){await observe('ABORTED_AFTER_RESERVE_NO_SEND');throw closed('COST_ABORTED_AFTER_RESERVE_NO_SEND');}
   // Exactly one transport call; no alternate model, retry, refund, or fallback.
   try{const response=await providerFetch(COST_ENDPOINT,send);await observe('RESPONSE_RETURNED_UNSETTLED');return response;}
   catch{await observe('TRANSPORT_UNKNOWN_NO_RETRY');throw closed('COST_TRANSPORT_UNKNOWN_NO_RETRY');}
  };
 }});
}
