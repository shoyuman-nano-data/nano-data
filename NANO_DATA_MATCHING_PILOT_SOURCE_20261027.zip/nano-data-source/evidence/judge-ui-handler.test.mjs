// Actual dedicated UI -> actual app/router/store -> synthetic transport integration.
// This is a VM DOM test, not browser visual/Cookie delivery verification.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {fixture,response} from './judge-router-fixture.mjs';
const {createApp}=await import(process.env.JUDGE_UI_APP_MODULE||'../adapter/app.mjs');
const script=readFileSync(new URL('../public/judge.js',import.meta.url),'utf8');

async function waitFor(predicate,label){
 for(let i=0;i<500;i++){
  if(predicate())return;
  await new Promise(resolve=>setImmediate(resolve));
 }
 assert.ok(predicate(),'UI did not settle: '+label);
}
function uiHarness(server){
 const elements=new Map(),storage=new Map(),events={},timers=new Map(),requests=[];
 let cookie='',serial=0,pending=0;
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',textContent:'',disabled:true,hidden:false,checked:false,children:[],events:{},addEventListener(kind,fn){this.events[kind]=fn;},replaceChildren(...nodes){this.children=nodes;},appendChild(node){this.children.push(node);},set innerHTML(_){throw Error('Unexpected HTML insertion');}});
  return elements.get(id);
 };
 const bridge=async(path,opts={})=>{
  pending++;
  try{
   const body=opts.body?JSON.parse(opts.body):undefined;requests.push({path,body});
   const result=await server.fetch(path,body,cookie);
   const setCookie=result.headers.get('set-cookie');if(setCookie)cookie=setCookie.split(';')[0];
   return result;
  }finally{pending--;}
 };
 const context=vm.createContext({
  document:{getElementById:get,createElement:()=>({value:'',textContent:''})},
  window:{addEventListener:(kind,fn)=>events[kind]=fn},
  sessionStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)},
  localStorage:new Proxy({},{get(){throw Error('Owner/persistent storage accessed');}}),
  fetch:bridge,crypto:{randomUUID:()=>String(++serial).padStart(32,'0')},Date,TextEncoder,
  setTimeout:(fn,delay)=>{const id=++serial;timers.set(id,{fn,delay});return id;},clearTimeout:id=>timers.delete(id)
 });
 vm.runInContext(script,context,{filename:'actual-judge.js'});
 const click=async id=>{assert.equal(get(id).disabled,false,id+' must be enabled');await get(id).events.click();};
 return {get,requests,storage,events,context,click,pending:()=>pending,cookie:()=>cookie};
}

test('C2 T01 actual UI and app complete two distinct cases in one grant with four sends, stable reads and remaining2',async t=>{
 let step=0;
 const outputs=[
  'Willow Reading Club Saturday: 2 tables and 6 chairs. Attendance, satisfaction and outcomes unmeasured.',
  'Willow checklist: prepare 2 tables and 6 chairs for Saturday. Measure attendance, satisfaction and outcomes; do not claim results.',
  'Cedar Repair Workshop Tuesday 10:00: one power outlet and 3 workbenches. Attendance and repair success unmeasured.',
  'Cedar checklist: check one power outlet, prepare 3 workbenches for Tuesday 10:00, and record attendance and repair success as unmeasured.'
 ];
 // Omitting createJudgeTrialRouter intentionally forces fixture() through createApp.
 const server=fixture(t,{createApp},{callCeiling:6,ceiling:8,transport:async()=>response(outputs[step++])});
 const ui=uiHarness(server);
 await waitFor(()=>ui.get('login').disabled===false,'anonymous shell');
 assert.equal(server.sends(),0);
 ui.get('code').value=server.seeded.grants[0].code;
 ui.get('login-form').events.submit({preventDefault(){}});
 assert.equal(ui.get('code').value,'');
 await waitFor(()=>ui.get('produce').disabled===false&&ui.pending()===0,'first case admission');
 const first=ui.get('case-selector').value;
 assert.match(first,/^HOF_[a-f0-9]{32}$/);
 assert.match(ui.get('original').value,/Willow Reading Club/);
 assert.equal(server.sends(),0,'admission and first-case metadata must not send');
 await ui.click('produce');
 await waitFor(()=>ui.get('reviewed').disabled===false,'first CORE saved');
 assert.equal(ui.get('receive').disabled,true,'review is explicit');
 ui.get('reviewed').checked=true;ui.get('reviewed').events.change();
 await ui.click('receive');
 await waitFor(()=>ui.get('result').textContent.includes('Willow checklist'),'first receiver saved');
 const firstAnswer=ui.get('result').textContent;
 assert.equal(server.sends(),2);
 await ui.click('new');
 await waitFor(()=>ui.get('case-selector').value!==first&&ui.get('produce').disabled===false,'second empty case');
 const second=ui.get('case-selector').value;
 assert.notEqual(second,first);
 assert.equal(ui.get('original').value,'','another example does not copy prior input');
 assert.equal(ui.get('reviewed').checked,false);
 ui.get('sample').value='cedar';await ui.click('load-sample');
 assert.match(ui.get('original').value,/Cedar Repair Workshop/);
 await ui.click('produce');
 await waitFor(()=>ui.get('reviewed').disabled===false,'second CORE saved');
 ui.get('reviewed').checked=true;ui.get('reviewed').events.change();
 await ui.click('receive');
 await waitFor(()=>ui.get('result').textContent.includes('Cedar checklist'),'second receiver saved');
 assert.equal(server.sends(),4);
 const rows=server.raw.sql.prepare('SELECT id,case_id,stage,parent_id,source FROM trial_runs ORDER BY created_at,id').all();
 assert.equal(rows.length,4);
 assert.equal(new Set(rows.map(row=>row.case_id)).size,2);
 for(const item of server.raw.sql.prepare('SELECT * FROM trial_cases ORDER BY created_at,case_id').all()){
  const runs=rows.filter(row=>row.case_id===item.case_id);
  assert.equal(runs.length,2);
  assert.equal(runs.find(row=>row.stage==='produce').id,item.case_id);
  assert.equal(runs.find(row=>row.stage==='receive').id,item.receiver_id);
  assert.equal(runs.find(row=>row.stage==='receive').parent_id,item.case_id);
 }
 for(const row of rows)assert.doesNotMatch(row.source,/"(?:caseId|case_id|creationKey|campaignId|grantId|sessionId)"/);
 for(const request of server.requests)assert.doesNotMatch(JSON.stringify(request.messages),/"(?:caseId|case_id|creationKey|campaignId|grantId|sessionId)"/);
 ui.get('case-selector').value=first;await ui.get('case-selector').events.change();
 await waitFor(()=>ui.get('result').textContent===firstAnswer,'read first saved case');
 assert.match(ui.get('original').value,/Willow Reading Club/);
 assert.equal(ui.get('reviewed').checked,false,'review choice never carries across cases');
 await ui.click('refresh');await ui.click('source');
 assert.equal(server.sends(),4,'navigation/refresh/original read never calls transport');
 const session=await(await server.fetch('/_judge/session',undefined,ui.cookie())).json();
 assert.equal(session.remainingCalls,2);
 assert.equal(session.cases.length,2);
 assert.equal(session.metadataUsed,2);
 assert.equal(server.raw.sql.prepare('SELECT count(*) n FROM trial_runs').get().n,4);
 assert.match(ui.get('quota').textContent,/Remaining calls: 2/);
 const persisted=[...ui.storage.values()].join('');
 assert.doesNotMatch(persisted,/Willow Reading Club|Cedar Repair Workshop|LOCAL_TEST_ONLY_CODE|checklist/);
 assert.ok(ui.requests.every(request=>request.path.startsWith('/_judge/')));
});
