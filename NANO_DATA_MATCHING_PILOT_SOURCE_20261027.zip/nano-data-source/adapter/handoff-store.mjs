export const OWNER_TRIAL_POLICIES=Object.freeze(['HP_SEED_ACCEPTANCE_20261026_01','HP_RECEIVER_ONLY_20261027_01','HP_RECEIVER_ACTION_20261027_01','HP_OWNER_100_20261027']);
// Private candidate. Uses a new table; never mutates historical provider evidence.
export function createHandoffStore(DB){
 const db=DB.withSession('first-primary');
 return {
  async reserve({id,owner,source,inputHash,policy}){
   if(policy.ownerTrialGroup==='OWNER_100_20261027'){
    const historical=OWNER_TRIAL_POLICIES.slice(0,3);
    const r=await db.prepare(`INSERT OR IGNORE INTO handoff_runs(id,owner,source,input_hash,policy_id,created_at) SELECT ?,?,?,?,?,? WHERE ((SELECT COUNT(*) FROM handoff_runs WHERE policy_id IN (?,?,?,?))+(SELECT COUNT(*) FROM nebius_one_call))<100 AND (SELECT COUNT(*) FROM nebius_one_call)>=4 AND (SELECT COUNT(*) FROM handoff_runs WHERE policy_id IN (?,?,?))>=4`).bind(id,owner,source,inputHash,policy.policyId,Date.now(),...OWNER_TRIAL_POLICIES,...historical).run();
    if(r.success!==true||!Number.isInteger(r.meta?.changes))throw Error('RESERVATION_UNCONFIRMED');
    return r.meta.changes===1;
   }
   const r=await db.prepare(`INSERT OR IGNORE INTO handoff_runs(id,owner,source,input_hash,policy_id,created_at) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM handoff_runs WHERE policy_id=?)<?`).bind(id,owner,source,inputHash,policy.policyId,Date.now(),policy.policyId,policy.maxTotalCalls).run();
   if(r.success!==true||!Number.isInteger(r.meta?.changes))throw Error('RESERVATION_UNCONFIRMED');
   return r.meta.changes===1;
  },
  async finish(id,evidence){const r=await db.prepare('UPDATE handoff_runs SET evidence_json=?,finished_at=? WHERE id=? AND evidence_json IS NULL').bind(JSON.stringify(evidence),Date.now(),id).run();return r.success===true&&r.meta?.changes===1;},
  async read(id,owner){const r=await db.prepare('SELECT id,source,input_hash,created_at,evidence_json,finished_at FROM handoff_runs WHERE id=? AND owner=?').bind(id,owner).first();return r?{...r,evidence:r.evidence_json?JSON.parse(r.evidence_json):null,evidence_json:undefined,status:r.evidence_json?'SAVED':'PENDING_OR_UNKNOWN_NO_RESEND'}:null;}
 };
}
