import {pilotEnvironment,PILOT_FLAG,PILOT_CUTOFF} from './judge-pilot-bridge.mjs';
import {finalJudgingRequested,finalJudgingPolicy,finalJudgingTransport} from './judge-final-boundary.mjs';
// Isolated trial entry. No owner DB/key/policy fallback; no credential/grant issuer.
import {createSeedChain} from './seed-chain.mjs';
import {createJudgeTrialStore} from './judge-trial-store.mjs';
import {hash} from './core.mjs';
const COOKIE='__Host-nano_judge_trial';
const ASSETS=new Set(['/judge','/judge.js','/judge.css']);
const API=new Map([['/_judge/session','GET'],['/_judge/auth/login','POST'],['/_judge/auth/logout','POST'],['/_judge/api/cases/new','POST'],['/_judge/api/cases/close-stage','POST'],['/_judge/api/seed/produce','POST'],['/_judge/api/seed/receive','POST'],['/_judge/api/seed/read','POST']]);
const ID=/^HOF_[a-f0-9]{32}$/,CREATION_KEY=/^[A-Za-z0-9_-]{16,128}$/;
const SECURITY={'content-security-policy':"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",'x-content-type-options':'nosniff','referrer-policy':'no-referrer','permissions-policy':'camera=(), microphone=(), geolocation=()','cache-control':'no-store'};
const hex=bytes=>[...bytes].map(n=>n.toString(16).padStart(2,'0')).join('');
const iso=n=>new Date(n).toISOString();
function seal(response){const h=new Headers(response.headers);for(const [k,v] of Object.entries(SECURITY))h.set(k,v);return new Response(response.body,{status:response.status,headers:h});}
const json=(value,status=200,headers={})=>seal(Response.json(value,{status,headers}));
// Used only for boundaries known to precede any run reservation in this request.
const fail=(reason,status=403,extra={})=>json({status:'CLOSED',reason,actual_model_calls:0,reservation_made:false,preflight_safe_to_retry:true,...extra},status);
const uncertain=(reason,status=503,extra={})=>json({status:'UNKNOWN_STOP_NO_RETRY',reason,...extra},status);
const expireCookie=()=>`${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
function tokenFrom(request){const values=(request.headers.get('cookie')||'').split(';').map(v=>v.trim()).filter(v=>v.startsWith(COOKIE+'='));if(values.length!==1)return null;const token=values[0].slice(COOKIE.length+1);return /^[a-f0-9]{64}$/.test(token)?token:null;}
async function body(request,maxBytes){const reader=request.body?.getReader();let n=0,parts=[];if(reader){try{while(true){const r=await reader.read();if(r.done)break;n+=r.value.length;if(n>maxBytes){await reader.cancel();throw Error('REQUEST_TOO_LARGE');}parts.push(r.value);}}finally{reader.releaseLock();}}const bytes=new Uint8Array(n);let at=0;for(const p of parts){bytes.set(p,at);at+=p.length;}const raw=new TextDecoder('utf-8',{fatal:true}).decode(bytes);const value=JSON.parse(raw);if(!value||Array.isArray(value)||typeof value!=='object'||JSON.stringify(value)!==raw)throw Error('INVALID_JSON_BODY');return value;}
const keys=(o,allowed)=>Object.keys(o).length===allowed.length&&allowed.every(k=>Object.hasOwn(o,k));
function configuration(env){let p;try{p=JSON.parse(env.JUDGE_TRIAL_POLICY_JSON||'{}');}catch{return null;}
 if(!p||p.enabled!==true||p.authority!=='EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL'||!/^HP_[A-Z0-9_]{1,64}$/.test(p.policyId||'')||!/^[A-Za-z0-9_-]{1,64}$/.test(p.campaignId||'')||!Number.isFinite(p.maximumEstimatedUSD)||p.maximumEstimatedUSD<=0||![512,2048].includes(p.receiverMaxOutputTokens??512)||!Number.isInteger(p.receiverDeadlineMs??15000)||(p.receiverDeadlineMs??15000)<1||(p.receiverDeadlineMs??15000)>60000||!Number.isSafeInteger(p.sessionTtlMs??1200000)||(p.sessionTtlMs??1200000)<1||(p.sessionTtlMs??1200000)>28800000)return null;
 if(!env.JUDGE_TRIAL_DB||typeof env.JUDGE_TRIAL_PROVIDER_KEY!=='string'||!env.JUDGE_TRIAL_PROVIDER_KEY.trim()||/[\r\n]/.test(env.JUDGE_TRIAL_PROVIDER_KEY))return null;
 return {...p,sessionTtlMs:p.sessionTtlMs??1200000,receiverMaxOutputTokens:p.receiverMaxOutputTokens??512,receiverDeadlineMs:p.receiverDeadlineMs??15000};
}
function publicSession(context,usage,cases=[],at=Date.now()){const remainingCalls=Math.max(0,Math.min(usage.grantCeiling-usage.grantUsed,usage.campaignCeiling-usage.campaignUsed));return {authenticated:true,enabled:true,mode:'ISOLATED_JUDGE_TRIAL',sessionTag:context.sessionTag,remainingCalls,metadataUsed:usage.metadataUsed,metadataCeiling:usage.metadataCeiling,canCreateCase:remainingCalls>0&&at<context.executeUntil&&usage.metadataUsed<usage.metadataCeiling,cases,availableStages:{produce:false,receive:false},executeUntil:iso(context.executeUntil),readUntil:iso(context.readUntil),sessionExpiresAt:iso(context.expiresAt),retentionUntil:iso(context.retentionUntil)};}
// Explicit allowlist avoids leaking storage ownership, hashes and grant identifiers.
function publicRecord(record){const allowed=['id','caseId','source','input_hash','created_at','finished_at','evidence','status','replayed','input','capsule','completion_status','semantic_status','saved_integrity','originalRef','parentId','action_execution_status','model_output_semantics','compression_advantage','source_anchor_check','transfer','transfer_status','fallback_option','reason','actual_model_calls'];const safe=Object.fromEntries(allowed.filter(k=>Object.hasOwn(record,k)).map(k=>[k,record[k]]));if(safe.evidence?.status==='UNKNOWN_STOP_NO_RETRY'){safe.evidence={...safe.evidence};delete safe.evidence.actual_model_calls;delete safe.actual_model_calls;}return safe;}
export function isJudgeTrialPath(pathname){return ASSETS.has(pathname)||pathname==='/_judge'||pathname.startsWith('/_judge/');}
export function createJudgeTrialRouter({providerFetch=globalThis.fetch,readPublicPricing,now=Date.now,randomBytes=n=>crypto.getRandomValues(new Uint8Array(n)),deadlineMs=15000}={}){
 const randomHex=n=>{const b=randomBytes(n);if(!(b instanceof Uint8Array)||b.length!==n)throw Error('RANDOM_SOURCE_INVALID');return hex(b);};
 return {async fetch(request,env){
  const url=new URL(request.url),origin=env.JUDGE_TRIAL_APP_ORIGIN;
  let acceptedReservation=false,reservationReached=false;
  try{
   if(ASSETS.has(url.pathname)){
    if(request.method!=='GET')return fail('METHOD_NOT_ALLOWED',405);
    if(url.search||url.protocol!=='https:'||(origin!==undefined&&origin!==url.origin))return fail('REQUEST_BOUNDARY_CLOSED');
    if(!env.ASSETS?.fetch)return fail('TRIAL_ASSETS_NOT_CONFIGURED',503);
    return seal(await env.ASSETS.fetch(request));
   }
   const method=API.get(url.pathname);if(!method)return fail('NOT_FOUND',404);
   if(request.method!==method)return fail('METHOD_NOT_ALLOWED',405);
   if(typeof origin!=='string'||!origin.startsWith('https://')||url.origin!==origin||new URL(origin).origin!==origin||url.search)return fail('TRIAL_ORIGIN_NOT_CONFIGURED');
   if(method==='POST'&&(request.headers.get('origin')!==origin||request.headers.get('content-type')!=='application/json'))return fail('REQUEST_BOUNDARY_CLOSED');
   const token=tokenFrom(request);
   if(url.pathname==='/_judge/auth/logout'){
    let value;try{value=await body(request,512);}catch{return fail('INVALID_TRIAL_REQUEST',400);}if(!keys(value,[]))return fail('INVALID_TRIAL_REQUEST',400);
    if(env.JUDGE_TRIAL_DB&&token)await createJudgeTrialStore(env.JUDGE_TRIAL_DB,{}, {now}).logout(await hash(token));
    return json({authenticated:false,enabled:false,mode:'ISOLATED_JUDGE_TRIAL'},200,{'set-cookie':expireCookie()});
   }
   const finalRequested=finalJudgingRequested(env);
   // Final mode can never recover a missing judge key by using the pilot bridge.
   if(finalRequested&&env.JUDGE_TRIAL_PILOT_BRIDGE!==undefined)return fail('FINAL_PILOT_MIXING_FORBIDDEN',503);
   env=await pilotEnvironment(env,now);
   const p=configuration(env);
   if(!p){if(url.pathname==='/_judge/session')return json({authenticated:false,enabled:false,mode:'ISOLATED_JUDGE_TRIAL'});return fail('TRIAL_DISABLED',503);}
   const admin=createJudgeTrialStore(env.JUDGE_TRIAL_DB,{}, {now});
   if(url.pathname==='/_judge/auth/login'){
    let value;try{value=await body(request,512);}catch{return fail('INVALID_TRIAL_REQUEST',400);}if(!keys(value,['code'])||typeof value.code!=='string'||value.code.length<1||value.code.length>256||/[\r\n]/.test(value.code))return fail('INVALID_TRIAL_REQUEST',400);
    const token=randomHex(32),result=await admin.login({codeHash:await hash(value.code),sessionId:'TS_'+randomHex(16),tokenHash:await hash(token),ttlMs:p.sessionTtlMs,campaignId:p.campaignId});
    if(result.status==='INVALID_CODE'){const rate=await admin.badLogin();return fail(rate.limited?'LOGIN_RATE_LIMITED':'INVALID_LOGIN',rate.limited?429:401,rate.limited?{retryAfterSeconds:rate.retryAfterSeconds}:{});}
    if(result.status==='SESSION_LIMIT')return fail('SESSION_LIMIT',429);
    if(result.status!=='CREATED')return fail('TRIAL_EXPIRED_OR_REVOKED',403);
    // Creation is confirmed. Do not strand its cookie when optional detail reads fail.
    // No retry, grant reset, extra session, or model call is performed here.
    const headers={'set-cookie':`${COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${Math.max(0,Math.floor((result.session.expiresAt-now())/1000))}`};
    let info;
    try{
     const store=createJudgeTrialStore(env.JUDGE_TRIAL_DB,result.scope,{now}),usage=await store.usage();
     if(!usage)return json({authenticated:false,reason:'SESSION_EXPIRED_OR_LOGIN_REQUIRED'},401,headers);
     info=publicSession(result.session,usage,await store.listCases(),now());
    }catch{
     const s=result.session;
     info={authenticated:true,enabled:true,mode:'ISOLATED_JUDGE_TRIAL',sessionTag:s.sessionTag,sessionDetailsPending:true,canCreateCase:false,availableStages:{produce:false,receive:false},executeUntil:iso(s.executeUntil),readUntil:iso(s.readUntil),sessionExpiresAt:iso(s.expiresAt),retentionUntil:iso(s.retentionUntil)};
    }
    return json(info,200,headers);
   }
   const context=token?await admin.session(await hash(token)):null;
   if(!context||context.campaignId!==p.campaignId){if(url.pathname==='/_judge/session'&&!token)return json({authenticated:false,enabled:true,mode:'ISOLATED_JUDGE_TRIAL'});return fail('SESSION_EXPIRED_OR_LOGIN_REQUIRED',401,{authenticated:false});}
   const scope={sessionId:context.sessionId,grantId:context.grantId,campaignId:context.campaignId},store=createJudgeTrialStore(env.JUDGE_TRIAL_DB,scope,{now}),usage=await store.usage();
   if(!usage)return fail('SESSION_EXPIRED_OR_LOGIN_REQUIRED',401,{authenticated:false});
   if(url.pathname==='/_judge/session')return json(publicSession(context,usage,await store.listCases(),now()));
   let value;try{value=await body(request,2048);}catch{return fail('INVALID_TRIAL_REQUEST',400);}
   if(url.pathname==='/_judge/api/cases/new'){
    if(!keys(value,['creationKey'])||!CREATION_KEY.test(value.creationKey||''))return fail('INVALID_TRIAL_REQUEST',400);
    let result;for(let attempts=0;attempts<3;attempts++){result=await store.createCase({creationKey:value.creationKey,producerId:'HOF_'+randomHex(16),receiverId:'HOF_'+randomHex(16)});if(result.status!=='ID_COLLISION')break;}
    return json(result,['CREATED','EXISTING','EMPTY_CASE_EXISTS'].includes(result.status)?200:422);
   }
   if(url.pathname==='/_judge/api/cases/close-stage'){
    if(!keys(value,['caseId','stage'])||!ID.test(value.caseId||'')||!['produce','receive'].includes(value.stage))return fail('INVALID_TRIAL_REQUEST',400);
    const item=await store.closeStage(value.caseId,value.stage);return item?json({status:'STAGE_CLOSED',case:item}):fail('NOT_FOUND',422);
   }
   const action=url.pathname.split('/').at(-1),allowed=action==='produce'?['caseId','id','original','purpose','reason','nextAction']:action==='receive'?['caseId','id','parentId']:['caseId','id'];
   if(!keys(value,allowed)||!ID.test(value.caseId||'')||!ID.test(value.id||'')||(action==='receive'&&!ID.test(value.parentId||''))||(action==='produce'&&!['original','purpose','reason','nextAction'].every(k=>typeof value[k]==='string'&&value[k].trim())))return fail('INVALID_TRIAL_REQUEST',400);
   // Validate registry ownership and fixed IDs BEFORE the chain's read-before-reserve replay.
   const item=await store.caseLookup(value.caseId);
   if(!item||(action==='produce'&&value.id!==item.producerId)||(action==='receive'&&(value.id!==item.receiverId||value.parentId!==item.producerId))||(action==='read'&&![item.producerId,item.receiverId].includes(value.id)))return fail('NOT_FOUND',422);
   if(action!=='read'&&now()>=context.executeUntil)return fail('EXECUTION_EXPIRED',422);
   const finalPolicy=finalRequested?finalJudgingPolicy(env,p,now):null;
   if(action!=='read'&&finalRequested&&!finalPolicy)return fail('FINAL_JUDGING_NOT_ACTIVATED',503);
   const caseStore=createJudgeTrialStore(env.JUDGE_TRIAL_DB,{...scope,caseId:item.caseId},{now});
   const wrappedStore={...caseStore,async reserve(input){reservationReached=true;const reserved=await caseStore.reserve(input);acceptedReservation=reserved===true;return reserved;}};
   const transport=finalRequested&&action!=='read'?finalJudgingTransport({env,policy:finalPolicy,runId:value.id,providerFetch,readPublicPricing,now}):env.JUDGE_TRIAL_PILOT_BRIDGE===PILOT_FLAG?((...args)=>{if(now()>=PILOT_CUTOFF)throw Error('PILOT_CUTOFF');return providerFetch(...args);}):providerFetch;
   const chain=createSeedChain({store:wrappedStore,policy:{enabled:true,authority:'EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL',policyId:p.policyId,maxTotalCalls:usage.campaignCeiling,maximumEstimatedUSD:p.maximumEstimatedUSD,expiresAt:iso(context.executeUntil),receiverMaxOutputTokens:p.receiverMaxOutputTokens,receiverDeadlineMs:p.receiverDeadlineMs},credential:env.JUDGE_TRIAL_PROVIDER_KEY,fetchImpl:transport,...(finalRequested?{transportIsSynthetic:providerFetch!==globalThis.fetch}:{}),deadlineMs});
   const {caseId,...chainValue}=value,result=await chain[action]({...chainValue,owner:context.owner});
   if(action!=='read'&&reservationReached&&!acceptedReservation)return uncertain('RESERVATION_UNCONFIRMED_OR_STAGE_OR_TOTAL_CAP',422,{id:value.id,caseId});
   const safe={...publicRecord(result),caseId};
   if(action!=='read'){
    if(result.status==='UNKNOWN_STOP_NO_RETRY'){delete safe.actual_model_calls;delete safe.reservation_made;}
    else if(acceptedReservation||result.status==='SAVED'||result.status==='PENDING_OR_UNKNOWN_NO_RESEND')safe.reservation_made=true;
    else if(!reservationReached&&result.status==='CLOSED'){safe.reservation_made=false;safe.preflight_safe_to_retry=true;}
   }
   return json(safe,result.status==='SAVED'||result.status==='PENDING_OR_UNKNOWN_NO_RESEND'?200:422);
  }catch{
   // acceptedReservation=false is not proof of no reservation (other contender/commit ambiguity).
   return uncertain(acceptedReservation?'TRIAL_STORAGE_OR_RESULT_UNCERTAIN':'TRIAL_REQUEST_OR_STORAGE_UNCERTAIN');
  }
 }};
}
