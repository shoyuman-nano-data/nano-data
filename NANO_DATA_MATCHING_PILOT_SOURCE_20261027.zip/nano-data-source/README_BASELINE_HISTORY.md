# NANO DATA — private local implementation base

This is a private local release-preflight candidate based on the pinned owner source plus the adopted Cycle02 judge overlay, not a published GitHub repository or a completed contest submission. MIT source license and third-party notices are included. No hosting account config, D1 data, credentials, live approval JSON or real session/record IDs are included. Configuration defaults remain disabled.

The pinned owner archive preserves the newer owner CORE normalization implementation. This candidate retains that implementation and adds the adopted Cycle02 isolated judge case registry, routes, schema and UI without rolling owner behavior back.

## Pinned owner baseline
Owner baseline worker SHA256: d473ba95a10884f5725a6305a386c4d9430ae0a371f227455206ac7572eed87e
All existing owner assets and owner payloads are retained from the supplied baseline, except for the explicit judge early dispatch, build/export/test hooks, generated bundle and this documentation. The full owner-to-candidate byte classification is recorded in the release evidence. Test-only record IDs were replaced with synthetic IDs. Historical non-secret policy labels embedded in runtime accounting are retained because changing them would change the implementation and break the live-base hash; they are not a usable permission or credential. Do not copy historical labels to authorize new model calls. No enabled policy file is distributed.

## Build and offline tests
Node >=24; esbuild 0.28.2 is pinned by package-lock.json. Runtime has no bundled third-party npm dependency. On a fresh machine, npm ci downloads dependencies and executes esbuild installation scripts; review before using it. Then: npm run build; npm test; npm run test:bundle. Tests inject mocked transport; no provider call is needed. This bundle was rebuilt with an existing installed esbuild, not a new npm install.

## System boundary
Cloudflare Worker fetch target with JUDGE_DB D1 binding; not a standalone Node HTTP server. Static assets are embedded by build.mjs. On a new isolated database apply schema.sql followed by migrations/0003_nebius_once.sql and 0004_handoff_product.sql. Never reapply initial schema blindly to an existing database. .env.example is an inventory, not automatically loaded configuration. Keep provider policies disabled until separately authorized. Keys belong in server secret storage, never browser or source.

/workflow shows original, purpose, reason, next action, produced CORE and receiver result. /seed is diagnostic; / is a legacy fixed-test route, not full handoff readiness. Producer and receiver are separate requests/contexts to the same configured model, not independent vendors. Source/reference saving and same-session reload are distinct from semantic correctness. Storage is plaintext. Judge access isolation and cross-session behavior still require review; this archive is the base for that work, not evidence that isolation work is finished.

The capsule contract has an 800-byte transport limit. Oversized CORE does not silently erase meaning: an original-text fallback is offered only if it fits and requires explicit selection. This fallback is not compression success. No general semantic preservation, cost saving or complete contest-readiness claim is made. Saved provider evidence and full completion criteria must be checked separately.

## Verification
The supplied owner baseline test evidence reports 103 source tests and 37 bundled tests passing; these are baseline history, not newly executed Cycle03 totals. A fresh offline build/hash comparison and sanitized-copy tests are recorded separately by the packaging operator. Full per-file hashes are in SHA256SUMS.json.


## Cycle02 judge overlay retained

The dedicated `/judge` route uses separate trial configuration, DB binding, cookie and persistent campaign/grant accounting. Server-issued case IDs support multiple fictional examples inside one unchanged budget. Unknown stages retain their reservations and send-intent markers; moving to another case does not refund or retry the old stage. See `JUDGE_TRIAL_SETUP.md`. Existing owner schema and migrations0003/0004 are not mixed with judge migrations0005/0006. The migration helper is local SQLite-only and is not a production D1 migration authorization.

## Cycle03 release preflight boundary

This source is private and undeployed. Proposed release settings stay disabled by default, with no real grant, code, provider credential or operational dates. Actual judge resources, production migration, credential binding, deployment, model calls and public release require their separate concrete authorization and evidence. Owner100 permissions and its expiry are not judge permissions.

The latest available owner archive inspected for this preparation is `libfile_d71fc99066348191ba36572ef4902eed` version0, ZIP SHA256 `5c0e2a7034d37894463097cd4417074d2e82c5228a6fd71aee25ea0362bf4d25`. Its worker hash matches the root-reported 2026-10-27 12:35:50 UTC owner deployment receipt. No fresh live source/hash observation was made by this local job. Current-live freshness remains unverified; the sole operator must pin the then-current owner release before any authorized deployment. This candidate must not overwrite a newer owner release wholesale.

Saved local tests and package integrity do not establish real judge access, real model quality, production D1 concurrency, physical purge scheduling, billing hard caps or submission. The finite pilot proposal is not a declaration that final judging access requirements are met.
