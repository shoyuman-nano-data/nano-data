# NANO DATA — source-linked AI handoff prototype

Keep the source. Carry the purpose. Continue the work.

This source retains the original record, purpose, reason and next action; produces a compact CORE; allows a separately reviewed receiver step; and saves source-linked results for inspection. NVIDIA Nemotron 3 Nano 30B A3B is called through the Nebius Token Factory API from the server, never with a browser-exposed key. This is a prototype, not evidence of lossless compression or general superiority.

## Source identity and status (28 October 2026)

`worker.mjs` SHA-256: `8312a888670538ee5019752719259fb15f8abdc97d2bd0cc32aec1b02cbf5771`.
This is the exact runtime bundle in the recorded 28 October 2026 10:03:27 UTC pilot deployment, version `894a64e6-8834-4bcc-b8a5-be49d4704ef6`, rather than the older C3 bundle. Deployment evidence is operator-reported and recorded in the project ledger; this package is not a fresh extraction from the host. Runtime source/assets are unchanged from that local deployed source. Documentation and packaging are updated. No external publication or final submission is implied.

A dated, fail-closed pilot bridge remains in the code to preserve reproducibility. Its campaign/policy labels, public hostname and 2026-10-28 13:00 UTC cutoff are nonsensitive constants, not usable access codes or authority to call a model. It is not a reusable production configuration. Do not enable or widen it for another deployment. New installations should use the isolated judge router with their own dedicated server-side key and DB, leaving `JUDGE_TRIAL_PILOT_BRIDGE` unset.

## Reproduce offline

Use Node 24 or later. Tests use synthetic credentials, local SQLite and injected model transports, not real provider requests.

```sh
npm test
npm run test:bundle
npm run test:judge-bundle
# Build dependency installation requires network and runs esbuild's install script:
npm ci
npm run build
```

`package-lock.json` pins esbuild 0.28.2. The generated worker has no npm runtime dependency. No node_modules, authentication state, hosting config, database/account identifiers, private code/hash or enabled policy is shipped. MIT license and third-party notices are included.

## Hosted setup boundary

The runtime targets Cloudflare Workers with D1, not a standalone Node HTTP listener. `build.mjs` embeds static assets. `/workflow` is the original/source/CORE/receiver review screen; `/judge` is the isolated trial screen; `/seed` is diagnostic. Neither loading a screen nor reloading saved results should start model execution.

For an owner installation, bind a fresh `JUDGE_DB`, apply `schema.sql`, then migrations `0003_nebius_once.sql` and `0004_handoff_product.sql`. Configure the exact HTTPS `JUDGE_APP_ORIGIN`, server-only `JUDGE_ACCESS_KEY` and ISO `JUDGE_ACCESS_EXPIRES_AT`. `.env.example` is an inventory, not an auto-loaded file. Provider execution remains disabled unless the appropriate explicit server-side policy is supplied. Set `NEBIUS_API_KEY` only through the host's secret store. Do not copy historical policy identifiers as authorization.

For isolated judge setup, see `JUDGE_TRIAL_DESIGN_HISTORY.md` for routes, session/grant accounting and schema details. Bind a separate `JUDGE_TRIAL_DB`, exact HTTPS `JUDGE_TRIAL_APP_ORIGIN`, dedicated server-only `JUDGE_TRIAL_PROVIDER_KEY`, and an explicitly reviewed `JUDGE_TRIAL_POLICY_JSON`. Schema 0005 plus the validated local SQLite migration helper for 0006 can reproduce the data model locally. The migration helper is NOT a production D1 deployment command. No live database bootstrap or usable grant is bundled. `release/judge-production.disabled.json` is a disabled test fixture, not the dated pilot's live settings.

This package is runnable offline as supplied. Public hosted inference still requires separate operator provisioning, fresh access verification and an agreed judging-period access/cost contract; it must not be advertised as a turnkey public judge service.

## Evidence limits

A historical synthetic source-to-CORE-to-receiver trial and saved reload exist. The dated pilot deployment itself was recorded with zero real pilot model calls at the reviewed checkpoint. Offline test passes are not model-quality results. Finite pilot quotas and expiry do not meet or prove unrestricted final judging access. New sessions do not restore old session bodies. Retention time is not proof of physical deletion; no purge scheduler is claimed. Costs are estimates, not billing hard caps.

## Postcommit login recovery — 28 October 2026

The operator recorded an explicitly approved postcommit login fix and one further replacement-login allowance. If usage or case-detail retrieval fails after a session is committed, the response retains that same session cookie and marks details pending; execution remains disabled until a GET refresh confirms details. The UI does not repeat login. This fixes the reproduced synthetic postcommit failure, not every possible production cause: transport loss, cookie refusal and uncertain commit state remain separate.

The cumulative max_sessions predicate is now3. The prior active session was revoked; sessions_issued2 and two revoked historical sessions were retained at the operator10:03 checkpoint. There was one remaining login issuance at that dated checkpoint, not three new sessions. No new grant/code, counter reset or extra inference allowance was created. Total model-call ceiling2 and estimated USD0.02 guard remain unchanged; the guard is not a billing cap. Pilot expiry remains13:00 UTC; owner expiry remains05:00 UTC and was not reactivated. The existing case-metadata capacity formula rises from4 to5; the authorized operational synthetic case remains one.

Operator receipt records deployment894a64e6-8834-4bcc-b8a5-be49d4704ef6 at10:03:27 UTC and zero runs at that checkpoint. Subsequent activity is not determined by this package. Operator-reported tests: source197/197 and bundle21/21; synthetic old-version postcommit regression1PASS2FAIL became3PASS. This packaging check independently rebuilds the worker and runs only focused synthetic tests. It does not rerun the full suites or call a real provider.

New regression tests and their synthetic fixture are included for offline reproducibility. Operational SQL, database snapshots, authentication state and private grants are not bundled. The portable replacement-login fixture uses a fixed synthetic clock rather than wall-clock time; it is not a production administration script.

This is a private publication candidate, not permission to publish, deploy, extend access, retry model calls or submit. Existing public commits are not modified. Finite pilot access remains distinct from final judging-period access.
