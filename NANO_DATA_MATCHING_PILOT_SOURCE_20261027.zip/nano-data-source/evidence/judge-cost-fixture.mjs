import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {COST_BUDGET_ID,JUDGING_END,COST_MODEL,COST_ENDPOINT} from '../adapter/judge-cost-guard.mjs';
export const NOW=Date.parse('2026-10-28T12:00:00.000Z');
export const runId=n=>'HOF_'+n.toString(16).padStart(32,'0');
export const request=(maxOutputTokens=512)=>({method:'POST',redirect:'manual',headers:{authorization:'Bearer SYNTHETIC_NON_SECRET_TEST_VALUE','content-type':'application/json'},body:JSON.stringify({model:COST_MODEL,messages:[{role:'user',content:'Fictional local test. No personal data.'}],max_completion_tokens:maxOutputTokens,n:1,stream:false,store:false,service_tier:'default'})});
export const pricing=()=>[{status:'active',type:'text2text',flavors:[{model_id:COST_MODEL,external_provider:false,max_model_len:262144,input_price_per_million_tokens:0.06,output_price_per_million_tokens:0.24}]}];
export const policy=()=>({enabled:true,mode:'APPLICATION_RESERVATION_GUARD_NOT_INVOICE_CAP',budgetId:COST_BUDGET_ID,startsAt:NOW-1000,executeUntil:JUDGING_END});
export class LocalCostD1 {
 constructor(path=':memory:',{initialize=true,ceiling=25000000000,prior=0,enabled=1}={}){
  this.sql=new DatabaseSync(path);
  this.sql.exec('PRAGMA busy_timeout=10000; PRAGMA foreign_keys=ON;');
  if(initialize){
   this.sql.exec(readFileSync(new URL('../migrations/0007_judge_cost_guard.PROPOSED.sql',import.meta.url),'utf8'));
   this.sql.prepare('INSERT INTO judge_cost_budget(singleton,budget_id,ceiling_nano,prior_committed_nano,starts_at,execute_until,enabled) VALUES(1,?,?,?,?,?,?)').run(COST_BUDGET_ID,ceiling,prior,NOW-1000,JUDGING_END,enabled);
  }
 }
 withSession(mode){if(mode!=='first-primary')throw Error('PRIMARY_REQUIRED');return this;}
 prepare(query){const sql=this.sql;return {bind(...args){return {async run(){const r=sql.prepare(query).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},async first(){return sql.prepare(query).get(...args)||null;}};}};}
 close(){this.sql.close();}
}
export {COST_ENDPOINT};
