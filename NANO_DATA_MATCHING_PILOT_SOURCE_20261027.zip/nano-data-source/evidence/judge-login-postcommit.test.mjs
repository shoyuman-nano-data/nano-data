// Synthetic DB only: no production credentials, network, or model calls.
import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './judge-router-fixture.mjs';
const module=await import(process.env.JUDGE_LOGIN_FIX_MODULE||'../worker.mjs');
for(const failure of ['none','usage','listCases'])test('postcommit login '+failure+' keeps same session recoverable',async t=>{
 const s=fixture(t,module,{maxSessions:1,callCeiling:2,ceiling:2});
 const original=s.raw.prepare.bind(s.raw);let injected=false;
 s.raw.prepare=query=>{if(!injected&&((failure==='usage'&&query.startsWith('SELECT c.ceiling campaign_ceiling'))||(failure==='listCases'&&/^SELECT (?:case_id|\*) FROM trial_cases WHERE campaign_id=/.test(query)))){injected=true;throw Error('SYNTHETIC_POSTCOMMIT_READ_FAULT');}return original(query);};
 const request=(path,data,cookie='')=>module.default.fetch(s.req(path,data,cookie),s.env);
 const login=await request('/_judge/auth/login',{code:s.seeded.grants[0].code});assert.equal(login.status,200);
 const body=await login.json();assert.equal(body.authenticated,true);
 const header=login.headers.get('set-cookie');assert.match(header,/^__Host-nano_judge_trial=[a-f0-9]{64}; HttpOnly; Secure; SameSite=Strict; Path=\/; Max-Age=\d+$/);
 const cookie=header.split(';')[0];assert.equal(JSON.stringify(body).includes(cookie.split('=')[1]),false);
 if(failure!=='none'){assert.equal(body.sessionDetailsPending,true);assert.equal(body.canCreateCase,false);assert.equal(Object.hasOwn(body,'remainingCalls'),false);assert.deepEqual(body.availableStages,{produce:false,receive:false});}
 const reread=await request('/_judge/session',undefined,cookie);assert.equal(reread.status,200);const restored=await reread.json();assert.equal(restored.authenticated,true);assert.equal(restored.sessionTag,body.sessionTag);assert.equal(restored.remainingCalls,2);
 const duplicate=await request('/_judge/auth/login',{code:s.seeded.grants[0].code},cookie);assert.equal(duplicate.status,429);assert.equal((await duplicate.json()).reason,'SESSION_LIMIT');assert.equal(duplicate.headers.get('set-cookie'),null);
 assert.equal(s.raw.sql.prepare('SELECT sessions_issued FROM trial_grants WHERE id=?').get(s.seeded.grants[0].id).sessions_issued,1);assert.equal(s.raw.sql.prepare('SELECT count(*) n FROM trial_sessions').get().n,1);assert.equal(s.raw.sql.prepare('SELECT count(*) n FROM trial_runs').get().n,0);assert.equal(s.sends(),0);
});
