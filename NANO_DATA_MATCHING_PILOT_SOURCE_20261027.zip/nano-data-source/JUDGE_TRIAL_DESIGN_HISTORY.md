# Isolated judge trial — Cycle02 private local candidate

This is a synthetic local implementation, not deployed access or a production grant offer. It combines Cycle01 source libfile_997d3a8817fc8191a5999591410a4c23@v0 with exactly six protected files from later owner source libfile_d71fc99066348191ba36572ef4902eed@v0. BASE_PROVENANCE.json and CYCLE02_CHANGES.json identify both inputs and final changes. CYCLE01_CHANGES.json remains historical. The latest owner normalization/fidelity/quantity/capsule/restore behavior is retained.

## Dedicated entry and closed defaults

/judge, /judge.js and /judge.css use only /_judge/* APIs. Routing finishes before reading owner settings. Dedicated bindings remain JUDGE_TRIAL_DB, JUDGE_TRIAL_APP_ORIGIN, JUDGE_TRIAL_POLICY_JSON and JUDGE_TRIAL_PROVIDER_KEY. Default policy is {"enabled":false}; owner DB/key/policy never supplies a fallback. No real credential, grant, database, enabled operational settings or deployment is included.

Enabled configuration is server reviewed: authority EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL, campaignId, HP_ policyId, maximumEstimatedUSD and optional sessionTtlMs/receiverMaxOutputTokens/receiverDeadlineMs. The campaign DB determines execution/read/retention bounds and durable ceilings. Existing token, timeout and estimate guards remain; estimates are not invoice hard caps. Owner100 and its expiry are not judge allocation.

Cookie __Host-nano_judge_trial is HttpOnly/Secure/SameSite=Strict/Path=/. Token hashes stay server-side. It neither issues nor consumes the owner cookie. Data ownership is session-bound; budget ownership is campaign/grant across all cases and sessions.

## Server-issued cases and durable accounting

A case registry fixes producerId=caseId and a separate receiverId. Client creationKey is an idempotent metadata correlation key, not authorization. /_judge/api/cases/new accepts only {creationKey}. Lost metadata response can be reconciled with that key or authenticated session summaries; creating/reading/closing a case costs no model call or run reservation.

Only one unreserved, unclosed producer case is allowed per session. Metadata count across all sessions and closed cases is capped at grant.call_ceiling + grant.max_sessions; it is distinct from the global call budget. A new case also checks active execution/access and remaining global calls. Metadata is not a promise that a later reservation will succeed.

/_judge/api/cases/close-stage accepts {caseId,stage} and irreversibly closes only that stage's future reservation. It is idempotent; it never deletes/refunds a run. If reserve wins first, at most that one reserved operation may finish into its original case before retention. If close wins, no new reservation succeeds. A rowless unknown can be closed before proceeding to another example. Different-case semantic duplicates are not detected or claimed prevented.

Produce uses {caseId,id,original,purpose,reason,nextAction}; receive uses {caseId,id,parentId}; read uses {caseId,id}. The router validates fixed IDs, scope and parent before the shared chain's read-before-reserve replay. Case metadata does not enter the provider prompt, stored source JSON or capsule. The original 800-byte serialized UTF-8 contract remains. Parent must be the same case's accepted, completed, non-purged producer; overlarge CORE is not truncated and fallback stays an explicit offer.

Reserve uses one atomic INSERT...SELECT plus UNIQUE(grant_id,case_id,stage), current session/grant/campaign/case/ID/closure/parent bounds and all-case counts. Every run row, including PENDING/UNKNOWN/failed/purged tombstones, consumes campaign/grant count permanently. Policy revision, relogin, case creation and storage deletion do not reset it. Finish binds run/campaign/grant/session/case, once only, before retention; close or access expiry does not erase a valid in-flight completion.

Known preflight rejection is distinct from storage/duplicate/response uncertainty. A generic reserve false is not proof that no other request reserved the stage. Uncertain requests retain intent markers and never automatically resend. Read and metadata reconciliation are separate from model execution.

## Local migration only

0005_judge_trial_isolated.sql remains unchanged. New 0006_judge_trial_cases.sql rebuilds trial_runs to remove the old UNIQUE(grant_id,stage), preserving every reservation field and tombstone. adapter/judge-trial-migration.mjs is a Node SQLite local helper owning BEGIN IMMEDIATE/COMMIT/ROLLBACK, validation and deterministic legacy mapping. It stages server-allocated missing receiver IDs, validates parent/scope, compares all original fields/counts/IDs and rejects inconsistencies. Repeat migration keeps fixed mappings. Fresh and populated migration fixtures are supplied.

Execute 0006 only through the validated local helper; direct SQL without staging fails. This is not a live D1 migration runner or authorization to initialize/update production DBs. Existing owner schema.sql and migrations0003/0004 never include trial schema.

## Multi-example local UI

Start separate trial session → prepare metadata case → edit fictional input → explicit producer → compare raw/canonical CORE and human review → explicit receiver → read saved state → try another example. Same-session case selector can return to old saved results. Case switches reset review and never copy an unknown source into a new send. Loading/restoring a page never runs producer/receiver automatically.

Only sessionTag, fixed IDs, creationKeys and send-intent markers enter judge sessionStorage. No source, CORE, output, code or cookie does. Each case has its own busy/opToken; auth/view epochs and request order guard DOM/session updates. A stale reply cannot overwrite another case; finally releases the original case's own busy state even after a view switch. Unknown state is retained and must be closed before moving on where required.

Remaining0 closes new execution, while permitted saved reads remain. Remaining1 permits a new producer but does not promise a two-call completion. Metadata ceiling and actual access bounds are separately shown. Logout,401/403, expiry and pagehide clear content; pageshow rechecks authentication first. Relogin creates a different session and does not grant access to old session cases. readUntil is capped by session/grant/access expiry. purge() can clear bodies while preserving quota tombstones; no production purge scheduler exists, so elapsed retention is not a claim of physical deletion.

## Evidence and outstanding scope

Synthetic happy-path fixture uses two different examples, grant6 calls/campaign8/maxSessions2. Four explicit stages consume4 reservations/mock sends, leaving2; metadata/read operations consume0. These are configurable test values, not final judging-period allowances. Other fault fixtures deliberately use smaller budgets and clocks.

Node24 node:sqlite, independent SQLite worker connections, injected mock transports and VM UI exercise the contract. The evidence archive includes exact commands/env module selectors, actual suite totals/logs, acceptance mapping, corrected failures, hashes and network guard results. Supplied generated worker can be tested offline. Build uses lockfile-pinned esbuild0.28.2; no runtime dependency or tool cache is shipped.

Local pass is not actual fresh-browser judge access, browser visual QA, production D1 concurrency, operational purge, billing assurance, real model/semantic success, comparative superiority or submission. Root later decides actual audiences, credentials, DB, judging dates, quotas/costs, deployment and first live verification within concrete authorization.
