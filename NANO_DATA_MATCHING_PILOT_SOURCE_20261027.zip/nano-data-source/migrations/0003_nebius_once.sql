-- LOCAL/STAGING ONLY. No remote migration authorized or performed.
CREATE TABLE IF NOT EXISTS nebius_one_call (
 approval_id TEXT PRIMARY KEY NOT NULL,
 binding_json TEXT NOT NULL,
 claimed_at INTEGER NOT NULL,
 evidence_json TEXT,
 finished_at INTEGER
);
