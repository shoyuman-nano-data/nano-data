export const CAPSULE_MAX_BYTES=800;
export const utf8Bytes=s=>new TextEncoder().encode(s).length;
export const makeCapsule=(input,id,core,transferMode='CORE')=>({stage:'receive',purpose:input.purpose,reason:input.reason,nextAction:input.nextAction,core,originalRef:id,parentId:id,transferMode});
export const coreBudget=(input,id)=>Math.max(0,CAPSULE_MAX_BYTES-utf8Bytes(JSON.stringify(makeCapsule(input,id,''))));
export function selectCapsule(input,id,core){
 const canonical=core.replace(/^[ \t\r\n]+|[ \t\r\n]+$/g,'');
 const normalization={type:'OUTER_ASCII_WHITESPACE_ONLY',applied:canonical!==core,raw_core_bytes:utf8Bytes(core),canonical_core_bytes:utf8Bytes(canonical),raw_capsule_bytes:utf8Bytes(JSON.stringify(makeCapsule(input,id,core)))};
 const compact=makeCapsule(input,id,canonical),size=utf8Bytes(JSON.stringify(compact));
 if(size<=CAPSULE_MAX_BYTES)return{capsule:compact,transfer:{mode:'CORE',normalization,capsule_bytes:size,limit_bytes:CAPSULE_MAX_BYTES}};
 const raw=makeCapsule(input,id,input.original,'ORIGINAL_FALLBACK'),rawSize=utf8Bytes(JSON.stringify(raw));
 if(rawSize<=CAPSULE_MAX_BYTES)return{fallback_option:{mode:'ORIGINAL_FALLBACK',requires_explicit_selection:true,available_within_existing_limit:true,bytes:rawSize,compression_claim:false},transfer:{mode:'UNAVAILABLE',normalization,reason:'CORE_EXCEEDS_CAPSULE_CONTRACT',core_capsule_bytes:size,original_capsule_bytes:rawSize,limit_bytes:CAPSULE_MAX_BYTES}};
 return{transfer:{mode:'UNAVAILABLE',normalization,reason:'CORE_AND_LOSSLESS_ORIGINAL_EXCEED_CAPSULE_CONTRACT',core_capsule_bytes:size,original_capsule_bytes:rawSize,limit_bytes:CAPSULE_MAX_BYTES}};
}
