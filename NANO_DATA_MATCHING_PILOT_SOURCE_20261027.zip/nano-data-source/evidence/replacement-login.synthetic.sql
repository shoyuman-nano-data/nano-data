-- Synthetic fixture only. Requires injected TEMP fixture_clock; not production SQL.
UPDATE trial_sessions SET revoked=1
WHERE grant_id='SYNTHETIC_RECOVERY_GRANT' AND revoked=0
AND (SELECT COUNT(*) FROM trial_campaigns)=1
AND (SELECT COUNT(*) FROM trial_grants)=1
AND (SELECT COUNT(*) FROM trial_sessions)=2
AND (SELECT COUNT(*) FROM trial_sessions WHERE grant_id='SYNTHETIC_RECOVERY_GRANT' AND revoked=1)=1
AND (SELECT COUNT(*) FROM trial_sessions WHERE grant_id='SYNTHETIC_RECOVERY_GRANT' AND revoked=0)=1
AND (SELECT COUNT(*) FROM trial_runs)=0
AND EXISTS(SELECT 1 FROM trial_grants g JOIN trial_campaigns c ON c.id=g.campaign_id
 WHERE g.id='SYNTHETIC_RECOVERY_GRANT' AND c.id='SYNTHETIC_RECOVERY_CAMPAIGN'
 AND g.sessions_issued=2 AND g.max_sessions=2 AND g.call_ceiling=2 AND g.revoked=0
 AND c.ceiling=2 AND c.revoked=0 AND g.expires_at=1793192400000
 AND c.execute_until=1793192400000 AND c.read_until=1793192400000 AND c.retention_until=1793192400000
 AND (SELECT COUNT(*) FROM fixture_clock)=1 AND (SELECT now_ms FROM fixture_clock)<1793192400000);
UPDATE trial_grants SET max_sessions=3
WHERE changes()=1 AND id='SYNTHETIC_RECOVERY_GRANT' AND campaign_id='SYNTHETIC_RECOVERY_CAMPAIGN'
AND max_sessions=2 AND sessions_issued=2 AND call_ceiling=2 AND revoked=0 AND expires_at=1793192400000
AND (SELECT COUNT(*) FROM trial_sessions WHERE grant_id='SYNTHETIC_RECOVERY_GRANT')=2
AND (SELECT COUNT(*) FROM trial_sessions WHERE grant_id='SYNTHETIC_RECOVERY_GRANT' AND revoked=1)=2
AND (SELECT COUNT(*) FROM trial_runs)=0;
