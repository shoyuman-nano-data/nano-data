-- PRIVATE CANDIDATE ONLY. Apply only after deployment/retention/access approval.
CREATE TABLE handoff_runs (
 id TEXT PRIMARY KEY NOT NULL,
 owner TEXT NOT NULL,
 source TEXT NOT NULL,
 input_hash TEXT NOT NULL,
 policy_id TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 evidence_json TEXT,
 finished_at INTEGER
);
CREATE INDEX handoff_policy_count ON handoff_runs(policy_id);
