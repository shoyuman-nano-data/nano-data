// No authentication or approval issuer. Caller must supply a verified session owner.
// Disabled until a separately approved server policy is configured. No automatic retries.
import {createProviderAttempt,MODEL,ENDPOINT,ESTIMATED_MAX_USD} from './provider.mjs';
import {hash} from './core.mjs';
import {coreBudget} from './capsule-contract.mjs';
export const HANDOFF_PREFIX='Produce plain-text CORE. Preserve names, times, places, every quantity, negation and unknowns for nextAction; no headings, JSON or repetition. Input JSON:\n';
export const RECEIVER_PREFIX='You are the receiver. Execute nextAction using core, purpose and reason. Return the requested work product, NOT a summary or copy of the handoff. Preserve unknowns; invent no facts. Input JSON:\n';
export const HANDOFF_SOURCE_MAX_BYTES=800;
const ID=/^HOF_[a-f0-9]{32}$/;
export function createHandoffService({store,policy,credential,fetchImpl=globalThis.fetch,deadlineMs=15000}){
 const p=Object.freeze({...policy});
 const receiverTokens=p.receiverMaxOutputTokens??512,receiverDeadline=p.receiverDeadlineMs??deadlineMs;
 const maxEstimatedPerCall=(1024*0.06+Math.max(512,receiverTokens)*0.24)/1000000;
 const receiverOnly=p.receiverOnlyParentId!==undefined;
 const restrictedPolicyValid=!receiverOnly||(ID.test(p.receiverOnlyParentId)&&p.maxTotalCalls===1&&receiverTokens===2048&&receiverDeadline===60000);
 const ownerTrialValid=(p.ownerTrialGroup===undefined&&p.policyId!=='HP_OWNER_100_20261027')||(p.ownerTrialGroup==='OWNER_100_20261027'&&p.policyId==='HP_OWNER_100_20261027'&&p.maxTotalCalls===100&&!receiverOnly&&receiverTokens===2048&&receiverDeadline===60000);
 const validPolicy=()=>p.enabled===true&&restrictedPolicyValid&&ownerTrialValid&&[512,2048].includes(receiverTokens)&&Number.isInteger(receiverDeadline)&&receiverDeadline>=1&&receiverDeadline<=60000&&p.authority==='EXPLICIT_OWNER_JUDGE_PRODUCT_APPROVAL'&&/^HP_[A-Z0-9_]{1,64}$/.test(p.policyId||'')&&Number.isSafeInteger(p.maxTotalCalls)&&p.maxTotalCalls>0&&p.maxTotalCalls<=100000&&Number.isFinite(p.maximumEstimatedUSD)&&p.maximumEstimatedUSD>=p.maxTotalCalls*maxEstimatedPerCall&&Number.isFinite(Date.parse(p.expiresAt))&&new Date(Date.parse(p.expiresAt)).toISOString()===p.expiresAt&&Date.now()<Date.parse(p.expiresAt);
 const closed=reason=>({status:'CLOSED',reason,actual_model_calls:0});
 return {
  async run({id,owner,source}){
   if(typeof owner!=='string'||!owner)return closed('AUTHENTICATED_OWNER_REQUIRED');
   if(!ID.test(id||'')||typeof source!=='string'||!source.trim()||new TextEncoder().encode(source).length>HANDOFF_SOURCE_MAX_BYTES)return closed('INPUT_INVALID');
   // Read-before-run returns the existing immutable result; neither duplicates nor uncertain attempts resend.
   const prior=await store.read(id,owner);if(prior)return {...prior,replayed:true};
   if(!validPolicy())return closed('PRODUCT_POLICY_NOT_APPROVED_OR_EXPIRED');
   if(receiverOnly){let input;try{input=JSON.parse(source);}catch{return closed('RECEIVER_ONLY_PARENT_REQUIRED');}if(input.stage!=='receive'||input.parentId!==p.receiverOnlyParentId||input.originalRef!==p.receiverOnlyParentId)return closed('RECEIVER_ONLY_PARENT_REQUIRED');}
   if(typeof credential!=='string'||!credential.trim()||/[\r\n]/.test(credential))return closed('PROVIDER_SECRET_REQUIRED');
   let isReceiver=false;try{isReceiver=JSON.parse(source).stage==='receive';}catch{}
   let producerPrefix=HANDOFF_PREFIX;try{const input=JSON.parse(source);if(input.stage==='produce')producerPrefix=HANDOFF_PREFIX.replace('CORE.',`CORE within ${coreBudget(input,id)} JSON-escaped UTF-8 bytes.`);}catch{}
   const prompt=(isReceiver?RECEIVER_PREFIX:producerPrefix)+source,inputHash=await hash(prompt);
   let reserved;try{reserved=await store.reserve({id,owner,source,inputHash,policy:p});}catch{return {status:'UNKNOWN_STOP_NO_RETRY',id,reason:'RESERVATION_UNCONFIRMED'};}
   if(!reserved)return closed('DUPLICATE_OR_TOTAL_CALL_CAP');
   const useProductBudget=isReceiver||p.ownerTrialGroup==='OWNER_100_20261027';
   const maxOutputTokens=useProductBudget?receiverTokens:512,runDeadline=useProductBudget?receiverDeadline:deadlineMs;
   const approval={approvalId:'NEBIUS_'+id.toUpperCase(),authority:'EXPLICIT_OWNER_ONE_CALL_APPROVAL',approved:true,inputHash,model:MODEL,endpoint:ENDPOINT,maxCalls:1,maxOutputTokens,maxInputTokens:1024,budgetUSD:0.01,expiresAt:p.expiresAt};
   let claimed=false;
   const adapter={claim:async()=>{if(claimed)return false;claimed=true;return true;},finish:async(_,e)=>store.finish(id,e)};
   const execution=createProviderAttempt({store:adapter,serverApproval:approval,credential,fetchImpl,deadlineMs:runDeadline,prompt,maxOutputTokens});
   const result=await execution.run({ownerAuthorized:true});
   // Preflight closed results have no provider finish. Persist them as well.
   if(!claimed)await store.finish(id,result);
   const saved=await store.read(id,owner);
   if(!saved?.evidence)return {status:'UNKNOWN_STOP_NO_RETRY',id,reason:'SAVED_EVIDENCE_UNCONFIRMED'};
   return {...saved,model_output_semantics:'UNVERIFIED_REVIEW_AGAINST_SOURCE',compression_advantage:'NOT_CLAIMED'};
  },
  async read({id,owner}){if(!ID.test(id||'')||typeof owner!=='string'||!owner)return closed('INPUT_INVALID');return await store.read(id,owner)||closed('NOT_FOUND');}
 };
}
