PRAGMA foreign_keys=ON;
CREATE TABLE caller_expectations(attempt TEXT PRIMARY KEY, job TEXT NOT NULL CHECK(job IN ('A_REPORT','B_REPORT','B_SOURCE')), owner TEXT NOT NULL);
CREATE TABLE claims(attempt TEXT PRIMARY KEY REFERENCES caller_expectations(attempt), job TEXT NOT NULL, token TEXT NOT NULL UNIQUE);
CREATE TABLE records(attempt TEXT NOT NULL REFERENCES claims(attempt), name TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(attempt,name));
CREATE TABLE successful_attempts(attempt TEXT PRIMARY KEY REFERENCES claims(attempt), commit_json TEXT NOT NULL);

CREATE UNIQUE INDEX judge_one_job_per_session ON caller_expectations(owner,job);
